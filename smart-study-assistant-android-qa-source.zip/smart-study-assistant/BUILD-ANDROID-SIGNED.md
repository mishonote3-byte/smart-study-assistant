# بناء Android بالمفتاح الجديد

النسخة المصدرية المحدثة لا تتضمن مفاتيح التوقيع. إعداد EAS يستخدم `credentialsSource: remote` لإنشاء مفتاح خاص بحساب صاحب التطبيق عند أول بناء.

إذا كان لديك APK مثبت من إصدار سابق وتريد أن تُحدّثه دون حذفه، استخدم مفتاح التوقيع الأصلي من مشروعك السابق بدلاً من إنشاء مفتاح جديد، واضبط `credentialsSource: local` على نسختك الخاصة فقط.

## APK للتجربة
بعد تسجيل الدخول إلى Expo وتشغيل الاعتمادات:

```bash
npm install -g eas-cli
npm install -g pnpm@9.12.0
pnpm install --frozen-lockfile
eas login
eas build --platform android --profile preview
```

## AAB للنشر

```bash
eas build --platform android --profile production
```

الـ preview مضبوط لإنتاج APK، والـ production مضبوط لإنتاج AAB.

## ملاحظة مهمة
احتفظ بنسخة احتياطية آمنة من ملف `.jks` وبياناته. إذا استُخدم هذا المفتاح للنشر أو التحديثات، فقد تحتاجه في الإصدارات اللاحقة.
