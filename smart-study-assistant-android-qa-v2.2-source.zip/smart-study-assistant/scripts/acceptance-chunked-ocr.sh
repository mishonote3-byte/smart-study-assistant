#!/usr/bin/env bash
set -euo pipefail

# Usage: API_BASE_URL=http://127.0.0.1:3000 ./scripts/acceptance-chunked-ocr.sh /path/to/file.pdf
PDF_PATH="${1:?مرر مسار ملف PDF للاختبار}"
API_BASE_URL="${API_BASE_URL:-http://127.0.0.1:3000}"
BATCH_SIZE="${BATCH_SIZE:-3}"
OUTPUT_DIR="${OUTPUT_DIR:-test-results/ocr-chunks}"
FILE_NAME="$(basename "$PDF_PATH")"

mkdir -p "$OUTPUT_DIR"
rm -f "$OUTPUT_DIR"/page-*.json

first_response="$OUTPUT_DIR/page-1-$BATCH_SIZE.json"
curl --fail --silent --show-error --max-time 60 \
  -X POST "$API_BASE_URL/api/document/upload" \
  -H 'content-type: application/octet-stream' \
  -H "x-file-name: $(printf '%s' "$FILE_NAME" | sed 's/ /%20/g')" \
  -H 'x-mime-type: application/pdf' \
  -H 'x-page-from: 1' \
  -H "x-page-to: $BATCH_SIZE" \
  --data-binary "@$PDF_PATH" > "$first_response"

total_pages="$(grep -o '"pageCount":[0-9]*' "$first_response" | head -1 | cut -d: -f2)"
if [[ -z "$total_pages" ]]; then
  echo "لم يُرجع الخادم عدد صفحات PDF." >&2
  exit 1
fi

completed=1
for ((from = BATCH_SIZE + 1; from <= total_pages; from += BATCH_SIZE)); do
  to=$((from + BATCH_SIZE - 1))
  if (( to > total_pages )); then to="$total_pages"; fi
  response="$OUTPUT_DIR/page-$from-$to.json"
  echo "تحليل الصفحات $from–$to من أصل $total_pages"
  curl --fail --silent --show-error --max-time 60 \
    -X POST "$API_BASE_URL/api/document/upload" \
    -H 'content-type: application/octet-stream' \
    -H "x-file-name: $(printf '%s' "$FILE_NAME" | sed 's/ /%20/g')" \
    -H 'x-mime-type: application/pdf' \
    -H "x-page-from: $from" \
    -H "x-page-to: $to" \
    --data-binary "@$PDF_PATH" > "$response"
  if grep -q 'تعذّرت معالجة\|لم يتم العثور' "$response"; then
    echo "فشلت الدفعة $from–$to." >&2
    exit 1
  fi
  completed=$((completed + 1))
done

echo "نجح OCR الدفعي: $completed دفعة غطت الصفحات 1–$total_pages."
