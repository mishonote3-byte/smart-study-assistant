#!/usr/bin/env bash
set -euo pipefail

base_url="${1:-http://127.0.0.1:3000}"
output_dir="${2:-/tmp/study-user-acceptance}"
page_number="${3:-1}"
mkdir -p "$output_dir"

files=(
  "اسسالهجوم.pdf"
  "اسلحهمشتركه.pdf"
  "التامينالشامل.pdf"
  "مدفعية2.pdf"
  "مدفعية.pdf"
)

for file_name in "${files[@]}"; do
  source_file="/home/ubuntu/upload/$file_name"
  result_file="$output_dir/$file_name.json"
  curl --silent --show-error --fail --max-time 240 \
    -X POST "$base_url/api/document/upload" \
    -H "Content-Type: application/octet-stream" \
    -H "x-file-name: $(python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1]))' "$file_name")" \
    -H "x-mime-type: application/pdf" \
    -H "x-page-from: $page_number" \
    -H "x-page-to: $page_number" \
    --data-binary "@$source_file" \
    -o "$result_file"
  jq -r --arg name "$file_name" '[$name, (.pageCount // 0), (.extractedPageFrom // 0), (.extractedPageTo // 0), ((.text // "") | length)] | @tsv' "$result_file"
done
