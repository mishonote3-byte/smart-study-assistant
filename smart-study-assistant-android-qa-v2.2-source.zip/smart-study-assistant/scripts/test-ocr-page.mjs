// اختبار جودة OCR المدمج على صفحة نموذجية من ملف المستخدم.
import { readFileSync } from "node:fs";
const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
const { createCanvas } = await import("@napi-rs/canvas");

const file = "/home/ubuntu/upload/اسسالهجوم.pdf";
const pageNumber = 2;

const buffer = Buffer.from(readFileSync(file));
const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
const page = await doc.getPage(pageNumber);
const viewport = page.getViewport({ scale: 3.2 });
const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
const context = canvas.getContext("2d");
await page.render({ canvas, canvasContext: context, viewport }).promise;
const image = canvas.toBuffer("image/png");
console.log(`rendered page ${pageNumber} of ${file}: ${image.length} bytes`);

const { createWorker } = await import("tesseract.js");
const worker = await createWorker("ara", 1, {
  langPath: "/home/ubuntu/budget-tracker/server/assets/tessdata",
  gzip: true,
  cacheMethod: "none",
});
await worker.setParameters({ tessedit_pageseg_mode: "6" });
const { data } = await worker.recognize(image, {}, { text: true });
console.log("OCR text:");
console.log(data.text.slice(0, 900));
await worker.terminate();
