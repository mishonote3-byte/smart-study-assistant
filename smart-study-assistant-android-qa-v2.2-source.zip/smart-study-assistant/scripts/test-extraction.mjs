// فحص استخراج نص PDF مباشرة (المسار غير OCR) لمقارنته مع OCR المدمج على ملفات المستخدم.
import { readFileSync } from "node:fs";
const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");

const FILES = [
  "/home/ubuntu/upload/اسسالهجوم.pdf",
  "/home/ubuntu/upload/مدفعية.pdf",
  "/home/ubuntu/upload/مدفعية2.pdf",
  "/home/ubuntu/upload/التامينالشامل.pdf",
  "/home/ubuntu/upload/مفهوم.pdf",
  "/home/ubuntu/upload/اسلحهمشتركه.pdf",
];

for (const file of FILES) {
  const buffer = Buffer.from(readFileSync(file));
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const samplePages = [1, 2, 3].filter((p) => p <= doc.numPages);
  const summary = { file: file.split("/").pop(), totalPages: doc.numPages };
  for (const pageNumber of samplePages) {
    const page = await doc.getPage(pageNumber);
    const content = await page.getTextContent();
    const direct = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .filter(Boolean)
      .join(" ")
      .trim();
    const arabic = (direct.match(/[\u0600-\u06FF]/g) || []).length;
    const totalLetters = (direct.match(/[\p{L}\p{N}]/gu) || []).length;
    summary[`page${pageNumber}`] = {
      length: direct.length,
      arabicRatio: totalLetters > 0 ? Math.round((arabic / totalLetters) * 100) / 100 : null,
      sample: direct.slice(0, 80),
      needsOcr:
        totalLetters < 25 ||
        (totalLetters >= 30 && arabic / Math.max(totalLetters, 1) < 0.32),
    };
  }
  console.log(JSON.stringify(summary));
}
