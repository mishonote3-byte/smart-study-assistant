// اختبار مباشر لمنطق توليد الأسئلة عبر الاستدعاء المحلي (بدون بروتوكول HTTP)
import { appRouter } from "../server/routers";

const TEXT =
  "التعليم أساس بناء الأمم. يهدف التعليم إلى نقل المعرفة من جيل إلى جيل. " +
  "تشمل المناهج الدراسية المواد العلمية والأدبية. يعتمد الطالب على المعلم في فهم الدروس. " +
  "المذاكرة اليومية تحسن نتائج الامتحانات. النجاح يتطلب الاجتهاد والاستمرارية. " +
  "القراءة توسع المدارك وتنمي العقل. العلم نور والجهل ظلام. " +
  "المدرسة بيئة تربوية متكاملة. الأسرة هي الشريك الأول في التعليم. " +
  "التكنولوجيا الحديثة طورت أساليب التدريس. الفهم أعمق من الحفظ في التعلم. " +
  "الامتحانات تقيس مستوى الطالب. المعلم الجيد يلهم طلابه. المكتبة مصدر غني للمعرفة.";

async function run() {
  const caller = appRouter.createCaller({ req: { headers: {} } as never, res: { locals: {} } as never, user: null } as never);
  const questions = await caller.study.generateQuestions({
    text: TEXT,
    documentId: "test-multi",
    questionCount: 12,
    typeCounts: { mcq: 4, fill: 3, truefalse: 3, reason: 2 },
  });
  const counts: Record<string, number> = {};
  for (const q of questions) counts[q.type] = (counts[q.type] ?? 0) + 1;
  console.log("total:", questions.length, "counts:", JSON.stringify(counts));
  for (const q of questions) {
    console.log(`[${q.type}] ${q.question.slice(0, 60)}`);
  }
}
run().catch((err) => {
  console.error(err);
  process.exit(1);
});
