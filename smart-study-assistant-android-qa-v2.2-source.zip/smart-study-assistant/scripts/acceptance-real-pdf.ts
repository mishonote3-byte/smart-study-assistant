import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { appRouter } from "../server/routers";

async function main() {
  const filePath = process.argv[2];
  if (!filePath) throw new Error("Usage: node --import tsx scripts/acceptance-real-pdf.ts /path/file.pdf");
  const buffer = await readFile(filePath);
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const pdf = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
  const pages: any[] = [];
  const textParts: string[] = [];
  const failures: number[] = [];
  const batchSize = 3;

  for (let first = 1; first <= pdf.numPages; first += batchSize) {
    const last = Math.min(first + batchSize - 1, pdf.numPages);
    const result: any = await caller.study.processDocument({
      fileName: basename(filePath), mimeType: "application/pdf", fileData: buffer.toString("base64"),
      pageFrom: first, pageTo: last,
    });
    if (!result.structuredDocument?.pages?.length) {
      for (let page = first; page <= last; page += 1) failures.push(page);
      continue;
    }
    pages.push(...result.structuredDocument.pages);
    textParts.push(result.text);
    process.stderr.write(`\rProcessed ${last}/${pdf.numPages}`);
  }
  process.stderr.write("\n");

  const fullText = textParts.join("\n\n");
  const questions: any[] = await caller.study.generateQuestions({
    text: fullText, documentId: "acceptance-real-pdf", questionCount: 150,
    typeCounts: { mcq: 105, truefalse: 45 },
  });
  const sourcePages = new Set(questions.map(question => question.sourcePage).filter(Boolean));
  const confidences = pages.map(page => Number(page.confidence || 0));
  console.log(JSON.stringify({
    file: basename(filePath),
    totalPages: pdf.numPages,
    processedPages: pages.length,
    failedPages: failures,
    readablePages: pages.filter(page => (page.text || "").replace(/\s/g, "").length >= 40).length,
    ocrPages: pages.filter(page => page.blocks?.some((block: any) => block.source === "ocr")).length,
    tablePages: pages.filter(page => page.blocks?.some((block: any) => block.type === "table")).length,
    averageConfidence: confidences.length ? Number((confidences.reduce((sum, value) => sum + value, 0) / confidences.length).toFixed(2)) : 0,
    extractedCharacters: fullText.length,
    questionCount: questions.length,
    mcq: questions.filter(question => question.type === "mcq").length,
    truefalse: questions.filter(question => question.type === "truefalse").length,
    questionsWithSourcePage: questions.filter(question => question.sourcePage).length,
    coveredSourcePages: sourcePages.size,
  }, null, 2));
}

main().catch(error => { console.error(error); process.exitCode = 1; });
