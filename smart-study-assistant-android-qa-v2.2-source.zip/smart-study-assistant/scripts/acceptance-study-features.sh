#!/usr/bin/env bash
set -euo pipefail

base_url="${1:-http://127.0.0.1:3100}"
source_json="${2:-/tmp/study-user-acceptance-page-five/مدفعية2.pdf.json}"
text="$(jq -r '.text' "$source_json" | head -c 5000)"

summary_payload="$(jq -nc --arg text "$text" '{"0":{"json":{"text":$text,"documentId":"acceptance-file"}}}')"
curl --silent --show-error --fail --max-time 90 -X POST \
  -H 'Content-Type: application/json' \
  -d "$summary_payload" \
  "$base_url/api/trpc/study.summarizeDocument?batch=1" \
  -o /tmp/study-summary-acceptance.json

questions_payload="$(jq -nc --arg text "$text" '{"0":{"json":{"text":$text,"documentId":"acceptance-file","questionCount":6}}}')"
curl --silent --show-error --fail --max-time 90 -X POST \
  -H 'Content-Type: application/json' \
  -d "$questions_payload" \
  "$base_url/api/trpc/study.generateQuestions?batch=1" \
  -o /tmp/study-questions-acceptance.json

grade_payload="$(jq -nc '{"0":{"json":{"question":"علل أهمية التخطيط.","modelAnswer":"يساعد التخطيط على تنظيم الموارد وتحقيق الهدف.","studentAnswer":"لأنه ينظم الموارد ويوجه العمل نحو الهدف."}}}')"
curl --silent --show-error --fail --max-time 60 -X POST \
  -H 'Content-Type: application/json' \
  -d "$grade_payload" \
  "$base_url/api/trpc/study.gradeEssay?batch=1" \
  -o /tmp/study-grading-acceptance.json

jq -r '["summary", (.[0].result.data.json.executive | length)] | @tsv' /tmp/study-summary-acceptance.json
jq -r '["questions", (.[0].result.data.json | length)] | @tsv' /tmp/study-questions-acceptance.json
jq -r '["essay_score", (.[0].result.data.json.score)] | @tsv' /tmp/study-grading-acceptance.json
