import { readFile } from "node:fs/promises";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

const filePath = process.argv[2];
if (!filePath) throw new Error("Provide a PDF file path.");

const data = new Uint8Array(await readFile(filePath));
const loadingTask = getDocument({ data });
const document = await loadingTask.promise;
const pages = [];

for (let pageNumber = 1; pageNumber <= Math.min(document.numPages, 50); pageNumber += 1) {
  const page = await document.getPage(pageNumber);
  const content = await page.getTextContent();
  const text = content.items
    .map((item) => ("str" in item ? item.str : ""))
    .filter(Boolean)
    .join(" ")
    .trim();
  if (text) pages.push(text);
}

const text = pages.join("\n\n").replace(/\s{2,}/g, " ").trim();
console.log(JSON.stringify({ pages: document.numPages, characters: text.length, preview: text.slice(0, 700) }, null, 2));
