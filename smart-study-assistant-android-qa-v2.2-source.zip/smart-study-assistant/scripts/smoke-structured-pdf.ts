import PDFDocument from "pdfkit";
import { appRouter } from "../server/routers";

async function makePdf() {
  const pdf = new PDFDocument({ size: "A4" });
  const chunks: Buffer[] = [];
  pdf.on("data", chunk => chunks.push(Buffer.from(chunk)));
  pdf.font("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
  pdf.fontSize(18).text("الفصل الأول: التخطيط", { align: "right" });
  pdf.fontSize(13).text("يهدف التخطيط إلى تنظيم الموارد وتحقيق الأهداف بكفاءة.", { align: "right" });
  pdf.text("النوع   العدد   الملاحظة", { align: "right" });
  pdf.text("الأول   10   مهم", { align: "right" });
  pdf.text("الثاني   20   عاجل", { align: "right" });
  pdf.end();
  await new Promise<void>((resolve, reject) => { pdf.on("end", resolve); pdf.on("error", reject); });
  return Buffer.concat(chunks);
}

async function main() {
  const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
  const buffer = await makePdf();
  const result: any = await caller.study.processDocument({
    fileName: "smoke-arabic.pdf",
    mimeType: "application/pdf",
    fileData: buffer.toString("base64"),
  });

  if (!result.structuredDocument?.pages?.length) throw new Error("Structured PDF result was not created");
  if (!result.text.includes("[صفحة رقم 1]")) throw new Error("Page source marker is missing");
  if (!result.structuredDocument.pages[0].blocks.length) throw new Error("No structured blocks were produced");
  console.log(JSON.stringify({
    pages: result.structuredDocument.pages.length,
    blocks: result.structuredDocument.pages[0].blocks.length,
    quality: result.structuredDocument.quality,
  }));
}

main().catch(error => { console.error(error); process.exitCode = 1; });
