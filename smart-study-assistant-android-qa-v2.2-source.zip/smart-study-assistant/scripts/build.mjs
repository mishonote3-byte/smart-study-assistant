import { cpSync, existsSync, rmSync } from "node:fs";
import { spawnSync } from "node:child_process";

const run = (command, args) => {
  const result = spawnSync(command, args, { stdio: "inherit", shell: process.platform === "win32" });
  if (result.status !== 0) process.exit(result.status || 1);
};

rmSync("dist", { recursive: true, force: true });
run("pnpm", ["exec", "expo", "export", "--platform", "web", "--output-dir", "dist/web"]);
run("pnpm", ["exec", "esbuild", "server/_core/index.ts", "--platform=node", "--packages=external", "--bundle", "--format=esm", "--outdir=dist"]);
if (existsSync("server/assets")) cpSync("server/assets", "dist/assets", { recursive: true });
