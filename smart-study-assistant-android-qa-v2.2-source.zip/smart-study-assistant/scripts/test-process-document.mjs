import { readFile } from "node:fs/promises";
import path from "node:path";

const filePath = process.argv[2];
if (!filePath) throw new Error("Provide a document file path.");

const content = await readFile(filePath);
const isPdf = filePath.toLowerCase().endsWith(".pdf");
const payload = {
  fileName: path.basename(filePath),
  mimeType: isPdf ? "application/pdf" : "text/plain",
  fileData: content.toString("base64"),
};
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 35_000);

try {
  const response = await fetch("http://127.0.0.1:3000/api/trpc/study.processDocument?batch=1", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ "0": { json: payload } }),
    signal: controller.signal,
  });
  const body = await response.text();
  console.log(JSON.stringify({ status: response.status, ok: response.ok, body: body.slice(0, 1000) }, null, 2));
} finally {
  clearTimeout(timeout);
}
