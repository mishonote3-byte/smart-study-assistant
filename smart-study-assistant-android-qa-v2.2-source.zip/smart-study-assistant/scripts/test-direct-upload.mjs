import { readFile } from "node:fs/promises";
import path from "node:path";

const filePath = process.argv[2];
if (!filePath) throw new Error("Provide a document file path.");

const binary = await readFile(filePath);
const name = path.basename(filePath);
const mimeType = name.toLowerCase().endsWith(".pdf") ? "application/pdf" : "text/plain";
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 75_000);

try {
  const response = await fetch("http://127.0.0.1:3000/api/document/process", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ fileName: name, mimeType, fileData: binary.toString("base64") }),
    signal: controller.signal,
  });
  const body = await response.json();
  console.log(JSON.stringify({ status: response.status, ok: response.ok, textLength: body.text?.length ?? 0, preview: body.text?.slice(0, 240), error: body.error }, null, 2));
} finally {
  clearTimeout(timeout);
}
