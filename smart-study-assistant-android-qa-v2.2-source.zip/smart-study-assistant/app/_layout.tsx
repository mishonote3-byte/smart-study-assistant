import "../global.css";
import { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "@/lib/theme-provider";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { StudyProvider } from "@/contexts/study-context";
import { trpc, createTRPCClient } from "@/lib/trpc";
import { getApiBaseUrl, setRuntimeApiBaseUrl } from "@/constants/oauth";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1 },
  },
});

export default function RootLayout() {
  const [trpcClient, setTrpcClient] = useState<ReturnType<typeof createTRPCClient> | null>(null);
  useEffect(() => {
    AsyncStorage.getItem('study_api_base_url').then(savedUrl => {
      if (savedUrl) setRuntimeApiBaseUrl(savedUrl);
      setTrpcClient(createTRPCClient(getApiBaseUrl()));
    }).catch(() => setTrpcClient(createTRPCClient(getApiBaseUrl())));
  }, []);
  if (!trpcClient) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F5F7FA' }}><ActivityIndicator size="large" color="#1B4F72" /></View>;
  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <GestureHandlerRootView style={{ flex: 1, direction: 'rtl' }}>
          <ThemeProvider>
            <StudyProvider>
              <Stack
                screenOptions={{
                  headerShown: false,
                  animation: "none",
                  contentStyle: { backgroundColor: "#F5F7FA" },
                }}
              >
                <Stack.Screen name="(tabs)" />
                <Stack.Screen
                  name="document-view"
                  options={{ presentation: "card", animation: "fade" }}
                />
                <Stack.Screen name="exam" options={{ presentation: "card", animation: "fade" }} />
                <Stack.Screen name="qa-exam" options={{ presentation: "card", animation: "fade" }} />
                <Stack.Screen name="oauth/callback" />
              </Stack>
            </StudyProvider>
            <StatusBar style="auto" />
          </ThemeProvider>
        </GestureHandlerRootView>
      </QueryClientProvider>
    </trpc.Provider>
  );
}
