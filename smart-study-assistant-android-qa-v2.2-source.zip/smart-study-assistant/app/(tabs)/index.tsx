import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { ScrollView, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useStudy } from "@/contexts/study-context";

type ActionCardProps = {
  title: string;
  description: string;
  icon: React.ComponentProps<typeof MaterialIcons>["name"];
  iconBackground: string;
  iconColor: string;
  onPress: () => void;
  wide: boolean;
};

function ActionCard({ title, description, icon, iconBackground, iconColor, onPress, wide }: ActionCardProps) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityLabel={title}
      activeOpacity={0.82}
      onPress={onPress}
      style={[styles.actionCard, wide && styles.actionCardWide]}
    >
      <View style={[styles.actionIcon, { backgroundColor: iconBackground }]}> 
        <MaterialIcons color={iconColor} name={icon} size={23} />
      </View>
      <View style={styles.actionText}>
        <Text style={styles.actionTitle}>{title}</Text>
        <Text style={styles.actionDescription}>{description}</Text>
      </View>
      <MaterialIcons color="#90A4B8" name="chevron-left" size={25} />
    </TouchableOpacity>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const { documents, examResults } = useStudy();
  const wide = width >= 820;

  const totalQuestions = documents.reduce((total, document) => total + (document.questionBank?.length || 0), 0);
  const totalExams = examResults.length;
  const averageScore = totalExams > 0
    ? Math.round(examResults.reduce((total, result) => total + (result.score / Math.max(result.totalQuestions, 1)) * 100, 0) / totalExams)
    : null;

  return (
    <ScreenContainer style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <View style={[styles.hero, wide && styles.heroWide]}>
            <View style={styles.heroMain}>
              <View style={styles.brandRow}>
                <View style={styles.brandIcon}>
                  <MaterialIcons color="#DDF7FF" name="auto-awesome" size={20} />
                </View>
                <Text style={styles.brandLabel}>منصة مذاكرة ذكية</Text>
              </View>
              <Text style={styles.heroTitle}>مساعد الدراسة الذكي</Text>
              <Text style={styles.heroDescription}>
                حمّل مستنداتك، استخرج محتواها، وراجعها من خلال ملخصات وأسئلة وامتحانات تفاعلية.
              </Text>
              <View style={styles.heroActions}>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="رفع مستند"
                  activeOpacity={0.84}
                  onPress={() => router.push("/upload")}
                  style={styles.primaryHeroButton}
                >
                  <MaterialIcons color="#08304A" name="upload-file" size={20} />
                  <Text style={styles.primaryHeroButtonText}>رفع مستند</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="معلومات الخصوصية"
                  activeOpacity={0.84}
                  onPress={() => router.push("/privacy")}
                  style={styles.secondaryHeroButton}
                >
                  <MaterialIcons color="#D4EDF8" name="shield" size={19} />
                  <Text style={styles.secondaryHeroButtonText}>الخصوصية</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={[styles.heroInsight, wide && styles.heroInsightWide]}>
              <View style={styles.insightIcon}>
                <MaterialIcons color="#AEEBFF" name="psychology" size={27} />
              </View>
              <Text style={styles.insightValue}>{documents.length}</Text>
              <Text style={styles.insightLabel}>مستند محفوظ محلياً</Text>
              <View style={styles.insightDivider} />
              <Text style={styles.insightDetail}>يدعم PDF وWord والصور والنص المباشر</Text>
            </View>
          </View>

          <View style={styles.statsGrid}>
            <View style={[styles.statCard, wide && styles.statCardWide]}>
              <View style={[styles.statIcon, { backgroundColor: "#E8F8FF" }]}>
                <MaterialIcons color="#087A9C" name="description" size={20} />
              </View>
              <View style={styles.statText}>
                <Text style={styles.statValue}>{documents.length}</Text>
                <Text style={styles.statLabel}>مستندات</Text>
              </View>
            </View>
            <View style={[styles.statCard, wide && styles.statCardWide]}>
              <View style={[styles.statIcon, { backgroundColor: "#EAFBF1" }]}>
                <MaterialIcons color="#208A51" name="quiz" size={20} />
              </View>
              <View style={styles.statText}>
                <Text style={styles.statValue}>{totalQuestions}</Text>
                <Text style={styles.statLabel}>أسئلة جاهزة</Text>
              </View>
            </View>
            <View style={[styles.statCard, wide && styles.statCardWide]}>
              <View style={[styles.statIcon, { backgroundColor: "#FFF5DE" }]}>
                <MaterialIcons color="#C68108" name="assignment" size={20} />
              </View>
              <View style={styles.statText}>
                <Text style={styles.statValue}>{totalExams}</Text>
                <Text style={styles.statLabel}>امتحانات</Text>
              </View>
            </View>
            <View style={[styles.statCard, wide && styles.statCardWide]}>
              <View style={[styles.statIcon, { backgroundColor: "#F1ECFF" }]}>
                <MaterialIcons color="#6D4CC8" name="military-tech" size={20} />
              </View>
              <View style={styles.statText}>
                <Text style={styles.statValue}>{averageScore === null ? "—" : `${averageScore}%`}</Text>
                <Text style={styles.statLabel}>متوسط النتيجة</Text>
              </View>
            </View>
          </View>

          <View style={[styles.workspace, wide && styles.workspaceWide]}>
            <View style={styles.primaryColumn}>
              <View style={styles.sectionHeading}>
                <View>
                  <Text style={styles.sectionTitle}>ابدأ المذاكرة</Text>
                  <Text style={styles.sectionDescription}>اختر ما تريد إنجازه الآن</Text>
                </View>
                <View style={styles.sectionDot} />
              </View>
              <View style={styles.actionGrid}>
                <ActionCard
                  description="PDF، Word، صور أو نص مباشر"
                  icon="upload-file"
                  iconBackground="#E8F8FF"
                  iconColor="#087A9C"
                  onPress={() => router.push("/upload")}
                  title="رفع مستند جديد"
                  wide={wide}
                />
                <ActionCard
                  description="اختبر فهمك في أسئلة متنوعة"
                  icon="fact-check"
                  iconBackground="#FFF5DE"
                  iconColor="#BE7E09"
                  onPress={() => router.push("/exam-setup")}
                  title="إنشاء امتحان"
                  wide={wide}
                />
                <ActionCard
                  description="اطلع على درجاتك ونقاط التحسين"
                  icon="insights"
                  iconBackground="#F1ECFF"
                  iconColor="#6D4CC8"
                  onPress={() => router.push("/results")}
                  title="نتائج الامتحانات"
                  wide={wide}
                />
              </View>

              <View style={styles.documentsPanel}>
                <View style={styles.panelHeader}>
                  <View>
                    <Text style={styles.panelTitle}>المستندات الأخيرة</Text>
                    <Text style={styles.panelSubtitle}>{documents.length ? "افتح مستنداً لمراجعة الملخص والأسئلة" : "لم تضف مستنداً بعد"}</Text>
                  </View>
                  {documents.length > 0 && (
                    <TouchableOpacity accessibilityRole="button" onPress={() => router.push("/upload")} style={styles.textButton}>
                      <Text style={styles.textButtonLabel}>عرض الكل</Text>
                    </TouchableOpacity>
                  )}
                </View>
                {documents.length > 0 ? (
                  <View style={styles.documentList}>
                    {documents.slice(0, 3).map((document) => (
                      <TouchableOpacity
                        accessibilityRole="button"
                        accessibilityLabel={`فتح ${document.name}`}
                        activeOpacity={0.82}
                        key={document.id}
                        onPress={() => router.push({ pathname: "/document-view" as never, params: { id: document.id } })}
                        style={styles.documentRow}
                      >
                        <View style={styles.documentIcon}>
                          <MaterialIcons color="#0E7490" name="menu-book" size={21} />
                        </View>
                        <View style={styles.documentDetails}>
                          <Text numberOfLines={1} style={styles.documentName}>{document.name}</Text>
                          <Text style={styles.documentMeta}>{document.questionBank?.length || 0} سؤال · {document.summary ? "ملخص جاهز" : "بانتظار التلخيص"}</Text>
                        </View>
                        <MaterialIcons color="#8AA0B2" name="chevron-left" size={25} />
                      </TouchableOpacity>
                    ))}
                  </View>
                ) : (
                  <TouchableOpacity activeOpacity={0.84} onPress={() => router.push("/upload")} style={styles.emptyState}>
                    <View style={styles.emptyIcon}>
                      <MaterialIcons color="#0E7490" name="auto-stories" size={26} />
                    </View>
                    <View style={styles.emptyText}>
                      <Text style={styles.emptyTitle}>حوّل أي مادة إلى خطة مراجعة</Text>
                      <Text style={styles.emptyDescription}>ارفع أول ملف لتنشئ ملخصاً، مفاهيم أساسية، وبنك أسئلة تلقائياً.</Text>
                    </View>
                    <Text style={styles.emptyLink}>ابدأ الآن</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            <View style={[styles.sideColumn, wide && styles.sideColumnWide]}>
              <View style={styles.howItWorks}>
                <View style={styles.sideHeading}>
                  <MaterialIcons color="#0E7490" name="tips-and-updates" size={20} />
                  <Text style={styles.sideTitle}>كيف يعمل؟</Text>
                </View>
                <View style={styles.stepList}>
                  <View style={styles.stepRow}>
                    <Text style={styles.stepNumber}>1</Text>
                    <Text style={styles.stepText}>حمّل الملف أو الصق النص</Text>
                  </View>
                  <View style={styles.stepRow}>
                    <Text style={styles.stepNumber}>2</Text>
                    <Text style={styles.stepText}>أنشئ الملخص وبنك الأسئلة</Text>
                  </View>
                  <View style={styles.stepRow}>
                    <Text style={styles.stepNumber}>3</Text>
                    <Text style={styles.stepText}>جهّز اختباراً لقياس مستواك</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity activeOpacity={0.85} onPress={() => router.push("/privacy")} style={styles.privacyCard}>
                <MaterialIcons color="#168052" name="verified-user" size={25} />
                <View style={styles.privacyText}>
                  <Text style={styles.privacyTitle}>خصوصيتك أولاً</Text>
                  <Text style={styles.privacyDescription}>يحفظ التطبيق مستنداتك ونتائجك محلياً على جهازك.</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screen: { backgroundColor: "#F4F7FB" },
  scrollContent: { flexGrow: 1, padding: 18, paddingBottom: 34 },
  content: { width: "100%", maxWidth: 1180, alignSelf: "center", gap: 16 },
  hero: { borderRadius: 24, backgroundColor: "#103B57", overflow: "hidden", padding: 24, gap: 22 },
  heroWide: { flexDirection: "row", alignItems: "stretch", padding: 30 },
  heroMain: { flex: 1, gap: 11 },
  brandRow: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 8 },
  brandIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#0B668A" },
  brandLabel: { color: "#CFEAF5", fontSize: 12, fontWeight: "700" },
  heroTitle: { color: "#FFFFFF", fontSize: 31, lineHeight: 40, fontWeight: "800", textAlign: "right" },
  heroDescription: { color: "#D6E7F0", fontSize: 15, lineHeight: 24, maxWidth: 660, textAlign: "right" },
  heroActions: { flexDirection: "row", flexWrap: "wrap", justifyContent: "flex-end", gap: 10, marginTop: 5 },
  primaryHeroButton: { minHeight: 45, paddingHorizontal: 16, borderRadius: 12, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 },
  primaryHeroButtonText: { color: "#08304A", fontSize: 14, fontWeight: "800" },
  secondaryHeroButton: { minHeight: 45, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, borderColor: "#4F7C94", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 },
  secondaryHeroButtonText: { color: "#D4EDF8", fontSize: 14, fontWeight: "800" },
  heroInsight: { borderRadius: 18, padding: 18, alignItems: "center", justifyContent: "center", backgroundColor: "#0A4E70", gap: 4 },
  heroInsightWide: { width: 210 },
  insightIcon: { width: 46, height: 46, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#0B668A", marginBottom: 3 },
  insightValue: { color: "#FFFFFF", fontSize: 28, lineHeight: 33, fontWeight: "800" },
  insightLabel: { color: "#D7EDF7", fontSize: 12, fontWeight: "700", textAlign: "center" },
  insightDivider: { width: "100%", height: 1, backgroundColor: "#3D7895", marginVertical: 7 },
  insightDetail: { color: "#B9DCEB", fontSize: 11, lineHeight: 17, textAlign: "center" },
  statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "space-between" },
  statCard: { width: "48.5%", minHeight: 84, borderRadius: 16, padding: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E1EAF1", flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10 },
  statCardWide: { width: "23.8%" },
  statIcon: { width: 39, height: 39, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  statText: { alignItems: "flex-end" },
  statValue: { color: "#152F45", fontSize: 21, lineHeight: 25, fontWeight: "800" },
  statLabel: { color: "#6A7F90", fontSize: 12, marginTop: 2 },
  workspace: { gap: 16 },
  workspaceWide: { flexDirection: "row", alignItems: "flex-start" },
  primaryColumn: { flex: 1, gap: 16 },
  sideColumn: { gap: 12 },
  sideColumnWide: { width: 278 },
  sectionHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 2 },
  sectionTitle: { color: "#132F45", fontSize: 21, lineHeight: 27, fontWeight: "800", textAlign: "right" },
  sectionDescription: { color: "#708393", fontSize: 13, marginTop: 3, textAlign: "right" },
  sectionDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#0E7490" },
  actionGrid: { flexDirection: "row", flexWrap: "wrap", gap: 11 },
  actionCard: { width: "100%", minHeight: 91, padding: 15, borderRadius: 17, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E0E9F0", flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 12, shadowColor: "#173B56", shadowOpacity: 0.04, shadowRadius: 10, elevation: 1 },
  actionCardWide: { width: "48.9%" },
  actionIcon: { width: 46, height: 46, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  actionText: { flex: 1, alignItems: "flex-end" },
  actionTitle: { color: "#132F45", fontSize: 15, fontWeight: "800", textAlign: "right" },
  actionDescription: { color: "#708393", fontSize: 12, lineHeight: 18, textAlign: "right", marginTop: 3 },
  documentsPanel: { borderRadius: 18, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E0E9F0", padding: 17, gap: 14 },
  panelHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12 },
  panelTitle: { color: "#132F45", fontSize: 17, fontWeight: "800", textAlign: "right" },
  panelSubtitle: { color: "#7A8B99", fontSize: 12, marginTop: 3, textAlign: "right" },
  textButton: { paddingVertical: 7, paddingHorizontal: 2 },
  textButtonLabel: { color: "#0A6C8B", fontSize: 13, fontWeight: "800" },
  documentList: { gap: 8 },
  documentRow: { minHeight: 68, borderRadius: 13, backgroundColor: "#F8FBFD", paddingHorizontal: 12, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10 },
  documentIcon: { width: 37, height: 37, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: "#E7F8FC" },
  documentDetails: { flex: 1, alignItems: "flex-end" },
  documentName: { color: "#1A364C", fontSize: 14, fontWeight: "800", textAlign: "right" },
  documentMeta: { color: "#718493", fontSize: 12, marginTop: 3, textAlign: "right" },
  emptyState: { minHeight: 92, borderRadius: 14, padding: 14, backgroundColor: "#F0FBFD", flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 12 },
  emptyIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#DDF4FA", alignItems: "center", justifyContent: "center" },
  emptyText: { flex: 1, alignItems: "flex-end" },
  emptyTitle: { color: "#17435A", fontSize: 14, fontWeight: "800", textAlign: "right" },
  emptyDescription: { color: "#638092", fontSize: 12, lineHeight: 18, marginTop: 3, textAlign: "right" },
  emptyLink: { color: "#0A6C8B", fontSize: 12, fontWeight: "800" },
  howItWorks: { borderRadius: 18, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E0E9F0", padding: 17, gap: 15 },
  sideHeading: { flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 7 },
  sideTitle: { color: "#173B56", fontSize: 16, fontWeight: "800" },
  stepList: { gap: 13 },
  stepRow: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10 },
  stepNumber: { width: 24, height: 24, borderRadius: 12, overflow: "hidden", textAlign: "center", color: "#FFFFFF", backgroundColor: "#0E7490", fontSize: 12, lineHeight: 24, fontWeight: "800" },
  stepText: { flex: 1, color: "#567084", fontSize: 13, lineHeight: 19, textAlign: "right" },
  privacyCard: { borderRadius: 18, padding: 16, backgroundColor: "#E8F8F0", flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 11 },
  privacyText: { flex: 1, alignItems: "flex-end" },
  privacyTitle: { color: "#116840", fontSize: 14, fontWeight: "800", textAlign: "right" },
  privacyDescription: { color: "#42775F", fontSize: 12, lineHeight: 18, marginTop: 3, textAlign: "right" },
});
