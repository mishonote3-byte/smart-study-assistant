import { useState, useEffect } from 'react';
import { ScrollView, Text, View, TouchableOpacity, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy } from '@/contexts/study-context';

export default function ExamSetupScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ documentId?: string }>();
  const { documents } = useStudy();

  const [selectedDocId, setSelectedDocId] = useState(params.documentId || '');
  const [selectedTypes, setSelectedTypes] = useState<string[]>(['mcq', 'truefalse']);
  const [typeCounts, setTypeCounts] = useState<Record<string, number>>({
    mcq: 70,
    truefalse: 30,
  });
  const [timeLimit, setTimeLimit] = useState(20);

  useEffect(() => {
    if (params.documentId) {
      setSelectedDocId(params.documentId);
    }
  }, [params.documentId]);

  const QUESTION_TYPES = [
    { key: 'mcq', label: 'اختيار من متعدد', icon: '🔘' },
    { key: 'truefalse', label: 'صح أم خطأ', icon: '✅' },
  ];

  const TIME_OPTIONS = [
    { value: 0, label: 'بدون وقت' },
    { value: 10, label: '10 دقائق' },
    { value: 20, label: '20 دقيقة' },
    { value: 30, label: '30 دقيقة' },
    { value: 45, label: '45 دقيقة' },
    { value: 60, label: '60 دقيقة' },
  ];

  const toggleType = (type: string) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const adjustTypeCount = (type: string, delta: number) => {
    setTypeCounts(prev => {
      const current = prev[type] ?? 0;
      const next = Math.max(0, Math.min(300, current + delta));
      return { ...prev, [type]: next };
    });
  };

  const totalCount = selectedTypes.reduce((total, type) => total + (typeCounts[type] || 0), 0);

  const selectedDoc = documents.find(d => d.id === selectedDocId);
  const availableQuestions = selectedDoc?.questionBank?.filter(q => selectedTypes.includes(q.type)) || [];

  const startExam = () => {
    if (!selectedDocId) {
      Alert.alert('تنبيه', 'يرجى اختيار مستند');
      return;
    }
    if (selectedTypes.length === 0) {
      Alert.alert('تنبيه', 'يرجى اختيار نوع سؤال واحد على الأقل');
      return;
    }
    if (totalCount === 0) {
      Alert.alert('تنبيه', 'يرجى وضع سؤال واحد على الأقل في نوع من الأنواع');
      return;
    }
    if (availableQuestions.length === 0) {
      Alert.alert('تنبيه', 'لا توجد أسئلة متاحة. قم بتوليد أسئلة من المستند أولاً.');
      return;
    }

    const actualCount = Math.min(totalCount, availableQuestions.length);

    router.push({
      pathname: '/exam' as any,
      params: {
        documentId: selectedDocId,
        questionCount: actualCount.toString(),
        timeLimit: timeLimit.toString(),
        questionTypes: selectedTypes.join(','),
        typeCounts: JSON.stringify(
          selectedTypes.reduce((counts, type) => ({ ...counts, [type]: typeCounts[type] || 1 }), {} as Record<string, number>)
        ),
      },
    });
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-4">
        <View className="items-center py-2">
          <Text className="text-2xl font-bold" style={{ color: '#1B4F72' }}>إعداد الامتحان</Text>
          <Text className="text-sm mt-1" style={{ color: '#7F8C8D' }}>اختر المستند وحدد إعدادات الامتحان</Text>
        </View>

        {/* Document Selection */}
        <View className="gap-2">
          <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>اختر المستند</Text>
          {documents.length === 0 ? (
            <View className="p-4 rounded-xl items-center" style={{ backgroundColor: '#F3F4F6' }}>
              <Text className="text-sm" style={{ color: '#E74C3C' }}>لا توجد مستندات. ارفع مستنداً أولاً.</Text>
            </View>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View className="flex-row gap-2">
                {documents.map(doc => (
                  <TouchableOpacity
                    key={doc.id}
                    onPress={() => setSelectedDocId(doc.id)}
                    className="px-5 py-3 rounded-xl items-center"
                    style={{
                      backgroundColor: selectedDocId === doc.id ? '#1B4F72' : '#F3F4F6',
                      minWidth: 100,
                      borderWidth: selectedDocId === doc.id ? 0 : 1,
                      borderColor: '#E5E7EB',
                    }}
                  >
                    <Text className="text-xs font-bold" style={{ color: selectedDocId === doc.id ? '#FFFFFF' : '#7F8C8D' }} numberOfLines={1}>
                      {doc.name}
                    </Text>
                    <Text className="text-xs mt-1" style={{ color: selectedDocId === doc.id ? '#B0C4DE' : '#BDC3C7' }}>
                      {doc.questionBank?.length || 0} سؤال
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          )}
        </View>

        {/* Question Types */}
        <View className="gap-2">
          <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>أنواع الأسئلة</Text>
          <View className="gap-2">
            {QUESTION_TYPES.map(type => (
              <TouchableOpacity
                key={type.key}
                onPress={() => toggleType(type.key)}
                className="flex-row items-center justify-between p-4 rounded-xl"
                style={{
                  backgroundColor: selectedTypes.includes(type.key) ? '#E8F4FD' : '#FFFFFF',
                  borderWidth: 1.5,
                  borderColor: selectedTypes.includes(type.key) ? '#1B4F72' : '#E5E7EB',
                }}
              >
                <View className="flex-row items-center gap-3">
                  <Text className="text-lg">{type.icon}</Text>
                  <Text className="text-sm font-bold" style={{ color: selectedTypes.includes(type.key) ? '#1B4F72' : '#7F8C8D' }}>
                    {type.label}
                  </Text>
                </View>
                <View className="w-7 h-7 rounded-full items-center justify-center" style={{ backgroundColor: selectedTypes.includes(type.key) ? '#1B4F72' : '#E5E7EB' }}>
                  {selectedTypes.includes(type.key) && <Text className="text-white text-xs font-bold">✓</Text>}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Question Count per Type */}
        <View className="gap-2">
          <View className="flex-row items-center justify-between">
            <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>عدد الأسئلة لكل نوع</Text>
            <Text className="font-bold text-sm" style={{ color: '#27AE60' }}>الإجمالي: {totalCount}</Text>
          </View>
          {QUESTION_TYPES.map(type => (
            <View
              key={`count-${type.key}`}
              className="flex-row items-center justify-between p-3 rounded-xl"
              style={{
                backgroundColor: selectedTypes.includes(type.key) ? '#E8F4FD' : '#F8F9FA',
                borderWidth: 1,
                borderColor: selectedTypes.includes(type.key) ? '#1B4F72' : '#E5E7EB',
              }}
            >
              <TouchableOpacity
                onPress={() => toggleType(type.key)}
                className="w-7 h-7 rounded-full items-center justify-center"
                style={{ backgroundColor: selectedTypes.includes(type.key) ? '#1B4F72' : '#E5E7EB' }}
              >
                {selectedTypes.includes(type.key) && <Text className="text-white text-xs font-bold">✓</Text>}
              </TouchableOpacity>
              <Text className="text-xs font-bold flex-1 text-center" style={{ color: selectedTypes.includes(type.key) ? '#1B4F72' : '#BDC3C7' }}>
                {type.icon} {type.label}
              </Text>
              <View className="flex-row items-center gap-3">
                <TouchableOpacity
                  onPress={() => adjustTypeCount(type.key, -1)}
                  disabled={!selectedTypes.includes(type.key)}
                  className="w-8 h-8 rounded-lg items-center justify-center"
                  style={{ backgroundColor: selectedTypes.includes(type.key) ? '#F3F4F6' : '#F8F9FA' }}
                >
                  <Text className="text-lg font-bold" style={{ color: selectedTypes.includes(type.key) ? '#1B4F72' : '#D5D8DC' }}>-</Text>
                </TouchableOpacity>
                <Text className="text-lg font-bold w-8 text-center" style={{ color: selectedTypes.includes(type.key) ? '#1B4F72' : '#D5D8DC' }}>
                  {typeCounts[type.key] || 0}
                </Text>
                <TouchableOpacity
                  onPress={() => adjustTypeCount(type.key, 1)}
                  disabled={!selectedTypes.includes(type.key)}
                  className="w-8 h-8 rounded-lg items-center justify-center"
                  style={{ backgroundColor: selectedTypes.includes(type.key) ? '#F3F4F6' : '#F8F9FA' }}
                >
                  <Text className="text-lg font-bold" style={{ color: selectedTypes.includes(type.key) ? '#1B4F72' : '#D5D8DC' }}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
          {selectedDoc && availableQuestions.length > 0 && (
            <Text className="text-xs text-center" style={{ color: '#7F8C8D' }}>
              متاح: {availableQuestions.length} سؤال
            </Text>
          )}
        </View>

        {/* Time Limit */}
        <View className="gap-2">
          <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>الوقت المحدد</Text>
          <View className="flex-row flex-wrap gap-2 justify-center">
            {TIME_OPTIONS.map(opt => (
              <TouchableOpacity
                key={opt.value}
                onPress={() => setTimeLimit(opt.value)}
                className="px-5 py-3 rounded-xl"
                style={{ backgroundColor: timeLimit === opt.value ? '#1B4F72' : '#F3F4F6' }}
              >
                <Text className="text-xs font-bold" style={{ color: timeLimit === opt.value ? '#FFFFFF' : '#7F8C8D' }}>
                  {opt.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Start Exam Button */}
        <TouchableOpacity
          onPress={startExam}
          className="py-5 rounded-2xl items-center"
          style={{ backgroundColor: '#27AE60' }}
        >
          <Text className="text-white font-bold text-lg">🚀 بدء الامتحان</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
