import React, { useState, useCallback, useRef } from 'react';
import { ScrollView, Text, View, TouchableOpacity, Pressable, TextInput, Alert, ActivityIndicator, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy } from '@/contexts/study-context';
import { trpc } from '@/lib/trpc';
import { getApiBaseUrl } from '@/constants/oauth';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import type { StructuredDocument } from '@/shared/study';

type PendingFile = {
  fileName: string;
  mimeType?: string | null;
  fileData?: string;
  filePath?: string;
  binaryFile?: any;
};

const isPdfFile = (fileName: string, mimeType?: string | null) =>
  mimeType === 'application/pdf' || fileName.toLowerCase().endsWith('.pdf');

type ProcessedFileResult = {
  text: string;
  pageCount?: number;
  extractedPageFrom?: number;
  extractedPageTo?: number;
  structuredDocument?: StructuredDocument;
};

const PAGE_BATCH_SIZE = 3;
const isFailedExtractionText = (text: string) =>
  text.startsWith('[لم يتم') || text.startsWith('[تعذّرت') || text.startsWith('تعذّرت معالجة');

export default function UploadScreen() {
  const router = useRouter();
  const { documents, addDocument, updateDocument, deleteDocument } = useStudy();
  const [manualText, setManualText] = useState('');
  const [manualName, setManualName] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [uploadProgress, setUploadProgress] = useState('');
  const [generating, setGenerating] = useState<string | null>(null);
  const [pendingPdf, setPendingPdf] = useState<PendingFile | null>(null);
  const [pageSelectionMode, setPageSelectionMode] = useState<'all' | 'range'>('all');
  const [pageFrom, setPageFrom] = useState('1');
  const [pageTo, setPageTo] = useState('');
  const webFileInputRef = useRef<any>(null);

  const processFileMutation = trpc.study.processDocument.useMutation();
  const generateQuestionsMutation = trpc.study.generateQuestions.useMutation();

  const processFileContent = useCallback(async ({
    fileName,
    mimeType,
    fileData,
    filePath,
    binaryFile,
    pageFrom: requestedPageFrom,
    pageTo: requestedPageTo,
  }: {
    fileName: string;
    mimeType?: string | null;
    fileData?: string;
    filePath?: string;
    binaryFile?: any;
    pageFrom?: number;
    pageTo?: number;
  }) => {
    setUploading(true);
    setUploadError('');
    setUploadProgress('يتم تجهيز الملف للقراءة الآن…');
    const documentName = fileName || 'مستند مرفوع';
    const normalizedName = documentName.trim().toLocaleLowerCase();
    const existingDocument = documents.find((document) =>
      document.name.trim().toLocaleLowerCase() === normalizedName
      && document.mimeType === (mimeType || undefined),
    );
    const processingDocument = {
      name: documentName,
      text: 'جارٍ استخراج النص من الملف. ستظهر المادة هنا تلقائياً فور اكتمال المعالجة.',
      filePath,
      mimeType: mimeType || undefined,
      processingState: 'processing' as const,
      processingMessage: requestedPageFrom
        ? `يتم استخراج النص من الصفحات ${requestedPageFrom} إلى ${requestedPageTo || 'الأخيرة'} الآن.`
        : 'يتم استخراج النص من جميع صفحات الملف الآن. يمكنك العودة إلى قائمة المستندات؛ لن تفقد العملية.',
      summary: undefined,
      explanation: undefined,
      questionBank: undefined,
    };
    const docId = existingDocument
      ? existingDocument.id
      : await addDocument(processingDocument);
    if (existingDocument) await updateDocument(docId, processingDocument);

    try {
      const payload = {
        fileName,
        mimeType: mimeType || 'text/plain',
        fileData: fileData || '',
        pageFrom: requestedPageFrom,
        pageTo: requestedPageTo,
      };
      const uploadBinary = async (rangeFrom = requestedPageFrom, rangeTo = requestedPageTo): Promise<ProcessedFileResult> => {
        const headers: Record<string, string> = {
          'content-type': 'application/octet-stream',
          'x-file-name': encodeURIComponent(fileName),
          'x-mime-type': mimeType || 'application/octet-stream',
        };
        if (rangeFrom) headers['x-page-from'] = String(rangeFrom);
        if (rangeTo) headers['x-page-to'] = String(rangeTo);

        if (Platform.OS === 'web') {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 8 * 60_000);
          try {
            const response = await fetch(`${getApiBaseUrl()}/api/document/upload`, {
              method: 'POST', headers, body: binaryFile, signal: controller.signal, credentials: 'include',
            });
            const body = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(body.error || 'تعذرت معالجة الملف.');
            return body as ProcessedFileResult;
          } finally { clearTimeout(timer); }
        }

        if (!filePath) throw new Error('تعذر الوصول إلى الملف المختار. اختره مرة أخرى.');
        const response = await FileSystem.uploadAsync(`${getApiBaseUrl()}/api/document/upload`, filePath, {
          httpMethod: 'POST', uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT, headers,
        });
        const body = JSON.parse(response.body || '{}');
        if (response.status < 200 || response.status >= 300) throw new Error(body.error || 'تعذرت معالجة الملف.');
        return body as ProcessedFileResult;
      };

      const hasBinaryUpload = Boolean(binaryFile || filePath);
      let processed: ProcessedFileResult;
      if (hasBinaryUpload && isPdfFile(fileName, mimeType)) {
        const firstPage = requestedPageFrom || 1;
        const firstBatchEnd = requestedPageTo
          ? Math.min(firstPage + PAGE_BATCH_SIZE - 1, requestedPageTo)
          : firstPage + PAGE_BATCH_SIZE - 1;
        const uploadPdfBatch = async (rangeFrom: number, rangeTo: number): Promise<ProcessedFileResult> => {
          let lastError: unknown;
          for (let attempt = 1; attempt <= 2; attempt += 1) {
            setUploadProgress(`يتم استخراج الصفحات ${rangeFrom}–${rangeTo} (المحاولة ${attempt} من 2).`);
            try {
              const batchResult = await uploadBinary(rangeFrom, rangeTo);
              setUploadProgress(`اكتمل استخراج الصفحات ${rangeFrom}–${rangeTo}.`);
              return batchResult;
            } catch (chunkError) {
              lastError = chunkError;
              if (attempt < 2) setUploadProgress(`تتم إعادة محاولة الصفحات ${rangeFrom}–${rangeTo} الآن.`);
            }
          }
          throw lastError instanceof Error ? lastError : new Error(`تعذر استخراج الصفحات ${rangeFrom}–${rangeTo}.`);
        };

        const firstBatch = await uploadPdfBatch(firstPage, firstBatchEnd);
        const documentLastPage = Math.min(
          requestedPageTo || firstBatch.pageCount || firstBatchEnd,
          firstBatch.pageCount || requestedPageTo || firstBatchEnd,
        );
        const extractedChunks = [firstBatch.text];
        const structuredPages = [...(firstBatch.structuredDocument?.pages || [])];

        for (let currentPage = firstBatchEnd + 1; currentPage <= documentLastPage; currentPage += PAGE_BATCH_SIZE) {
          const batchEnd = Math.min(currentPage + PAGE_BATCH_SIZE - 1, documentLastPage);
          await updateDocument(docId, {
            processingState: 'processing',
            processingMessage: `يتم استخراج النص من الصفحات ${currentPage}–${batchEnd} من أصل ${documentLastPage}.`,
          });

          try {
            const batch = await uploadPdfBatch(currentPage, batchEnd);
            extractedChunks.push(batch.text);
            structuredPages.push(...(batch.structuredDocument?.pages || []));
          } catch {
            extractedChunks.push(`[الصفحات ${currentPage}–${batchEnd}: تعذّر استخراج النص بعد إعادة المحاولة.]`);
          }
        }

        const averageConfidence = structuredPages.length
          ? structuredPages.reduce((sum, page) => sum + page.confidence, 0) / structuredPages.length
          : 0;
        processed = {
          text: extractedChunks.filter(Boolean).join('\n\n').trim(),
          pageCount: firstBatch.pageCount,
          extractedPageFrom: firstPage,
          extractedPageTo: documentLastPage,
          structuredDocument: structuredPages.length ? {
            version: 1,
            totalPages: firstBatch.pageCount || structuredPages.length,
            extractedPageFrom: firstPage,
            extractedPageTo: documentLastPage,
            pages: structuredPages,
            plainText: extractedChunks.filter(Boolean).join('\n\n').trim(),
            quality: {
              readablePages: structuredPages.filter(page => page.text.trim().length >= 20).length,
              ocrPages: structuredPages.filter(page => page.blocks.some(block => block.source === 'ocr')).length,
              tablePages: structuredPages.filter(page => page.blocks.some(block => block.type === 'table')).length,
              warningPages: structuredPages.filter(page => page.warnings.length > 0).length,
              averageConfidence: Number(averageConfidence.toFixed(2)),
            },
          } : undefined,
        };
      } else {
        processed = hasBinaryUpload ? await uploadBinary() : await processFileMutation.mutateAsync(payload);
      }

      const text = processed.text || '';
      const failed = isFailedExtractionText(text);
      await updateDocument(docId, {
        text,
        processingState: failed ? 'failed' : 'ready',
        processingMessage: failed ? 'تعذر استخراج النص. جرّب صورة أو ملفاً أوضح.' : undefined,
        pageCount: processed.pageCount,
        extractedPageFrom: processed.extractedPageFrom,
        extractedPageTo: processed.extractedPageTo,
        structuredDocument: processed.structuredDocument,
      });
      if (failed || text.trim().length < 20) {
        router.push({ pathname: '/document-view' as any, params: { id: docId } });
      } else {
        setUploadProgress('تمت قراءة الملف. يجري تحويله إلى أسئلة الامتحان…');
        try {
          const questions = await generateQuestionsMutation.mutateAsync({
            text, documentId: docId, questionCount: 150,
            typeCounts: { mcq: 105, truefalse: 45 },
          });
          if (!questions.length) throw new Error('لم ينتج الملف أسئلة قابلة للاستخدام.');
          await updateDocument(docId, {
            questionBank: questions.map((q: any, i: number) => ({
              id: q.id || `q${i + 1}`, type: q.type, question: q.question,
              answer: q.answer, options: q.options, correctAnswer: q.correctAnswer,
              pairs: q.pairs, hint: q.hint, sourcePage: q.sourcePage,
              sourceQuote: q.sourceQuote, documentId: docId,
            })),
          });
          router.push({ pathname: '/qa-exam' as any, params: { documentId: docId } });
        } catch (questionError: any) {
          const message = questionError?.message || 'تعذر تحويل الملف إلى امتحان. يمكنك إعادة المحاولة من صفحة المستند.';
          setUploadError(message);
          await updateDocument(docId, { processingMessage: `تعذر إنشاء الأسئلة: ${message}` });
          router.push({ pathname: '/document-view' as any, params: { id: docId } });
        }
      }
    } catch (err: any) {
      const message = err?.name === 'AbortError'
        ? 'ما زالت المعالجة تستغرق وقتاً طويلاً. جرّب اختيار نطاق صفحات محدد؛ لا يلزم تصغير الملف.'
        : err?.message || 'تعذرت معالجة الملف. جرّب ملفاً آخر أو أدخل النص يدوياً.';
      setUploadError(message);
      await updateDocument(docId, {
        text: 'تعذرت معالجة الملف. جرّب اختيار نطاق صفحات محدد أو صورة واضحة، أو أدخل النص يدوياً.',
        processingState: 'failed',
        processingMessage: message,
      });
      router.push({ pathname: '/document-view' as any, params: { id: docId } });
    } finally {
      setUploading(false);
      setUploadProgress('');
    }
  }, [processFileMutation, generateQuestionsMutation, addDocument, documents, updateDocument, router]);

  const prepareOrProcessFile = useCallback((file: PendingFile) => {
    setSelectedFileName(file.fileName || 'مستند مرفوع');
    setUploadError('');
    if (isPdfFile(file.fileName, file.mimeType)) {
      setPendingPdf(file);
      setPageSelectionMode('all');
      setPageFrom('1');
      setPageTo('');
      return;
    }
    void processFileContent(file);
  }, [processFileContent]);

  const confirmPdfPageSelection = useCallback(() => {
    if (!pendingPdf) return;
    const start = Number.parseInt(pageFrom, 10);
    const end = Number.parseInt(pageTo, 10);
    if (pageSelectionMode === 'range' && (!Number.isInteger(start) || start < 1 || !Number.isInteger(end) || end < start)) {
      Alert.alert('نطاق صفحات غير صالح', 'أدخل رقم صفحة بداية صحيحاً ثم رقم نهاية مساوياً له أو أكبر منه.');
      return;
    }
    const file = pendingPdf;
    setPendingPdf(null);
    void processFileContent({
      ...file,
      pageFrom: pageSelectionMode === 'range' ? start : undefined,
      pageTo: pageSelectionMode === 'range' ? end : undefined,
    });
  }, [pageFrom, pageSelectionMode, pageTo, pendingPdf, processFileContent]);

  const handleFilePick = useCallback(async () => {
    if (Platform.OS === 'web') {
      webFileInputRef.current?.click();
      return;
    }

    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'],
        copyToCacheDirectory: true,
      });
      if (result.canceled) return;
      const file = result.assets[0];
      if (!file) return;

      prepareOrProcessFile({
        fileName: file.name || 'document',
        mimeType: file.mimeType,
        filePath: file.uri,
      });
    } catch (err: any) {
      const message = err?.message || 'لم يتم اختيار ملف صالح';
      setUploadError(message);
      Alert.alert('تعذر اختيار الملف', message);
    }
  }, [prepareOrProcessFile]);

  const handleWebFileChange = useCallback((event: any) => {
    const file = event?.target?.files?.[0];
    if (!file) return;

    setUploadError('');
    prepareOrProcessFile({
      fileName: file.name || 'document',
      mimeType: file.type || 'text/plain',
      binaryFile: file,
    });
    event.target.value = '';
  }, [prepareOrProcessFile]);

  const handleAddManual = useCallback(() => {
    if (!manualText.trim()) {
      Alert.alert('تنبيه', 'يرجى إدخال نص المستند');
      return;
    }
    addDocument({ name: manualName || 'مستند يدوي', text: manualText }).then(id => {
      setManualText('');
      setManualName('');
      router.push({ pathname: '/document-view' as any, params: { id } });
    });
  }, [manualText, manualName, addDocument, router]);

  const handleGenerateQuestions = async (docId: string) => {
    setGenerating(docId);
    try {
      const currentDoc = documents.find(d => d.id === docId);
      const questions = await generateQuestionsMutation.mutateAsync({
        text: currentDoc?.text || '',
        documentId: docId,
        questionCount: 150,
        typeCounts: { mcq: 105, truefalse: 45 },
      });
      await updateDocument(docId, {
        questionBank: questions.map((q: any, i: number) => ({
          id: q.id || `q${i + 1}`,
          type: q.type,
          question: q.question,
          answer: q.answer,
          options: q.options,
          correctAnswer: q.correctAnswer,
          pairs: q.pairs,
          hint: q.hint,
          sourcePage: q.sourcePage,
          sourceQuote: q.sourceQuote,
          documentId: docId,
        })),
      });
      Alert.alert('تم', 'تم توليد بنك الأسئلة بنجاح');
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'حدث خطأ');
    } finally {
      setGenerating(null);
    }
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-6">
        <View className="items-center py-2">
          <Text className="text-2xl font-bold" style={{ color: '#1B4F72' }}>رفع المستندات</Text>
          <Text className="text-sm mt-1" style={{ color: '#7F8C8D' }}>ارفع ملفاتك أو أدخل النص يدوياً</Text>
        </View>

        {/* File Upload */}
        <View style={{ backgroundColor: '#1B4F72', borderRadius: 16, padding: 18, gap: 10 }}>
          <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '700', textAlign: 'center' }}>رفع ملف</Text>
          <Text style={{ color: '#D8E7F4', fontSize: 13, textAlign: 'center' }}>PDF أو Word أو صورة JPG/PNG</Text>
          {Platform.OS === 'web' ? (
            React.createElement('input', {
              ref: webFileInputRef,
              type: 'file',
              accept: '.pdf,.docx,image/jpeg,image/png',
              onChange: handleWebFileChange,
              disabled: uploading,
              'aria-label': 'اختيار ملف للدراسة',
              style: {
                width: '100%',
                padding: '12px',
                color: '#17324D',
                background: '#FFFFFF',
                borderRadius: '10px',
                border: '1px solid #B0C4DE',
                cursor: uploading ? 'wait' : 'pointer',
              },
            })
          ) : (
            <Pressable
              onPress={handleFilePick}
              disabled={uploading}
              accessibilityRole="button"
              accessibilityLabel="اختيار ملف للدراسة"
              style={({ pressed }) => ({
                backgroundColor: '#FFFFFF',
                borderRadius: 10,
                paddingVertical: 13,
                alignItems: 'center',
                opacity: uploading ? 0.65 : pressed ? 0.85 : 1,
              })}
            >
              {uploading ? <ActivityIndicator color="#1B4F72" /> : <Text style={{ color: '#1B4F72', fontWeight: '700' }}>اختيار ملف</Text>}
            </Pressable>
          )}
          {uploading && <View style={{ alignItems: 'center', gap: 8 }}><ActivityIndicator color="#FFFFFF" /><Text style={{ color: '#FFFFFF', textAlign: 'center' }}>{uploadProgress || 'يجري قراءة الملف واستخراج النص الآن…'}</Text><Text style={{ color: '#D8E7F4', textAlign: 'center', fontSize: 12 }}>قد تستغرق المستندات الممسوحة الطويلة عدة دقائق، ولا يلزم تصغير الملف.</Text></View>}
          {pendingPdf && !uploading && (
            <View style={{ backgroundColor: '#FFFFFF', borderRadius: 12, padding: 14, gap: 10 }}>
              <Text style={{ color: '#1B4F72', fontWeight: '700', textAlign: 'right' }}>اختر الصفحات المطلوب تحليلها</Text>
              <Text style={{ color: '#7F8C8D', fontSize: 12, textAlign: 'right' }}>
                يمكنك تحليل الملف كاملاً أو الاقتصار على فصل أو نطاق محدد.
              </Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Pressable
                  onPress={() => setPageSelectionMode('all')}
                  style={({ pressed }) => ({ flex: 1, backgroundColor: pageSelectionMode === 'all' ? '#1B4F72' : '#F3F4F6', borderRadius: 8, padding: 10, opacity: pressed ? 0.85 : 1 })}
                >
                  <Text style={{ color: pageSelectionMode === 'all' ? '#FFFFFF' : '#1B4F72', fontWeight: '700', textAlign: 'center', fontSize: 12 }}>كل الصفحات</Text>
                </Pressable>
                <Pressable
                  onPress={() => setPageSelectionMode('range')}
                  style={({ pressed }) => ({ flex: 1, backgroundColor: pageSelectionMode === 'range' ? '#1B4F72' : '#F3F4F6', borderRadius: 8, padding: 10, opacity: pressed ? 0.85 : 1 })}
                >
                  <Text style={{ color: pageSelectionMode === 'range' ? '#FFFFFF' : '#1B4F72', fontWeight: '700', textAlign: 'center', fontSize: 12 }}>نطاق صفحات</Text>
                </Pressable>
              </View>
              {pageSelectionMode === 'range' && (
                <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                  <TextInput value={pageFrom} onChangeText={setPageFrom} keyboardType="number-pad" placeholder="من" style={{ flex: 1, borderWidth: 1, borderColor: '#D9E2EC', borderRadius: 8, padding: 10, textAlign: 'center', color: '#2C3E50' }} />
                  <Text style={{ color: '#7F8C8D' }}>إلى</Text>
                  <TextInput value={pageTo} onChangeText={setPageTo} keyboardType="number-pad" placeholder="إلى" style={{ flex: 1, borderWidth: 1, borderColor: '#D9E2EC', borderRadius: 8, padding: 10, textAlign: 'center', color: '#2C3E50' }} />
                </View>
              )}
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Pressable
                  onPress={() => setPendingPdf(null)}
                  style={({ pressed }) => ({ flex: 1, borderRadius: 8, padding: 11, alignItems: 'center', backgroundColor: '#FDEDEC', opacity: pressed ? 0.85 : 1 })}
                >
                  <Text style={{ color: '#E74C3C', fontWeight: '700' }}>إلغاء</Text>
                </Pressable>
                <Pressable
                  onPress={confirmPdfPageSelection}
                  style={({ pressed }) => ({ flex: 1, borderRadius: 8, padding: 11, alignItems: 'center', backgroundColor: '#27AE60', opacity: pressed ? 0.85 : 1 })}
                >
                  <Text style={{ color: '#FFFFFF', fontWeight: '700' }}>بدء التحليل</Text>
                </Pressable>
              </View>
            </View>
          )}
          {!!selectedFileName && !uploading && <Text style={{ color: '#D8E7F4', fontSize: 12, textAlign: 'center' }}>الملف المختار: {selectedFileName}</Text>}
          {!!uploadError && <Text style={{ color: '#FDE2E2', fontSize: 12, textAlign: 'center' }}>{uploadError}</Text>}
        </View>

        {/* Manual Input */}
        <View className="gap-3">
          <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>إدخال نص يدوي</Text>
          <TextInput
            value={manualName}
            onChangeText={setManualName}
            placeholder="اسم المستند"
            className="p-4 rounded-xl text-base"
            style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB', color: '#2C3E50' }}
          />
          <TextInput
            value={manualText}
            onChangeText={setManualText}
            placeholder="الصق النص هنا أو اكتبه..."
            multiline
            numberOfLines={10}
            className="p-4 rounded-xl text-base"
            style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB', color: '#2C3E50', minHeight: 180 }}
          />
          <Pressable
            onPress={handleAddManual}
            accessibilityRole="button"
            accessibilityLabel="إضافة المستند اليدوي"
            style={({ pressed }) => ({ backgroundColor: '#27AE60', borderRadius: 12, paddingVertical: 16, alignItems: 'center', opacity: pressed ? 0.85 : 1 })}
          >
            <Text className="text-white font-bold text-base">إضافة المستند</Text>
          </Pressable>
        </View>

        {/* Document List */}
        {documents.length > 0 && (
          <View className="gap-3">
            <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>مستنداتك ({documents.length})</Text>
            {documents.map(doc => (
              <View key={doc.id} className="rounded-xl overflow-hidden" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                <TouchableOpacity
                  onPress={() => router.push({ pathname: '/document-view' as any, params: { id: doc.id } })}
                  className="p-4"
                >
                  <View className="flex-row items-center justify-between">
                    <View className="flex-1">
                      <Text className="text-base font-bold" style={{ color: '#2C3E50' }}>{doc.name}</Text>
                      <Text className="text-xs mt-1" style={{ color: '#7F8C8D' }}>
                        {doc.questionBank?.length || 0} سؤال | {doc.summary ? '✓ ملخص' : 'بدون ملخص'}
                      </Text>
                      <Text className="text-xs mt-1" style={{ color: '#BDC3C7' }}>
                        {new Date(doc.createdAt).toLocaleDateString('ar-EG')}
                      </Text>
                    </View>
                    <Text className="text-2xl">←</Text>
                  </View>
                </TouchableOpacity>

                <View className="flex-row border-t" style={{ borderColor: '#E5E7EB' }}>
                  <TouchableOpacity
                    onPress={() => handleGenerateQuestions(doc.id)}
                    disabled={generating === doc.id}
                    className="flex-1 py-3 items-center"
                    style={{ borderRightWidth: 0.5, borderRightColor: '#E5E7EB' }}
                  >
                    {generating === doc.id ? (
                      <ActivityIndicator size="small" color="#1B4F72" />
                    ) : (
                      <Text className="text-xs font-bold" style={{ color: '#1B4F72' }}>توليد أسئلة</Text>
                    )}
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      Alert.alert('حذف', `حذف "${doc.name}"؟`, [
                        { text: 'إلغاء', style: 'cancel' },
                        { text: 'حذف', style: 'destructive', onPress: () => deleteDocument(doc.id) },
                      ]);
                    }}
                    className="flex-1 py-3 items-center"
                  >
                    <Text className="text-xs font-bold" style={{ color: '#E74C3C' }}>حذف</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
