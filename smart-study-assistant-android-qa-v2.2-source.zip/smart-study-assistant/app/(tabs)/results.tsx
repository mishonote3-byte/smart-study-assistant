import { useState } from 'react';
import { ScrollView, Text, View, TouchableOpacity, Alert, Share } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy } from '@/contexts/study-context';

export default function ResultsScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ justFinished?: string }>();
  const { examResults } = useStudy();
  const justFinished = params.justFinished === 'true';
  const [expandedResults, setExpandedResults] = useState<Record<string, boolean>>({});

  const handleShareResult = async (result: typeof examResults[0]) => {
    const score = Math.round((result.score / Math.max(result.totalQuestions, 1)) * 100);
    try {
      await Share.share({
        message: `📊 نتيجة امتحان: ${result.documentName}\n🎯 النتيجة: ${result.score}/${result.totalQuestions}\n📈 النسبة: ${score}%`,
      });
    } catch { /* cancelled */ }
  };

  const handleDeleteResult = (index: number) => {
    Alert.alert('حذف', 'حذف هذه النتيجة؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive' },
    ]);
  };

  const TYPE_LABELS: Record<string, string> = {
    mcq: 'اختيار من متعدد',
    fill: 'أكمل العبارات',
    truefalse: 'صح أم خطأ',
    enumerate: 'اذكر / عدّد',
    reason: 'علل',
    matching: 'طابق',
  };

  const formatAnswer = (answer: unknown) => {
    if (answer === null || answer === undefined || String(answer).trim() === '') return 'لم تتم الإجابة';
    if (typeof answer === 'object' && !Array.isArray(answer)) {
      const pairs = Object.entries(answer as Record<string, string>);
      return pairs.length ? pairs.map(([left, right]) => `${left} ← ${right}`).join('\n') : 'لم تتم الإجابة';
    }
    return String(answer);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-4">
        <View className="items-center py-2">
          <Text className="text-2xl font-bold" style={{ color: '#1B4F72' }}>نتائج الامتحانات</Text>
          <Text className="text-sm mt-1" style={{ color: '#7F8C8D' }}>
            {examResults.length} امتحان {justFinished && '• تم الانتهاء للتو'}
          </Text>
        </View>

        {/* Summary Stats */}
        {examResults.length > 0 && (
          <View className="flex-row gap-3">
            <View className="flex-1 p-3 rounded-xl items-center" style={{ backgroundColor: '#E8F4FD' }}>
              <Text className="text-xl font-bold" style={{ color: '#1B4F72' }}>{examResults.length}</Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>امتحان</Text>
            </View>
            <View className="flex-1 p-3 rounded-xl items-center" style={{ backgroundColor: '#F0FFF0' }}>
              <Text className="text-xl font-bold" style={{ color: '#27AE60' }}>
                {Math.round(examResults.reduce((a, r) => a + (r.score / Math.max(r.totalQuestions, 1)) * 100, 0) / examResults.length)}%
              </Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>المتوسط</Text>
            </View>
            <View className="flex-1 p-3 rounded-xl items-center" style={{ backgroundColor: '#FFF8E1' }}>
              <Text className="text-xl font-bold" style={{ color: '#F39C12' }}>
                {Math.max(...examResults.map(r => Math.round((r.score / Math.max(r.totalQuestions, 1)) * 100)))}%
              </Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>الأعلى</Text>
            </View>
          </View>
        )}

        {examResults.length === 0 ? (
          <View className="items-center py-16">
            <Text className="text-4xl mb-4">📊</Text>
            <Text className="text-lg mb-2" style={{ color: '#7F8C8D' }}>لا توجد نتائج بعد</Text>
            <Text className="text-sm" style={{ color: '#BDC3C7' }}>أدِ امتحاناً لتحصل على نتائجك هنا</Text>
            <TouchableOpacity
              onPress={() => router.push('/(tabs)/exam-setup' as any)}
              className="mt-6 py-3 px-8 rounded-xl"
              style={{ backgroundColor: '#1B4F72' }}
            >
              <Text className="text-white font-bold">بدء امتحان</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View className="gap-4">
            {examResults.map((result, index) => {
              const score = Math.round((result.score / Math.max(result.totalQuestions, 1)) * 100);
              const isPass = score >= 50;
              const isExpanded = expandedResults[result.id] ?? (justFinished && index === 0);

              return (
                <View key={index} className="rounded-2xl overflow-hidden" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                  {/* Result Header */}
                  <View className="p-4" style={{ backgroundColor: isPass ? '#F0FFF0' : '#FDEDEC' }}>
                    <View className="flex-row items-center justify-between">
                      <View>
                        <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>{result.documentName}</Text>
                        <Text className="text-xs mt-1" style={{ color: '#7F8C8D' }}>
                          {result.totalQuestions} سؤال | {new Date(result.createdAt).toLocaleDateString('ar-EG')}
                        </Text>
                      </View>
                      <View className="items-center">
                        <Text className="text-2xl font-bold" style={{ color: isPass ? '#27AE60' : '#E74C3C' }}>
                          {score}%
                        </Text>
                        <Text className="text-xs" style={{ color: '#7F8C8D' }}>
                          {result.score}/{result.totalQuestions}
                        </Text>
                      </View>
                    </View>

                    {/* Score Bar */}
                    <View className="mt-3 h-3 rounded-full" style={{ backgroundColor: '#E5E7EB' }}>
                      <View
                        className="h-3 rounded-full"
                        style={{
                          backgroundColor: isPass ? '#27AE60' : '#E74C3C',
                          width: `${Math.min(score, 100)}%`,
                        }}
                      />
                    </View>
                  </View>

                  {/* Essay Scores */}
                  {result.essayScores && Object.keys(result.essayScores).length > 0 && (
                    <View className="p-4 gap-2 border-t" style={{ borderColor: '#E5E7EB' }}>
                      <Text className="text-xs font-bold mb-1" style={{ color: '#1B4F72' }}>تقييم الأسئلة المقالية:</Text>
                      {Object.entries(result.essayScores).map(([qId, grade]) => (
                        <View key={qId} className="flex-row items-center justify-between py-1">
                          <Text className="text-xs" style={{ color: '#7F8C8D' }}>سؤال مقالي</Text>
                          <View className="flex-row items-center gap-2">
                            <Text className="text-xs font-bold" style={{ color: grade.score >= 50 ? '#27AE60' : '#E74C3C' }}>
                              {grade.score}%
                            </Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Detailed answer correction */}
                  {result.questionDetails && result.questionDetails.length > 0 ? (
                    <View className="border-t" style={{ borderColor: '#E5E7EB' }}>
                      <TouchableOpacity
                        onPress={() => setExpandedResults(current => ({ ...current, [result.id]: !isExpanded }))}
                        className="p-4 flex-row items-center justify-between"
                        accessibilityRole="button"
                        accessibilityLabel="عرض التصحيح التفصيلي للأسئلة"
                      >
                        <View>
                          <Text className="text-sm font-bold" style={{ color: '#1B4F72' }}>التصحيح التفصيلي للأسئلة</Text>
                          <Text className="text-xs mt-1" style={{ color: '#7F8C8D' }}>اعرف إجابتك والإجابة النموذجية لكل سؤال</Text>
                        </View>
                        <Text className="text-base font-bold" style={{ color: '#1B4F72' }}>{isExpanded ? '⌃' : '⌄'}</Text>
                      </TouchableOpacity>
                      {isExpanded && (
                        <View className="px-4 pb-4 gap-3">
                          {result.questionDetails.map((detail, detailIndex) => (
                            <View
                              key={detail.questionId}
                              className="p-3 rounded-xl"
                              style={{ backgroundColor: detail.isCorrect ? '#F0FFF0' : '#FDEDEC', borderWidth: 1, borderColor: detail.isCorrect ? '#B7E4C7' : '#F5C6C2' }}
                            >
                              <View className="flex-row items-center justify-between mb-2">
                                <Text className="text-xs font-bold" style={{ color: detail.isCorrect ? '#1E8449' : '#C0392B' }}>
                                  {detail.isCorrect ? 'إجابة صحيحة' : 'تحتاج إلى مراجعة'}
                                </Text>
                                <Text className="text-xs" style={{ color: '#7F8C8D' }}>
                                  {detailIndex + 1}. {TYPE_LABELS[detail.questionType] || detail.questionType}
                                </Text>
                              </View>
                              <Text className="text-sm font-bold leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right' }}>{detail.questionText}</Text>
                              <View className="mt-3 p-2 rounded-lg" style={{ backgroundColor: '#FFFFFF' }}>
                                <Text className="text-xs font-bold mb-1" style={{ color: '#7F8C8D' }}>إجابتك</Text>
                                <Text className="text-sm leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right' }}>{formatAnswer(detail.userAnswer)}</Text>
                              </View>
                              <View className="mt-2 p-2 rounded-lg" style={{ backgroundColor: '#E8F8F0' }}>
                                <Text className="text-xs font-bold mb-1" style={{ color: '#1E8449' }}>الإجابة النموذجية</Text>
                                <Text className="text-sm leading-relaxed" style={{ color: '#1E8449', textAlign: 'right' }}>{detail.correctAnswer}</Text>
                              </View>
                              {typeof detail.essayScore === 'number' && (
                                <Text className="text-xs font-bold mt-3" style={{ color: detail.essayScore >= 50 ? '#1E8449' : '#C0392B' }}>تقييم الإجابة المقالية: {detail.essayScore}%</Text>
                              )}
                              {!!detail.essayFeedback && (
                                <View className="mt-2 p-2 rounded-lg" style={{ backgroundColor: '#FFF8E1' }}>
                                  <Text className="text-xs font-bold mb-1" style={{ color: '#9A6B00' }}>ملاحظة للتحسين</Text>
                                  <Text className="text-xs leading-relaxed" style={{ color: '#5D4A00', textAlign: 'right' }}>{detail.essayFeedback}</Text>
                                </View>
                              )}
                            </View>
                          ))}
                        </View>
                      )}
                    </View>
                  ) : (
                    <View className="p-4 border-t" style={{ borderColor: '#E5E7EB' }}>
                      <Text className="text-xs text-center" style={{ color: '#95A5A6' }}>التصحيح التفصيلي متاح للامتحانات الجديدة التي تُجرى بعد هذا التحديث.</Text>
                    </View>
                  )}

                  {/* Actions */}
                  <View className="flex-row border-t" style={{ borderColor: '#E5E7EB' }}>
                    <TouchableOpacity
                      onPress={() => handleShareResult(result)}
                      className="flex-1 py-3 items-center"
                      style={{ borderRightWidth: 0.5, borderRightColor: '#E5E7EB' }}
                    >
                      <Text className="text-xs font-bold" style={{ color: '#1B4F72' }}>مشاركة</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => router.push({ pathname: '/(tabs)/exam-setup' as any, params: { documentId: result.documentId } })}
                      className="flex-1 py-3 items-center"
                      style={{ borderRightWidth: 0.5, borderRightColor: '#E5E7EB' }}
                    >
                      <Text className="text-xs font-bold" style={{ color: '#27AE60' }}>إعادة الامتحان</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleDeleteResult(index)}
                      className="flex-1 py-3 items-center"
                    >
                      <Text className="text-xs font-bold" style={{ color: '#E74C3C' }}>حذف</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
