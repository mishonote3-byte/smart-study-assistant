import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Platform, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ScreenContainer } from '@/components/screen-container';
import { API_BASE_URL, getApiBaseUrl, setRuntimeApiBaseUrl } from '@/constants/oauth';

const STORAGE_KEY = 'study_api_base_url';

export default function SettingsScreen() {
  const managedMode = useMemo(() => Boolean(API_BASE_URL), []);
  const [url, setUrl] = useState('');
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    if (managedMode) {
      setUrl(getApiBaseUrl());
      return;
    }
    void AsyncStorage.getItem(STORAGE_KEY).then(value => setUrl(value || getApiBaseUrl()));
  }, [managedMode]);

  const normalized = () => url.trim().replace(/\/$/, '');
  const validate = () => /^https?:\/\/[^\s]+$/i.test(normalized());

  const testConnection = async () => {
    const base = managedMode ? getApiBaseUrl() : normalized();
    if (!base || !/^https?:\/\/[^\s]+$/i.test(base)) {
      Alert.alert('الخدمة غير مهيأة', 'إصدار التطبيق الحالي لا يحتوي على عنوان خدمة صحيح.');
      return;
    }
    setTesting(true);
    try {
      const response = await fetch(`${base}/api/health`);
      if (!response.ok) throw new Error(String(response.status));
      Alert.alert('الخدمة تعمل', 'التطبيق متصل بخدمة المعالجة بنجاح.');
    } catch {
      Alert.alert('الخدمة غير متاحة مؤقتًا', 'تعذر الوصول إلى خدمة المعالجة الآن. حاول مرة أخرى بعد قليل.');
    } finally {
      setTesting(false);
    }
  };

  const save = async () => {
    if (managedMode) return;
    if (!validate()) { Alert.alert('العنوان غير صحيح', 'اكتب العنوان كاملاً مثل https://example.com'); return; }
    const value = normalized();
    await AsyncStorage.setItem(STORAGE_KEY, value);
    setRuntimeApiBaseUrl(value);
    Alert.alert('تم الحفظ', Platform.OS === 'web' ? 'أعد تحميل الصفحة لتطبيق الإعداد.' : 'تم حفظ عنوان الخدمة.');
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ gap: 16, paddingBottom: 32 }}>
        <View className="items-center py-3">
          <Text className="text-2xl font-bold" style={{ color: '#1B4F72' }}>إعدادات التطبيق</Text>
          <Text className="text-sm mt-2 text-center" style={{ color: '#7F8C8D' }}>
            {managedMode ? 'الخدمة مهيأة تلقائيًا داخل التطبيق' : 'إعداد الاتصال بخدمة المعالجة'}
          </Text>
        </View>

        {managedMode ? (
          <View className="p-4 rounded-xl gap-3" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D9E2EC' }}>
            <Text className="font-bold" style={{ color: '#1B4F72' }}>حالة الخدمة</Text>
            <Text className="text-sm leading-relaxed" style={{ color: '#5B6770', textAlign: 'right' }}>
              لا تحتاج إلى كتابة أي عنوان أو تشغيل أي خادم يدويًا. الاتصال مضبوط تلقائيًا في هذا الإصدار.
            </Text>
            <TouchableOpacity onPress={testConnection} disabled={testing} className="py-3 rounded-xl items-center" style={{ backgroundColor: '#1B4F72' }}>
              {testing ? <ActivityIndicator color="#FFFFFF" /> : <Text className="text-white font-bold">اختبار الخدمة</Text>}
            </TouchableOpacity>
          </View>
        ) : (
          <View className="p-4 rounded-xl gap-3" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D9E2EC' }}>
            <Text className="font-bold" style={{ color: '#1B4F72' }}>عنوان الخدمة</Text>
            <TextInput
              value={url}
              onChangeText={setUrl}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              placeholder="https://example.com"
              style={{ direction: 'ltr', textAlign: 'left', borderWidth: 1, borderColor: '#B8C6D1', borderRadius: 10, padding: 12, color: '#1F2937' }}
            />
            <TouchableOpacity onPress={testConnection} disabled={testing} className="py-3 rounded-xl items-center" style={{ backgroundColor: '#E8F4FD' }}>
              {testing ? <ActivityIndicator color="#1B4F72" /> : <Text className="font-bold" style={{ color: '#1B4F72' }}>اختبار الاتصال</Text>}
            </TouchableOpacity>
            <TouchableOpacity onPress={save} className="py-3 rounded-xl items-center" style={{ backgroundColor: '#1B4F72' }}>
              <Text className="text-white font-bold">حفظ الإعداد</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
