import { useState, useEffect, useCallback, useRef } from 'react';
import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy, type Question, type QuestionDetail } from '@/contexts/study-context';
import { trpc } from '@/lib/trpc';
import { isMatchingAnswerCorrect, minutesToSeconds } from '@/lib/exam-utils';

export default function ExamScreen() {
  const router = useRouter();
  const { documentId, questionCount: qcStr, timeLimit: tlStr, questionTypes: qtStr, typeCounts: tcStr } = useLocalSearchParams<{
    documentId: string;
    questionCount: string;
    timeLimit: string;
    questionTypes: string;
    typeCounts?: string;
  }>();

  const { getDocument, addExamResult } = useStudy();
  const gradeEssayMutation = trpc.study.gradeEssay.useMutation();

  const doc = getDocument(documentId || '');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeRemaining, setTimeRemaining] = useState(() => minutesToSeconds(tlStr));
  const [isFinished, setIsFinished] = useState(false);
  const [grading, setGrading] = useState(false);
  const [hintVisible, setHintVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const answersRef = useRef<Record<string, any>>({});
  const questionsRef = useRef<Question[]>([]);
  const documentRef = useRef(doc);
  const submitExamRef = useRef<() => Promise<void>>(async () => {});

  const questionCount = Number(qcStr) || 10;
  const timeLimitMinutes = Number(tlStr) || 0;
  const types = (qtStr || '').split(',').filter(Boolean);

  // Filter and shuffle questions
  const allQuestions = doc?.questionBank?.filter(q => types.includes(q.type)) || [];

  const parsedTypeCounts: Record<string, number> = (() => {
    try {
      const parsed = tcStr ? JSON.parse(tcStr) : {};
      const result: Record<string, number> = {};
      for (const [type, value] of Object.entries(parsed)) {
        if (Number.isFinite(value) && Number(value) > 0) result[type] = Math.min(300, Math.floor(Number(value)));
      }
      return result;
    } catch {
      return {};
    }
  })();
  const hasTypeCounts = Object.keys(parsedTypeCounts).length > 0;

  const questions = (() => {
    if (!hasTypeCounts) return allQuestions.slice(0, questionCount);
    const selected: Question[] = [];
    const usedIds = new Set<string>();
    for (const type of types) {
      const perType = parsedTypeCounts[type] || 0;
      const available = allQuestions.filter(q => q.type === type && !usedIds.has(q.id));
      for (let index = 0; index < Math.min(perType, available.length); index += 1) {
        selected.push(available[index]);
        usedIds.add(available[index].id);
      }
    }
    // إذا لم يكن بنك الأسئلة المولّد كافياً، نكمل بأسئلة من أي نوع متاح حتى العدد المطلوب.
    const remaining = Math.max(0, questionCount - selected.length);
    if (remaining > 0) {
      for (const q of allQuestions) {
        if (usedIds.has(q.id)) continue;
        selected.push(q);
        usedIds.add(q.id);
        if (selected.length >= questionCount) break;
      }
    }
    return selected;
  })();

  useEffect(() => {
    questionsRef.current = questions;
    documentRef.current = doc;
  }, [doc, questions]);

  const handleFinish = useCallback(() => {
    setIsFinished(true);
    if (timerRef.current) clearInterval(timerRef.current);
    void submitExamRef.current();
  }, []);

  useEffect(() => {
    if (timeLimitMinutes > 0 && !isFinished) {
      timerRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            handleFinish();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }
  }, [timeLimitMinutes, isFinished, handleFinish]);

  const submitExam = async () => {
    setGrading(true);
    let correctCount = 0;
    const essayScores: Record<string, { score: number; feedback: string }> = {};
    const questionDetails: QuestionDetail[] = [];
    const submittedAnswers = answersRef.current;
    const submittedQuestions = questionsRef.current;
    const submittedDocument = documentRef.current;

    for (const q of submittedQuestions) {
      const userAnswer = submittedAnswers[q.id];
      const hasAnswer = q.type === 'matching'
        ? !!userAnswer && Object.keys(userAnswer as Record<string, string>).length > 0
        : String(userAnswer ?? '').trim().length > 0;
      let isCorrect = false;
      let essayFeedback: string | undefined;
      let essayScore: number | undefined;

      // Objective questions - auto grade
      if (q.type === 'mcq' || q.type === 'truefalse' || q.type === 'fill') {
        const normalizedAnswer = String(userAnswer).trim().toLowerCase();
        const normalizedCorrect = String(q.correctAnswer || q.answer).trim().toLowerCase();
        isCorrect = hasAnswer && normalizedAnswer === normalizedCorrect;
      }

      if (q.type === 'matching') {
        const selectedPairs = (userAnswer || {}) as Record<string, string>;
        isCorrect = hasAnswer && isMatchingAnswerCorrect(selectedPairs, q.pairs);
      }

      // Essay questions - AI grade
      if (q.type === 'enumerate' || q.type === 'reason') {
        if (!hasAnswer) {
          essayScores[q.id] = { score: 0, feedback: 'لم يتم تقديم إجابة لهذا السؤال.' };
        } else {
          try {
            const result = await gradeEssayMutation.mutateAsync({
              question: q.question,
              modelAnswer: q.answer,
              studentAnswer: String(userAnswer),
            });
            essayScores[q.id] = {
              score: result.score || 0,
              feedback: result.feedback || '',
            };
          } catch {
            essayScores[q.id] = { score: 0, feedback: 'لم يتم التقييم' };
          }
        }
        essayScore = essayScores[q.id].score;
        essayFeedback = essayScores[q.id].feedback;
        isCorrect = essayScore >= 50;
      }

      if (isCorrect) correctCount++;
      const correctAnswer = q.type === 'matching'
        ? (q.pairs || []).map(pair => `${pair.left} ← ${pair.right}`).join('\n')
        : (q.correctAnswer || q.answer);
      questionDetails.push({
        questionId: q.id,
        questionText: q.question,
        questionType: q.type,
        userAnswer: userAnswer ?? '',
        correctAnswer,
        isCorrect,
        hint: q.hint,
        essayFeedback,
        essayScore,
      });
    }

    await addExamResult({
      documentId: submittedDocument?.id || '',
      documentName: submittedDocument?.name || '',
      totalQuestions: submittedQuestions.length,
      score: correctCount,
      answers: submittedAnswers,
      essayScores: Object.keys(essayScores).length > 0 ? essayScores : undefined,
      questionDetails,
    });

    setGrading(false);
    router.push({ pathname: '/results' as any, params: { justFinished: 'true' } });
  };
  submitExamRef.current = submitExam;

  const currentQuestion = questions[currentIndex];

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (grading) {
    return (
      <ScreenContainer className="p-4 items-center justify-center">
        <ActivityIndicator size="large" color="#1B4F72" />
        <Text className="text-lg mt-4" style={{ color: '#1B4F72' }}>جاري التصحيح...</Text>
        <Text className="text-sm mt-2" style={{ color: '#7F8C8D' }}>يرجى الانتظار</Text>
      </ScreenContainer>
    );
  }

  if (!currentQuestion) {
    return (
      <ScreenContainer className="p-4 items-center justify-center">
        <Text className="text-lg" style={{ color: '#E74C3C' }}>لا توجد أسئلة متاحة</Text>
        <Text className="text-sm mt-2" style={{ color: '#7F8C8D' }}>تأكد من توليد أسئلة أولاً</Text>
        <TouchableOpacity onPress={() => router.back()} className="mt-4 py-3 px-6 rounded-xl" style={{ backgroundColor: '#1B4F72' }}>
          <Text className="text-white font-bold">العودة</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const TYPE_COLORS: Record<string, string> = {
    mcq: '#3498DB',
    fill: '#9B59B6',
    truefalse: '#27AE60',
    enumerate: '#F39C12',
    reason: '#E74C3C',
    matching: '#16A085',
  };

  const TYPE_LABELS: Record<string, string> = {
    mcq: 'اختيار من متعدد',
    fill: 'أكمل العبارات',
    truefalse: 'صح أم خطأ',
    enumerate: 'اذكر / عدّد',
    reason: 'علل',
    matching: 'طابق',
  };

  const handleAnswer = (value: any) => {
    setAnswers(prev => {
      const nextAnswers = { ...prev, [currentQuestion.id]: value };
      answersRef.current = nextAnswers;
      return nextAnswers;
    });
  };

  const handleQuestionChange = (index: number) => {
    setHintVisible(false);
    setCurrentIndex(index);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-4">
        {/* Header */}
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center gap-2">
            <Text className="text-xs" style={{ color: '#7F8C8D' }}>
              سؤال {currentIndex + 1} من {questions.length}
            </Text>
          </View>
          {timeLimitMinutes > 0 && (
            <View className="px-3 py-1 rounded-lg" style={{ backgroundColor: timeRemaining < 60 ? '#FDEDEC' : '#E8F4FD' }}>
              <Text className="text-sm font-bold" style={{ color: timeRemaining < 60 ? '#E74C3C' : '#1B4F72' }}>
                ⏱ {formatTime(timeRemaining)}
              </Text>
            </View>
          )}
        </View>

        {/* Progress Bar */}
        <View className="h-2 rounded-full" style={{ backgroundColor: '#E5E7EB' }}>
          <View
            className="h-2 rounded-full"
            style={{
              backgroundColor: '#1B4F72',
              width: `${((currentIndex + 1) / questions.length) * 100}%`,
            }}
          />
        </View>

        {/* Question */}
        <View className="p-5 rounded-2xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
          <View className="flex-row items-center justify-between mb-3">
            <View className="px-3 py-1 rounded-full" style={{ backgroundColor: TYPE_COLORS[currentQuestion.type] || '#1B4F72' }}>
              <Text className="text-xs font-bold text-white">{TYPE_LABELS[currentQuestion.type]}</Text>
            </View>
          </View>
          <Text className="text-base font-bold leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right' }}>
            {currentQuestion.question}
          </Text>
          <TouchableOpacity
            onPress={() => setHintVisible(visible => !visible)}
            className="self-start mt-4 px-3 py-2 rounded-lg"
            style={{ backgroundColor: hintVisible ? '#FFF8E1' : '#E8F4FD', borderWidth: 1, borderColor: hintVisible ? '#F5C842' : '#B0C4DE' }}
            accessibilityRole="button"
            accessibilityLabel="إظهار تلميح السؤال"
          >
            <Text className="text-xs font-bold" style={{ color: hintVisible ? '#9A6B00' : '#1B4F72' }}>
              {hintVisible ? 'إخفاء التلميح' : 'تلميح'}
            </Text>
          </TouchableOpacity>
          {hintVisible && (
            <View className="mt-3 p-3 rounded-lg" style={{ backgroundColor: '#FFFDF4', borderRightWidth: 3, borderRightColor: '#F39C12' }}>
              <Text className="text-sm leading-relaxed" style={{ color: '#5D4A00', textAlign: 'right' }}>
                {currentQuestion.hint || 'راجع المفهوم الرئيس المرتبط بالسؤال في النص أو الملخص، ثم حدّد الفكرة الأقرب للإجابة.'}
              </Text>
            </View>
          )}
        </View>

        {/* Answer Input */}
        {(currentQuestion.type === 'mcq') && (
          <View className="gap-2">
            {(currentQuestion.options || []).map((option, i) => {
              const isSelected = answers[currentQuestion.id] === option;
              return (
                <TouchableOpacity
                  key={i}
                  onPress={() => handleAnswer(option)}
                  className="p-4 rounded-xl flex-row items-center gap-3"
                  style={{
                    backgroundColor: isSelected ? '#E8F4FD' : '#FFFFFF',
                    borderWidth: 1.5,
                    borderColor: isSelected ? '#1B4F72' : '#E5E7EB',
                  }}
                >
                  <View className="w-6 h-6 rounded-full items-center justify-center" style={{ backgroundColor: isSelected ? '#1B4F72' : '#E5E7EB' }}>
                    {isSelected && <Text className="text-white text-xs font-bold">✓</Text>}
                  </View>
                  <Text className="text-sm flex-1" style={{ color: '#2C3E50' }}>{option}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {currentQuestion.type === 'truefalse' && (
          <View className="gap-3">
            {['صح', 'خطأ'].map(opt => {
              const isSelected = answers[currentQuestion.id] === opt;
              return (
                <TouchableOpacity
                  key={opt}
                  onPress={() => handleAnswer(opt)}
                  className="p-4 rounded-xl items-center"
                  style={{
                    backgroundColor: isSelected ? '#E8F4FD' : '#FFFFFF',
                    borderWidth: 1.5,
                    borderColor: isSelected ? '#1B4F72' : '#E5E7EB',
                  }}
                >
                  <Text className="text-lg font-bold" style={{ color: isSelected ? '#1B4F72' : '#7F8C8D' }}>{opt}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {currentQuestion.type === 'matching' && (
          <View className="gap-4">
            <Text className="text-sm text-center" style={{ color: '#7F8C8D' }}>
              اختر العبارة المناسبة المقابلة لكل عنصر.
            </Text>
            {(currentQuestion.pairs || []).map((pair, pairIndex) => (
              <View key={`${pair.left}-${pairIndex}`} className="p-3 rounded-xl gap-2" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                <Text className="text-sm font-bold" style={{ color: '#2C3E50', textAlign: 'right' }}>{pair.left}</Text>
                <View className="gap-2">
                  {(currentQuestion.options || []).map((option, optionIndex) => {
                    const selectedPairs = (answers[currentQuestion.id] || {}) as Record<string, string>;
                    const isSelected = selectedPairs[pair.left] === option;
                    return (
                      <TouchableOpacity
                        key={`${pairIndex}-${optionIndex}`}
                        onPress={() => handleAnswer({ ...selectedPairs, [pair.left]: option })}
                        className="p-3 rounded-lg"
                        style={{ backgroundColor: isSelected ? '#E8F4FD' : '#F8FAFC', borderWidth: 1, borderColor: isSelected ? '#1B4F72' : '#E5E7EB' }}
                      >
                        <Text className="text-sm" style={{ color: isSelected ? '#1B4F72' : '#2C3E50', textAlign: 'right' }}>{option}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            ))}
          </View>
        )}

        {(currentQuestion.type === 'fill' || currentQuestion.type === 'enumerate' || currentQuestion.type === 'reason') && (
          <TextInput
            value={answers[currentQuestion.id] || ''}
            onChangeText={(text) => handleAnswer(text)}
            placeholder="اكتب إجابتك هنا..."
            multiline
            numberOfLines={4}
            className="p-4 rounded-xl text-base"
            style={{
              backgroundColor: '#FFFFFF',
              borderWidth: 1.5,
              borderColor: '#E5E7EB',
              color: '#2C3E50',
              minHeight: 100,
              textAlign: 'right',
            }}
          />
        )}

        {/* Navigation */}
        <View className="flex-row gap-3">
          {currentIndex > 0 && (
            <TouchableOpacity
              onPress={() => handleQuestionChange(currentIndex - 1)}
              className="flex-1 py-4 rounded-xl items-center"
              style={{ backgroundColor: '#F3F4F6' }}
            >
              <Text className="font-bold" style={{ color: '#7F8C8D' }}>السابق →</Text>
            </TouchableOpacity>
          )}
          {currentIndex < questions.length - 1 ? (
            <TouchableOpacity
              onPress={() => handleQuestionChange(currentIndex + 1)}
              className="flex-1 py-4 rounded-xl items-center"
              style={{ backgroundColor: '#1B4F72' }}
            >
              <Text className="text-white font-bold">التالي ←</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={handleFinish}
              className="flex-1 py-4 rounded-xl items-center"
              style={{ backgroundColor: '#27AE60' }}
            >
              <Text className="text-white font-bold">إنهاء الامتحان</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Question Dots */}
        <View className="flex-row flex-wrap gap-2 justify-center pb-4">
          {questions.map((_, i) => (
            <TouchableOpacity
              key={i}
              onPress={() => handleQuestionChange(i)}
              className="w-8 h-8 rounded-full items-center justify-center"
              style={{
                backgroundColor: i === currentIndex ? '#1B4F72' : (answers[questions[i].id] ? '#27AE60' : '#E5E7EB'),
              }}
            >
              <Text className="text-xs font-bold" style={{ color: i === currentIndex ? '#FFFFFF' : (answers[questions[i].id] ? '#FFFFFF' : '#7F8C8D') }}>
                {i + 1}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
