import { ScrollView, Text, View, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';

export default function PrivacyScreen() {
  const router = useRouter();

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-5">
        <View className="items-center py-4">
          <Text className="text-2xl font-bold" style={{ color: '#1B4F72' }}>🔒 الخصوصية والأمان</Text>
          <Text className="text-sm mt-2" style={{ color: '#7F8C8D' }}>بياناتك محمية على جهازك فقط</Text>
        </View>

        {/* Security Badge */}
        <View className="p-5 rounded-2xl" style={{ backgroundColor: '#F0FFF0', borderWidth: 1, borderColor: '#27AE60' }}>
          <Text className="text-lg font-bold mb-3" style={{ color: '#27AE60' }}>✅ مستنداتك محفوظة محلياً</Text>
          <Text className="text-sm leading-relaxed" style={{ color: '#2C3E50' }}>
            المستندات والملخصات ونتائج الامتحانات تُحفظ في تخزين المتصفح على جهازك. لا ينشئ التطبيق حساباً ولا يخزن هذه البيانات في قاعدة بيانات خاصة بالتطبيق.
          </Text>
        </View>

        {/* Storage Info */}
        <View className="gap-3">
          <Text className="text-base font-bold" style={{ color: '#1B4F72' }}>📱 أين تُخزن بياناتك؟</Text>
          
          <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
            <Text className="text-sm font-bold mb-1" style={{ color: '#2C3E50' }}>تخزين محلي (LocalStorage/IndexedDB)</Text>
            <Text className="text-xs leading-relaxed" style={{ color: '#7F8C8D' }}>
              تبقى النسخ المحفوظة والنتائج في متصفحك. عند رفع ملف للقراءة، يُرسل مؤقتاً إلى خادم المعالجة ولا يُحفظ في قاعدة بيانات دائمة.
            </Text>
          </View>

          <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
            <Text className="text-sm font-bold mb-1" style={{ color: '#2C3E50' }}>معالجة الذكاء الاصطناعي — عند اختيارك لها</Text>
            <Text className="text-xs leading-relaxed" style={{ color: '#7F8C8D' }}>
              عند الضغط على «تلخيص» أو «توليد أسئلة» أو «تصحيح مقالي»، يُرسل النص المطلوب فقط عبر اتصال HTTPS إلى خادم المعالجة كي ينفذ طلب الذكاء الاصطناعي. الخادم في هذا التطبيق لا يكتب النص في قاعدة بيانات أو تخزين دائم، لكن هذا ليس وضعاً دون اتصال بالإنترنت. لا تستخدم المعالجة الذكية لمستندات شديدة السرية إلا إذا قبلت إرسال النص لهذا الغرض.
            </Text>
          </View>

          <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
            <Text className="text-sm font-bold mb-1" style={{ color: '#2C3E50' }}>لا حسابات أو تسجيلات</Text>
            <Text className="text-xs leading-relaxed" style={{ color: '#7F8C8D' }}>
              لا يتطلب التطبيق إنشاء حساب أو تسجيل دخول. استخدام المستندات والنتائج وإدارتها يتم محلياً دون إنشاء ملف مستخدم على الخادم.
            </Text>
          </View>
        </View>

        {/* Encryption Info */}
        <View className="gap-3">
          <Text className="text-base font-bold" style={{ color: '#1B4F72' }}>🔐 كيف نحمي بياناتك؟</Text>
          
          <View className="flex-row items-start gap-3 p-3 rounded-xl" style={{ backgroundColor: '#F8F9FA' }}>
            <Text className="text-lg">1️⃣</Text>
            <View className="flex-1">
              <Text className="text-sm font-bold" style={{ color: '#2C3E50' }}>تشفير HTTPS</Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>تستخدم النسخة المنشورة اتصال HTTPS، بينما يعمل الخادم الخاص داخل شبكتك المحلية.</Text>
            </View>
          </View>

          <View className="flex-row items-start gap-3 p-3 rounded-xl" style={{ backgroundColor: '#F8F9FA' }}>
            <Text className="text-lg">2️⃣</Text>
            <View className="flex-1">
              <Text className="text-sm font-bold" style={{ color: '#2C3E50' }}>تخزين محلي فقط</Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>البيانات تبقى على جهازك ولا تُخزن في أي مكان آخر</Text>
            </View>
          </View>

          <View className="flex-row items-start gap-3 p-3 rounded-xl" style={{ backgroundColor: '#F8F9FA' }}>
            <Text className="text-lg">3️⃣</Text>
            <View className="flex-1">
              <Text className="text-sm font-bold" style={{ color: '#2C3E50' }}>لا إعلانات ولا تتبع</Text>
              <Text className="text-xs" style={{ color: '#7F8C8D' }}>لا يتم جمع أي بيانات عن استخدامك أو سلوكك</Text>
            </View>
          </View>
        </View>

        {/* How to Install */}
        <View className="gap-3">
          <Text className="text-base font-bold" style={{ color: '#1B4F72' }}>💻 تثبيت التطبيق على Windows</Text>
          
          <View className="p-4 rounded-xl" style={{ backgroundColor: '#E8F4FD', borderWidth: 1, borderColor: '#B0C4DE' }}>
            <Text className="text-sm mb-2" style={{ color: '#1B4F72' }}>
              1. افتح المتصفح (Chrome أو Edge)
            </Text>
            <Text className="text-sm mb-2" style={{ color: '#1B4F72' }}>
              2. اذهب لرابط التطبيق
            </Text>
            <Text className="text-sm mb-2" style={{ color: '#1B4F72' }}>
              3. اضغط على أيقونة «تثبيت» في شريط العنوان
            </Text>
            <Text className="text-sm" style={{ color: '#1B4F72' }}>
              4. أو: ثلاث نقاط ← «التطبيقات» ← «تثبيت هذا الموقع كتطبيق»
            </Text>
          </View>
        </View>

        <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFF8E1', borderWidth: 1, borderColor: '#F5C842' }}>
          <Text className="text-xs" style={{ color: '#7F8C8D' }}>
            ملاحظة: حتى بعد التثبيت كتطبيق على سطح المكتب، تبقى بيانات التطبيق المخزنة محلياً في ملف تعريف المتصفح على جهازك. حذف بيانات المتصفح أو إعادة ضبطه قد يمسحها، لذلك احتفظ بنسخ مهمة من مستنداتك الأصلية.
          </Text>
        </View>

        <TouchableOpacity
          onPress={() => router.back()}
          className="py-4 rounded-xl items-center"
          style={{ backgroundColor: '#1B4F72' }}
        >
          <Text className="text-white font-bold">العودة</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
