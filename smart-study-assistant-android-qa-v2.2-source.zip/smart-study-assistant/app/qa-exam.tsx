import { useMemo, useState } from 'react';
import { ScrollView, Text, View, TouchableOpacity } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy, type Question } from '@/contexts/study-context';

export default function QuestionAnswerExam() {
  const router = useRouter();
  const { documentId } = useLocalSearchParams<{ documentId: string }>();
  const { getDocument, addExamResult } = useStudy();
  const doc = getDocument(documentId || '');
  const questions = useMemo(() => doc?.questionBank || [], [doc?.questionBank]);
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [ratings, setRatings] = useState<Record<string, boolean>>({});
  const [finished, setFinished] = useState(false);
  const [saving, setSaving] = useState(false);
  const current = questions[index];
  const correct = Object.values(ratings).filter(Boolean).length;

  const finish = async (nextRatings: Record<string, boolean>) => {
    if (!doc || saving) return;
    setSaving(true);
    try {
      await addExamResult({
        documentId: doc.id,
        documentName: doc.name,
        totalQuestions: questions.length,
        score: Object.values(nextRatings).filter(Boolean).length,
        answers: Object.fromEntries(Object.entries(nextRatings).map(([id, value]) => [id, value ? 'عرفت الإجابة' : 'يحتاج مراجعة'])),
        questionDetails: questions.map((q: Question) => ({
          questionId: q.id, questionText: q.question, questionType: q.type,
          userAnswer: nextRatings[q.id] ? 'عرفت الإجابة' : 'يحتاج مراجعة',
          correctAnswer: q.answer, isCorrect: !!nextRatings[q.id], hint: q.hint,
        })),
      });
      setFinished(true);
    } finally {
      setSaving(false);
    }
  };

  const rate = (knewAnswer: boolean) => {
    if (!current) return;
    const next = { ...ratings, [current.id]: knewAnswer };
    setRatings(next);
    setRevealed(false);
    if (index + 1 < questions.length) setIndex(index + 1);
    else void finish(next);
  };

  if (!doc || !questions.length) return (
    <ScreenContainer className="p-5 items-center justify-center">
      <Text className="text-lg text-center" style={{ color: '#1B4F72' }}>لا توجد أسئلة لهذا المستند بعد.</Text>
      <TouchableOpacity onPress={() => router.back()} className="mt-5 p-4 rounded-xl" style={{ backgroundColor: '#1B4F72' }}>
        <Text className="text-white">العودة للمستند</Text>
      </TouchableOpacity>
    </ScreenContainer>
  );

  return (
    <ScreenContainer className="p-5">
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 30 }}>
        <TouchableOpacity onPress={() => router.back()} style={{ alignSelf: 'flex-start', paddingVertical: 8 }}>
          <Text style={{ color: '#1B4F72', fontSize: 16 }}>رجوع</Text>
        </TouchableOpacity>
        <Text style={{ color: '#1B4F72', fontSize: 23, fontWeight: '700', textAlign: 'right', marginVertical: 16 }}>
          {finished ? 'نتيجة سؤال وجواب' : 'امتحان سؤال وجواب'}
        </Text>
        <Text style={{ color: '#536577', fontSize: 15, textAlign: 'right', marginBottom: 15 }}>{doc.name}</Text>
        {finished ? (
          <View style={{ backgroundColor: '#FFFFFF', padding: 22, borderRadius: 16, gap: 15 }}>
            <Text style={{ color: '#1B4F72', fontSize: 26, fontWeight: '700', textAlign: 'center' }}>{correct} / {questions.length}</Text>
            <Text style={{ color: '#536577', fontSize: 16, textAlign: 'center' }}>عرفت {correct} إجابة · تحتاج مراجعة {questions.length - correct}</Text>
            <TouchableOpacity onPress={() => { setIndex(0); setRatings({}); setRevealed(false); setFinished(false); }} style={{ backgroundColor: '#1B4F72', padding: 16, borderRadius: 12 }}>
              <Text style={{ color: 'white', textAlign: 'center', fontSize: 16, fontWeight: '700' }}>إعادة الامتحان</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <Text style={{ color: '#536577', fontSize: 15, marginBottom: 10, textAlign: 'right' }}>السؤال {index + 1} من {questions.length}</Text>
            <View style={{ backgroundColor: '#DFE8F0', height: 7, borderRadius: 6, marginBottom: 18 }}>
              <View style={{ backgroundColor: '#1B4F72', height: 7, borderRadius: 6, width: `${((index + 1) / questions.length) * 100}%` }} />
            </View>
            <View style={{ backgroundColor: '#FFFFFF', padding: 20, borderRadius: 16, gap: 15 }}>
              <Text style={{ color: '#142F44', fontSize: 20, fontWeight: '700', textAlign: 'right', lineHeight: 33 }}>{current.question}</Text>
              {current.options?.length ? current.options.map((option, i) => (
                <Text key={i} style={{ color: '#33485B', fontSize: 16, textAlign: 'right', lineHeight: 27 }}>{i + 1}. {option}</Text>
              )) : null}
              {!!current.sourcePage && <Text style={{ color: '#536577', textAlign: 'right', fontSize: 14 }}>المصدر: صفحة {current.sourcePage}</Text>}
            </View>
            {!revealed ? (
              <TouchableOpacity onPress={() => setRevealed(true)} style={{ backgroundColor: '#1B4F72', padding: 17, borderRadius: 12, marginTop: 20 }}>
                <Text style={{ color: 'white', fontSize: 17, fontWeight: '700', textAlign: 'center' }}>إظهار الإجابة</Text>
              </TouchableOpacity>
            ) : (
              <>
                <View style={{ backgroundColor: '#E8F5EF', padding: 18, borderRadius: 12, marginTop: 20 }}>
                  <Text style={{ color: '#165A3A', fontSize: 16, textAlign: 'right', lineHeight: 28 }}>الإجابة: {current.answer}</Text>
                  {!!current.sourceQuote && <Text style={{ color: '#3E6052', fontSize: 14, textAlign: 'right', marginTop: 8 }}>من النص: {current.sourceQuote}</Text>}
                </View>
                <Text style={{ color: '#536577', textAlign: 'center', fontSize: 15, marginVertical: 14 }}>هل كنت تعرف الإجابة؟</Text>
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <TouchableOpacity onPress={() => rate(false)} disabled={saving} style={{ backgroundColor: '#FFF0E9', padding: 15, borderRadius: 12, flex: 1 }}>
                    <Text style={{ color: '#934825', textAlign: 'center', fontSize: 15, fontWeight: '700' }}>أحتاج مراجعة</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => rate(true)} disabled={saving} style={{ backgroundColor: '#16754C', padding: 15, borderRadius: 12, flex: 1 }}>
                    <Text style={{ color: 'white', textAlign: 'center', fontSize: 15, fontWeight: '700' }}>عرفتها صح</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
