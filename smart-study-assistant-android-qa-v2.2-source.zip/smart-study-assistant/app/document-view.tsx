import { useEffect, useState } from 'react';
import { ScrollView, Text, View, TouchableOpacity, Alert, ActivityIndicator, Share, Platform } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Speech from 'expo-speech';
import { ScreenContainer } from '@/components/screen-container';
import { useStudy } from '@/contexts/study-context';
import { trpc } from '@/lib/trpc';

export default function DocumentViewScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getDocument, updateDocument } = useStudy();
  const [activeSection, setActiveSection] = useState<'text' | 'summary' | 'explanation' | 'questions'>('text');
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [loadingExplanation, setLoadingExplanation] = useState(false);
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [questionError, setQuestionError] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [exporting, setExporting] = useState<'word' | 'pdf' | null>(null);

  const summarizeMutation = trpc.study.summarizeDocument.useMutation();
  const explainMutation = trpc.study.explainDocument.useMutation();
  const generateQuestionsMutation = trpc.study.generateQuestions.useMutation();
  const exportMutation = trpc.study.exportDocument.useMutation();

  const doc = getDocument(id || '');
  const isProcessing = doc?.processingState === 'processing';
  const isFailed = doc?.processingState === 'failed';

  useEffect(() => {
    return () => {
      void Speech.stop();
    };
  }, []);

  if (!doc) {
    return (
      <ScreenContainer className="p-4 items-center justify-center">
        <Text className="text-lg" style={{ color: '#7F8C8D' }}>لم يتم العثور على المستند</Text>
        <TouchableOpacity onPress={() => router.back()} className="mt-4 py-3 px-6 rounded-xl" style={{ backgroundColor: '#1B4F72' }}>
          <Text className="text-white font-bold">العودة</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const handleSummarize = async () => {
    if (isProcessing) {
      Alert.alert('جارٍ التحضير', 'اكتمل رفع الملف، ويجري الآن استخراج النص. حاول بعد لحظات.');
      return;
    }
    if (!doc.text.trim()) {
      Alert.alert('تنبيه', 'لا يوجد نص لتلخيصه');
      return;
    }
    setLoadingSummary(true);
    try {
      const summary = await summarizeMutation.mutateAsync({ text: doc.text, documentId: doc.id });
      await updateDocument(doc.id, {
        summary: {
          executive: summary.executive || '',
          concepts: summary.concepts || [],
          keyPoints: summary.keyPoints || [],
          createdAt: new Date().toISOString(),
        },
      });
      Alert.alert('تم', 'تم تلخيص المستند بنجاح');
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'حدث خطأ في التلخيص');
    } finally {
      setLoadingSummary(false);
    }
  };

  const handleGenerateQuestions = async () => {
    if (isProcessing) {
      Alert.alert('جارٍ التحضير', 'اكتمل رفع الملف، ويجري الآن استخراج النص. حاول بعد لحظات.');
      return;
    }
    if (!doc.text.trim()) {
      Alert.alert('تنبيه', 'لا يوجد نص لتوليد أسئلة منه');
      return;
    }
    setQuestionError(null);
    setLoadingQuestions(true);
    try {
      const questions = await generateQuestionsMutation.mutateAsync({
        text: doc.text,
        documentId: doc.id,
        questionCount: 150,
        typeCounts: { mcq: 105, truefalse: 45 },
      });
      await updateDocument(doc.id, {
        questionBank: questions.map((q: any, i: number) => ({
          id: q.id || `q${i + 1}`,
          type: q.type,
          question: q.question,
          answer: q.answer,
          options: q.options,
          correctAnswer: q.correctAnswer,
          pairs: q.pairs,
          hint: q.hint,
          sourcePage: q.sourcePage,
          sourceQuote: q.sourceQuote,
          documentId: doc.id,
        })),
      });
      Alert.alert('تم', `تم توليد ${questions.length} سؤال`);
    } catch (err: any) {
      const message = err.message || 'تعذر توليد بنك الأسئلة. حاول مرة أخرى.';
      setQuestionError(message);
      Alert.alert('خطأ', message);
    } finally {
      setLoadingQuestions(false);
    }
  };

  const handleShare = async () => {
    try {
      let content = `📄 ${doc.name}\n\n`;
      if (activeSection === 'text') {
        content += doc.text;
      } else if (activeSection === 'summary' && doc.summary) {
        content += `📋 الملخص التنفيذي:\n${doc.summary.executive}\n\n`;
        content += `📚 المفاهيم الأساسية:\n${doc.summary.concepts.map(c => `• ${c}`).join('\n')}\n\n`;
        content += `🔑 النقاط الرئيسية:\n${doc.summary.keyPoints.map(p => `• ${p}`).join('\n')}`;
      } else if (activeSection === 'explanation' && doc.explanation) {
        content += `📖 شرح مبسط:\n${doc.explanation}`;
      } else if (activeSection === 'questions' && doc.questionBank) {
        doc.questionBank.forEach((q, i) => {
          content += `${i + 1}. ${q.question}\n   الإجابة: ${q.answer}\n\n`;
        });
      }
      await Share.share({ message: content });
    } catch { /* user cancelled */ }
  };

  const handleExport = async (type: 'word' | 'pdf') => {
    setExporting(type);
    try {
      const result = await exportMutation.mutateAsync({
        type,
        title: doc.name,
        content: activeSection === 'summary' && doc.summary
          ? `${doc.summary.executive}\n\n${doc.summary.keyPoints.join('\n')}`
          : activeSection === 'explanation' ? (doc.explanation || '') : activeSection === 'text' ? doc.text : '',
        questions: activeSection === 'questions' ? (doc.questionBank || []).map(question => ({
          question: question.question,
          answer: question.answer,
          options: question.options,
          correctAnswer: question.correctAnswer,
          sourcePage: question.sourcePage,
        })) : [],
      });
      if (Platform.OS === 'web' && typeof document !== 'undefined') {
        const bytes = Uint8Array.from(atob(result.base64), character => character.charCodeAt(0));
        const url = URL.createObjectURL(new Blob([bytes], { type: result.mimeType }));
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = result.fileName;
        anchor.click();
        URL.revokeObjectURL(url);
      } else {
        Alert.alert('تم إنشاء الملف', 'افتح التطبيق من المتصفح لتنزيل الملف مباشرة.');
      }
    } catch (error: any) {
      Alert.alert('خطأ', error?.message || 'تعذر إنشاء ملف التصدير.');
    } finally {
      setExporting(null);
    }
  };

  const handleExplain = async () => {
    if (isProcessing) {
      Alert.alert('جارٍ التحضير', 'اكتمل رفع الملف، ويجري الآن استخراج النص. حاول بعد لحظات.');
      return;
    }
    if (!doc.text.trim()) {
      Alert.alert('تنبيه', 'لا يوجد نص يمكن شرحه');
      return;
    }
    setLoadingExplanation(true);
    try {
      const result = await explainMutation.mutateAsync({ text: doc.text, documentId: doc.id });
      await updateDocument(doc.id, { explanation: result.explanation || '' });
      Alert.alert('تم', 'تم إعداد شرح مبسط للمحتوى');
    } catch (err: any) {
      Alert.alert('خطأ', err.message || 'تعذر إنشاء الشرح. حاول مرة أخرى.');
    } finally {
      setLoadingExplanation(false);
    }
  };

  const webSynth =
    typeof window !== 'undefined' && typeof (window as any).speechSynthesis !== 'undefined'
      ? ((window as any).speechSynthesis as SpeechSynthesis | null)
      : null;

  const stopWebSpeech = () => {
    if (webSynth) {
      webSynth.cancel();
    }
  };

  const findArabicVoice = (): SpeechSynthesisVoice | null => {
    if (!webSynth) return null;
    const voices = webSynth.getVoices();
    const arabic = voices.find((v: SpeechSynthesisVoice) => /^ar[\- ]/.test(v.lang))
      || voices.find((v: SpeechSynthesisVoice) => v.lang.startsWith('ar'));
    return arabic || null;
  };

  const speakWeb = (text: string) => {
    if (!webSynth) return;
    const MAX = 200;
    const chunks: string[] = [];
    let current = '';
    for (const sentence of text.match(/[^.!؟\n]+[.!؟\n]*/g) || [text]) {
      const next = `${current} ${sentence}`.trim();
      if (next.length > MAX && current) {
        chunks.push(current);
        current = sentence.trim();
      } else {
        current = next;
      }
    }
    if (current) chunks.push(current);
    const arabicVoice = findArabicVoice();
    let utteranceIndex = 0;
    const speakNext = () => {
      if (utteranceIndex >= chunks.length) {
        setIsSpeaking(false);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(chunks[utteranceIndex]);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.9;
      if (arabicVoice) utterance.voice = arabicVoice;
      utterance.onend = () => {
        utteranceIndex += 1;
        speakNext();
      };
      utterance.onerror = () => {
        setIsSpeaking(false);
      };
      webSynth.speak(utterance);
    };
    speakNext();
  };

  const stopExplanationAudio = () => {
    stopWebSpeech();
    void Speech.stop();
    setIsSpeaking(false);
  };

  const playExplanationAudio = () => {
    if (!doc.explanation?.trim()) return;
    stopExplanationAudio();
    setIsSpeaking(true);
    if (webSynth) {
      // على الويب يفتقر expo-speech إلى أصوات عربية، لذا نستخدم Web Speech API مع صوت عربي صريح.
      // نتحقق من تحميل الأصوات لأن القائمة قد تكون فارغة عند بداية التشغيل.
      const explanationText: string = doc.explanation || '';
      const voices = webSynth.getVoices();
      if (voices.length) {
        speakWeb(explanationText);
      } else {
        webSynth.onvoiceschanged = () => {
          webSynth.onvoiceschanged = null;
          speakWeb(explanationText);
        };
        webSynth.cancel();
        webSynth.getVoices();
      }
    } else {
      const maxLength = Speech.maxSpeechInputLength || 3500;
      const sentences = doc.explanation.match(/[^.!؟\n]+[.!؟\n]*/g) || [doc.explanation];
      const chunks: string[] = [];
      let currentChunk = '';
      for (const sentence of sentences) {
        const nextChunk = `${currentChunk} ${sentence}`.trim();
        if (nextChunk.length > maxLength && currentChunk) {
          chunks.push(currentChunk);
          currentChunk = sentence.trim();
        } else {
          currentChunk = nextChunk;
        }
      }
      if (currentChunk) chunks.push(currentChunk);
      chunks.forEach((chunk, index) => {
        Speech.speak(chunk, {
          language: 'ar-SA',
          rate: 0.9,
          onDone: index === chunks.length - 1 ? () => setIsSpeaking(false) : undefined,
          onStopped: index === chunks.length - 1 ? () => setIsSpeaking(false) : undefined,
          onError: index === chunks.length - 1 ? () => setIsSpeaking(false) : undefined,
        });
      });
    }
  };

  const TYPE_LABELS: Record<string, string> = {
    mcq: 'اختيار من متعدد',
    fill: 'أكمل',
    truefalse: 'صح أم خطأ',
    enumerate: 'اذكر / عدّد',
    reason: 'علل',
    matching: 'طابق',
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="gap-4">
        {/* Header */}
        <View className="items-center py-2">
          <Text className="text-xl font-bold" style={{ color: '#1B4F72' }} numberOfLines={1}>
            {doc.name}
          </Text>
          <Text className="text-xs mt-1" style={{ color: '#7F8C8D' }}>
            {new Date(doc.createdAt).toLocaleDateString('ar-EG')}
          </Text>
          {doc.pageCount && (
            <Text className="text-xs mt-1" style={{ color: '#7F8C8D' }}>
              {doc.extractedPageFrom && doc.extractedPageTo
                ? `تم تحليل الصفحات ${doc.extractedPageFrom}–${doc.extractedPageTo} من أصل ${doc.pageCount}`
                : `${doc.pageCount} صفحة`}
            </Text>
          )}
        </View>

        {isProcessing && (
          <View className="flex-row items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: '#E8F4FD', borderWidth: 1, borderColor: '#B0C4DE' }}>
            <ActivityIndicator color="#1B4F72" />
            <Text className="flex-1 text-sm" style={{ color: '#1B4F72' }}>{doc.processingMessage || 'يتم استخراج النص من الملف…'}</Text>
          </View>
        )}
        {isFailed && (
          <View className="p-3 rounded-xl" style={{ backgroundColor: '#FDECEC', borderWidth: 1, borderColor: '#E74C3C' }}>
            <Text className="text-sm" style={{ color: '#A61B1B' }}>{doc.processingMessage || 'تعذر استخراج النص من هذا الملف.'}</Text>
          </View>
        )}

        {/* Section Tabs */}
        <View className="flex-row gap-2">
          {([
            { key: 'text', label: 'النص' },
            { key: 'summary', label: 'الملخص' },
            { key: 'explanation', label: 'الشرح' },
            { key: 'questions', label: 'الأسئلة' },
          ] as const).map(section => (
            <TouchableOpacity
              key={section.key}
              onPress={() => setActiveSection(section.key)}
              className="flex-1 py-2 rounded-lg items-center"
              style={{ backgroundColor: activeSection === section.key ? '#1B4F72' : '#F3F4F6' }}
            >
              <Text className="text-xs font-bold" style={{ color: activeSection === section.key ? '#FFFFFF' : '#7F8C8D' }}>
                {section.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Content */}
        {activeSection === 'text' && (
          <View className="gap-4">
            {doc.structuredDocument && (
              <View className="p-3 rounded-xl" style={{ backgroundColor: '#E8F4FD' }}>
                <Text className="font-bold text-sm" style={{ color: '#1B4F72' }}>تقرير جودة الاستخراج</Text>
                <Text className="text-xs mt-1" style={{ color: '#2C3E50' }}>
                  الصفحات المقروءة: {doc.structuredDocument.quality.readablePages}/{doc.structuredDocument.pages.length} · OCR: {doc.structuredDocument.quality.ocrPages} · الجداول: {doc.structuredDocument.quality.tablePages} · الثقة: {Math.round(doc.structuredDocument.quality.averageConfidence * 100)}%
                </Text>
              </View>
            )}
            <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
              {doc.structuredDocument ? doc.structuredDocument.pages.map(page => (
                <View key={page.pageNumber} className="mb-5 gap-2">
                  <Text className="font-bold text-sm" style={{ color: '#1B4F72', textAlign: 'right' }}>صفحة {page.pageNumber} · {page.kind === 'scanned' ? 'ممسوحة ضوئياً' : page.kind === 'table' ? 'تحتوي جدولاً' : 'نص'}</Text>
                  {page.blocks.map(block => block.type === 'table' ? (
                    <View key={block.id} style={{ borderWidth: 1, borderColor: '#D9E2EC' }}>
                      {block.rows.map((row, rowIndex) => (
                        <View key={`${block.id}-${rowIndex}`} className="flex-row-reverse">
                          {row.map((cell, cellIndex) => (
                            <View key={`${block.id}-${rowIndex}-${cellIndex}`} style={{ flex: 1, padding: 6, borderLeftWidth: cellIndex < row.length - 1 ? 1 : 0, borderTopWidth: rowIndex ? 1 : 0, borderColor: '#D9E2EC', backgroundColor: rowIndex === 0 ? '#E8F4FD' : '#FFFFFF' }}>
                              <Text className="text-xs" style={{ textAlign: 'right', color: '#2C3E50' }}>{cell}</Text>
                            </View>
                          ))}
                        </View>
                      ))}
                    </View>
                  ) : (
                    <Text key={block.id} className="text-sm leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right', fontWeight: block.type === 'heading' ? '700' : '400' }}>
                      {block.type === 'list-item' ? '• ' : ''}{block.text}
                    </Text>
                  ))}
                </View>
              )) : (
                <Text className="text-sm leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right' }}>{doc.text || 'لا يوجد نص'}</Text>
              )}
            </View>
            {!doc.summary && (
              <TouchableOpacity
                onPress={handleSummarize}
                disabled={loadingSummary || isProcessing}
                className="py-3 rounded-xl items-center"
                style={{ backgroundColor: '#1B4F72', opacity: loadingSummary || isProcessing ? 0.7 : 1 }}
              >
                {loadingSummary ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text className="text-white font-bold">تلخيص المستند بالذكاء الاصطناعي</Text>
                )}
              </TouchableOpacity>
            )}
          </View>
        )}

        {activeSection === 'summary' && (
          <View className="gap-4">
            {!doc.summary ? (
              <View className="items-center py-8">
                <Text className="text-lg mb-4" style={{ color: '#7F8C8D' }}>لم يتم تلخيص المستند بعد</Text>
                <TouchableOpacity
                  onPress={handleSummarize}
                  disabled={loadingSummary || isProcessing}
                  className="py-3 px-6 rounded-xl"
                  style={{ backgroundColor: '#1B4F72', opacity: loadingSummary || isProcessing ? 0.7 : 1 }}
                >
                  {loadingSummary ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text className="text-white font-bold">تلخيص الآن</Text>
                  )}
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                  <Text className="font-bold text-base mb-2" style={{ color: '#1B4F72' }}>الملخص التنفيذي</Text>
                  <Text className="text-sm leading-relaxed" style={{ color: '#2C3E50' }}>{doc.summary.executive}</Text>
                </View>

                {doc.summary.concepts.length > 0 && (
                  <View className="p-4 rounded-xl" style={{ backgroundColor: '#E8F4FD', borderWidth: 1, borderColor: '#B0C4DE' }}>
                    <Text className="font-bold text-base mb-2" style={{ color: '#1B4F72' }}>المفاهيم الأساسية</Text>
                    {doc.summary.concepts.map((c, i) => (
                      <Text key={i} className="text-sm mb-1" style={{ color: '#2C3E50' }}>• {c}</Text>
                    ))}
                  </View>
                )}

                {doc.summary.keyPoints.length > 0 && (
                  <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFF8E1', borderWidth: 1, borderColor: '#F5C842' }}>
                    <Text className="font-bold text-base mb-2" style={{ color: '#F39C12' }}>النقاط الرئيسية</Text>
                    {doc.summary.keyPoints.map((p, i) => (
                      <Text key={i} className="text-sm mb-1" style={{ color: '#2C3E50' }}>{i + 1}. {p}</Text>
                    ))}
                  </View>
                )}
              </>
            )}
          </View>
        )}

        {activeSection === 'explanation' && (
          <View className="gap-4">
            {!doc.explanation ? (
              <View className="items-center py-8">
                <Text className="text-lg mb-2" style={{ color: '#7F8C8D' }}>لم يتم إعداد شرح مبسط بعد</Text>
                <Text className="text-sm mb-4 text-center" style={{ color: '#95A5A6' }}>
                  سيشرح المحتوى خطوة بخطوة بلغة عربية سهلة للمراجعة.
                </Text>
                <TouchableOpacity
                  onPress={handleExplain}
                  disabled={loadingExplanation || isProcessing}
                  className="py-3 px-6 rounded-xl"
                  style={{ backgroundColor: '#1B4F72', opacity: loadingExplanation || isProcessing ? 0.7 : 1 }}
                >
                  {loadingExplanation ? <ActivityIndicator color="#FFFFFF" /> : <Text className="text-white font-bold">إنشاء الشرح الآن</Text>}
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <View className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                  <View className="flex-row items-center justify-between mb-3">
                    <Text className="font-bold text-base" style={{ color: '#1B4F72' }}>شرح مبسط للمحتوى</Text>
                    <View className="px-2 py-1 rounded-full" style={{ backgroundColor: '#E8F4FD' }}>
                      <Text className="text-xs font-bold" style={{ color: '#1B4F72' }}>العربية</Text>
                    </View>
                  </View>
                  <Text className="text-sm leading-relaxed" style={{ color: '#2C3E50', textAlign: 'right' }}>{doc.explanation}</Text>
                </View>
                <View className="flex-row gap-3">
                  <TouchableOpacity
                    onPress={playExplanationAudio}
                    disabled={isSpeaking}
                    className="flex-1 py-3 rounded-xl items-center"
                    style={{ backgroundColor: '#1B4F72', opacity: isSpeaking ? 0.6 : 1 }}
                    accessibilityRole="button"
                    accessibilityLabel="الاستماع إلى الشرح باللغة العربية"
                  >
                    <Text className="text-white font-bold">{isSpeaking ? 'يتم التشغيل…' : 'استمع إلى الشرح'}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={stopExplanationAudio}
                    disabled={!isSpeaking}
                    className="flex-1 py-3 rounded-xl items-center"
                    style={{ backgroundColor: '#FDEDEC', opacity: isSpeaking ? 1 : 0.55 }}
                    accessibilityRole="button"
                    accessibilityLabel="إيقاف الشرح الصوتي"
                  >
                    <Text className="font-bold" style={{ color: '#E74C3C' }}>إيقاف الصوت</Text>
                  </TouchableOpacity>
                </View>
                <TouchableOpacity
                  onPress={handleExplain}
                  disabled={loadingExplanation}
                  className="py-3 rounded-xl items-center"
                  style={{ backgroundColor: '#F3F4F6', opacity: loadingExplanation ? 0.7 : 1 }}
                >
                  {loadingExplanation ? <ActivityIndicator color="#1B4F72" /> : <Text className="font-bold" style={{ color: '#1B4F72' }}>إعادة إنشاء الشرح</Text>}
                </TouchableOpacity>
              </>
            )}
          </View>
        )}

        {activeSection === 'questions' && (
          <View className="gap-4">
            {!doc.questionBank || doc.questionBank.length === 0 ? (
              <View className="items-center py-8">
                <Text className="text-lg mb-4" style={{ color: '#7F8C8D' }}>لا توجد أسئلة بعد</Text>
                {!!doc.processingMessage && !isProcessing && (
                  <Text className="text-sm mb-4 text-center" style={{ color: '#A61B1B' }}>{doc.processingMessage}</Text>
                )}
                {questionError && (
                  <View className="w-full mb-4 p-3 rounded-xl" style={{ backgroundColor: '#FDECEC', borderWidth: 1, borderColor: '#E74C3C' }}>
                    <Text className="text-sm text-center" style={{ color: '#A61B1B' }}>{questionError}</Text>
                  </View>
                )}
                <TouchableOpacity
                  onPress={handleGenerateQuestions}
                  disabled={loadingQuestions || isProcessing}
                  className="py-3 px-6 rounded-xl"
                  style={{ backgroundColor: '#27AE60', opacity: loadingQuestions || isProcessing ? 0.7 : 1 }}
                >
                  {loadingQuestions ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text className="text-white font-bold">توليد بنك أسئلة</Text>
                  )}
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <TouchableOpacity
                  onPress={handleGenerateQuestions}
                  disabled={loadingQuestions || isProcessing}
                  className="py-3 rounded-xl items-center"
                  style={{ backgroundColor: '#27AE60', opacity: loadingQuestions || isProcessing ? 0.7 : 1 }}
                >
                  {loadingQuestions ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text className="text-white font-bold">تحديث / توليد أسئلة جديدة</Text>
                  )}
                </TouchableOpacity>

                <Text className="text-xs" style={{ color: '#7F8C8D' }}>
                  {doc.questionBank.length} سؤال
                </Text>

                {doc.questionBank.map((q, i) => (
                  <View key={q.id} className="p-4 rounded-xl" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB' }}>
                    <View className="flex-row items-center justify-between mb-2">
                      <View className="px-2 py-1 rounded" style={{ backgroundColor: '#E8F4FD' }}>
                        <Text className="text-xs font-bold" style={{ color: '#1B4F72' }}>
                          {TYPE_LABELS[q.type] || q.type}
                        </Text>
                      </View>
                      <Text className="text-xs" style={{ color: '#BDC3C7' }}>#{i + 1}</Text>
                    </View>
                    <Text className="text-sm font-bold mb-2" style={{ color: '#2C3E50' }}>{q.question}</Text>
                    {q.sourcePage && <Text className="text-xs mb-2" style={{ color: '#7F8C8D' }}>المصدر: صفحة {q.sourcePage}</Text>}
                    {q.options && q.options.length > 0 && (
                      <View className="gap-1 mb-2">
                        {q.options.map((opt, j) => (
                          <Text key={j} className="text-xs" style={{ color: '#555' }}>
                            {String.fromCharCode(1611 + j)} - {opt}
                          </Text>
                        ))}
                      </View>
                    )}
                    <View className="p-2 rounded" style={{ backgroundColor: '#F0FFF0' }}>
                      <Text className="text-xs font-bold" style={{ color: '#27AE60' }}>الإجابة: {q.answer}</Text>
                    </View>
                  </View>
                ))}
              </>
            )}
          </View>
        )}

        {/* Actions */}
        <View className="flex-row gap-2 pb-2">
          <TouchableOpacity onPress={() => handleExport('word')} disabled={!!exporting} className="flex-1 py-3 rounded-xl items-center" style={{ backgroundColor: '#E8F4FD' }}>
            <Text className="text-xs font-bold" style={{ color: '#1B4F72' }}>{exporting === 'word' ? 'جارٍ الإنشاء…' : 'تصدير Word'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleExport('pdf')} disabled={!!exporting} className="flex-1 py-3 rounded-xl items-center" style={{ backgroundColor: '#FFF3E0' }}>
            <Text className="text-xs font-bold" style={{ color: '#A65300' }}>{exporting === 'pdf' ? 'جارٍ الإنشاء…' : 'تصدير PDF'}</Text>
          </TouchableOpacity>
        </View>
        <View className="flex-row gap-3 pb-4">
          {!!doc.questionBank?.length && (
            <TouchableOpacity
              onPress={() => router.push({ pathname: '/qa-exam' as any, params: { documentId: doc.id } })}
              className="flex-1 py-3 rounded-xl items-center"
              style={{ backgroundColor: '#1B4F72' }}
            >
              <Text className="text-white font-bold text-sm">امتحان سؤال وجواب</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            onPress={handleShare}
            className="flex-1 py-3 rounded-xl items-center"
            style={{ backgroundColor: '#F3F4F6' }}
          >
            <Text className="text-sm font-bold" style={{ color: '#7F8C8D' }}>مشاركة</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push({ pathname: '/(tabs)/exam-setup' as any, params: { documentId: doc.id } })}
            className="flex-1 py-3 rounded-xl items-center"
            style={{ backgroundColor: '#27AE60' }}
          >
            <Text className="text-white font-bold text-sm">بدء امتحان</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
