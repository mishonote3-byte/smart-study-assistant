import { describe, expect, it } from "vitest";
import { blocksFromLines, localQuestionBank, sourceChunks } from "../server/routers/studyRouter";

describe("Arabic study pipeline", () => {
  it("preserves page boundaries while chunking a long source", () => {
    const text = `[صفحة رقم 1]\n${"معلومة مهمة. ".repeat(80)}\n[صفحة رقم 2]\n${"تفصيل آخر. ".repeat(80)}`;
    const chunks = sourceChunks(text, 700);
    expect(chunks.length).toBeGreaterThan(1);
    expect(chunks.join("\n")).toContain("[صفحة رقم 1]");
    expect(chunks.join("\n")).toContain("[صفحة رقم 2]");
  });

  it("keeps a detected table as rows and columns", () => {
    const blocks = blocksFromLines([
      { text: "النوع   العدد   الملاحظة" },
      { text: "أول   10   مهم" },
      { text: "ثانٍ   20   عاجل" },
    ], 4, "ocr", 0.8);
    expect(blocks).toHaveLength(1);
    expect(blocks[0].type).toBe("table");
    if (blocks[0].type === "table") expect(blocks[0].rows).toHaveLength(3);
  });

  it("creates the requested 70/30 objective fallback distribution with source mapping", () => {
    const source = `[صفحة رقم 7]\n${Array.from({ length: 30 }, (_, index) => `المعلومة رقم ${index + 1} توضح أحد التفاصيل الأساسية في الدرس`).join(".\n")}`;
    const questions = localQuestionBank(source, 10, "doc-1", { mcq: 7, truefalse: 3 });
    expect(questions.filter(question => question.type === "mcq")).toHaveLength(7);
    expect(questions.filter(question => question.type === "truefalse")).toHaveLength(3);
    expect(questions.every(question => question.sourcePage === 7 && question.sourceQuote)).toBe(true);
  });
});
