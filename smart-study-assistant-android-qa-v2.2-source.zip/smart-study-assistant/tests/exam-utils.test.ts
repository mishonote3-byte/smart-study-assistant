import { describe, expect, it } from 'vitest';

import { isMatchingAnswerCorrect, minutesToSeconds } from '../lib/exam-utils';

describe('عداد الامتحان', () => {
  it('يحوّل الدقائق المختارة إلى ثوانٍ ولا ينهي امتحان 20 دقيقة بعد 20 ثانية', () => {
    expect(minutesToSeconds(20)).toBe(1200);
    expect(minutesToSeconds('10')).toBe(600);
    expect(minutesToSeconds('')).toBe(0);
  });
});

describe('تصحيح المطابقة', () => {
  const pairs = [
    { left: 'التواصل', right: 'تبادل المعلومات' },
    { left: 'الثقة', right: 'بناء الاعتماد المتبادل' },
  ];

  it('يقبل الإجابة فقط عند اكتمال جميع الأزواج الصحيحة', () => {
    expect(isMatchingAnswerCorrect({
      التواصل: 'تبادل المعلومات',
      الثقة: 'بناء الاعتماد المتبادل',
    }, pairs)).toBe(true);
    expect(isMatchingAnswerCorrect({ التواصل: 'تبادل المعلومات' }, pairs)).toBe(false);
    expect(isMatchingAnswerCorrect({
      التواصل: 'بناء الاعتماد المتبادل',
      الثقة: 'تبادل المعلومات',
    }, pairs)).toBe(false);
  });
});
