$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent $PSScriptRoot

if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
  Write-Host "لم يتم العثور على Ollama. ثبّته أولاً من https://ollama.com ثم أعد تشغيل هذا الملف." -ForegroundColor Yellow
  exit 1
}

Set-Location $Project
if (-not (Test-Path ".env")) {
  Copy-Item "$PSScriptRoot\.env.private.example" ".env"
  Write-Host "تم إنشاء .env. يمكنك تعديل اسم النموذج عند الحاجة." -ForegroundColor Green
}

ollama pull qwen2.5:7b-instruct
pnpm install --frozen-lockfile
pnpm build
$LocalIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike "127.*" -and $_.PrefixOrigin -ne "WellKnown" } | Select-Object -First 1 -ExpandProperty IPAddress)
if ($LocalIP) {
  Write-Host "افتح إعدادات التطبيق على الهاتف واكتب: http://${LocalIP}:3000" -ForegroundColor Cyan
  Write-Host "يجب أن يكون الهاتف والكمبيوتر على شبكة Wi-Fi واحدة." -ForegroundColor Cyan
}
pnpm start
