/** @type {const} */
const themeColors = {
  primary: { light: '#1B3A6B', dark: '#1B3A6B' },
  background: { light: '#F5F7FA', dark: '#151718' },
  surface: { light: '#FFFFFF', dark: '#1e2022' },
  foreground: { light: '#11181C', dark: '#ECEDEE' },
  muted: { light: '#687076', dark: '#9BA1A6' },
  border: { light: '#E5E7EB', dark: '#334155' },
  success: { light: '#27AE60', dark: '#4ADE80' },
  warning: { light: '#F39C12', dark: '#FBBF24' },
  error: { light: '#E74C3C', dark: '#F87171' },
};

module.exports = { themeColors };
