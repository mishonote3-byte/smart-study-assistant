import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { prewarmEmbeddedOcrWorker } from "../routers/studyRouter";
import { createContext } from "./context";
import { ENV } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  // OCR المدمج يحتاج إلى فك تحميل بيانات اللغة عند تشغيل العملية لأول مرة.
  // ننتظر اكتمال ذلك قبل فتح المنفذ حتى لا يكون أول طلب رفع هو طلب التهيئة البطيء.
  try {
    console.log("[study] preparing embedded OCR languages before accepting uploads");
    await prewarmEmbeddedOcrWorker();
    console.log("[study] embedded OCR is ready");
  } catch (error) {
    // يبقى مسار OCR البديل متاحاً إذا تعذر تحميل العامل في بيئة محددة.
    console.warn("[study] embedded OCR prewarm failed; fallback OCR will remain available", error);
  }

  const app = express();
  const server = createServer(app);
  const requestWindows = new Map<string, { startedAt: number; count: number }>();
  const limitRequests = (maximum: number, windowMs: number) => (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const current = requestWindows.get(key);
    const entry = !current || now - current.startedAt > windowMs ? { startedAt: now, count: 0 } : current;
    entry.count += 1;
    requestWindows.set(key, entry);
    if (entry.count > maximum) { res.status(429).json({ error: "طلبات كثيرة خلال وقت قصير. انتظر قليلاً ثم أعد المحاولة." }); return; }
    next();
  };

  const hasExpectedSignature = (buffer: Buffer, mimeType: string, fileName: string) => {
    const lower = fileName.toLowerCase();
    if (mimeType === "application/pdf" || lower.endsWith(".pdf")) return buffer.subarray(0, 5).toString() === "%PDF-";
    if (mimeType.includes("word") || lower.endsWith(".docx")) return buffer[0] === 0x50 && buffer[1] === 0x4b;
    if (mimeType === "image/png" || lower.endsWith(".png")) return buffer.subarray(1, 4).toString() === "PNG";
    if (mimeType === "image/jpeg" || /\.jpe?g$/.test(lower)) return buffer[0] === 0xff && buffer[1] === 0xd8;
    return mimeType.startsWith("text/");
  };

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    const sameOrigin = !origin || !ENV.isProduction || (() => { try { return new URL(origin).host === req.headers.host; } catch { return false; } })();
    if (origin && sameOrigin) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "40mb" }));
  app.use(express.urlencoded({ limit: "40mb", extended: true }));
  app.use("/api", limitRequests(120, 15 * 60_000));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  // مسار صريح لرفع محتوى المستندات في نسخة الويب. نتجنّب هنا تجميع tRPC
  // حتى لا تتعطل ملفات PDF الكبيرة داخل طلب مجمع أو خلف التخزين المؤقت للتطبيق التدريجي.
  app.post("/api/document/process", async (req, res) => {
    try {
      const { fileName, fileData, mimeType, pageFrom, pageTo } = req.body ?? {};
      if (typeof fileName !== "string" || typeof fileData !== "string" || typeof mimeType !== "string") {
        res.status(400).json({ error: "بيانات الملف غير مكتملة" });
        return;
      }

      const caller = appRouter.createCaller(await createContext({ req, res, info: {} as never }));
      const result = await caller.study.processDocument({
        fileName,
        fileData,
        mimeType,
        ...(typeof pageFrom === "number" ? { pageFrom } : {}),
        ...(typeof pageTo === "number" ? { pageTo } : {}),
      });
      res.json(result);
    } catch (error) {
      console.error("[study] direct document processing failed", error);
      res.status(500).json({ error: "تعذرت معالجة الملف. جرّب ملفاً أصغر أو صورة واضحة." });
    }
  });

  // رفع ثنائي مباشر: يمنع تحويل الملف إلى Base64 من زيادة حجمه في الذاكرة.
  // يستخدمه الويب والهاتف للملفات الكبيرة، بينما يبقى المسار السابق متوافقاً
  // مع الملفات القديمة المحفوظة محلياً.
  app.post(
    "/api/document/upload",
    // ملفات التطبيق تصل عادةً بنوعها الحقيقي مثل application/pdf أو image/jpeg،
    // وليس application/octet-stream فقط؛ لذا نقرأ الجسم الثنائي لأي نوع في هذا المسار المحدد.
    express.raw({ type: () => true, limit: "40mb" }),
    async (req, res) => {
      try {
        const fileName = decodeURIComponent(String(req.header("x-file-name") || "document.pdf"));
        const mimeType = String(req.header("x-mime-type") || "application/octet-stream");
        const rawFrom = Number(req.header("x-page-from"));
        const rawTo = Number(req.header("x-page-to"));
        if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
          res.status(400).json({ error: "لم يصل محتوى الملف بصورة صحيحة." });
          return;
        }
        if (!hasExpectedSignature(req.body, mimeType, fileName)) {
          res.status(415).json({ error: "نوع الملف لا يطابق محتواه أو غير مدعوم." });
          return;
        }
        const caller = appRouter.createCaller(await createContext({ req, res, info: {} as never }));
        const result = await caller.study.processDocument({
          fileName,
          mimeType,
          fileData: req.body.toString("base64"),
          ...(Number.isInteger(rawFrom) && rawFrom > 0 ? { pageFrom: rawFrom } : {}),
          ...(Number.isInteger(rawTo) && rawTo > 0 ? { pageTo: rawTo } : {}),
        });
        res.json(result);
      } catch (error) {
        console.error("[study] binary document upload failed", error);
        res.status(500).json({ error: "تعذرت معالجة الملف الآن. يمكنك اختيار نطاق صفحات محدد ثم المحاولة." });
      }
    },
  );

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  // Production deployments use this server as the public origin. Serve the
  // exported Expo web bundle from the same origin so the PWA and API are both
  // available at the project domain.
  const serverBuildPath = path.dirname(fileURLToPath(import.meta.url));
  // قد يضع Expo الحزمة في dist/ مباشرة أو في dist/web حسب إعداد التصدير.
  // وعند الإنتاج يكون ملف الخادم نفسه داخل dist/، بينما يبقى عند التطوير
  // داخل server/_core. لذلك نتحقق من المواقع المتوافقة ولا نخدم إلا مجلداً
  // يحتوي فعلياً على index.html.
  const webDistCandidates = [
    path.join(serverBuildPath, "web"),
    serverBuildPath,
    path.resolve(serverBuildPath, "../../dist/web"),
    path.resolve(serverBuildPath, "../../dist"),
  ];
  const webDistPath = webDistCandidates.find((candidate) =>
    fs.existsSync(path.join(candidate, "index.html")),
  );
  if (webDistPath) {
    app.use(express.static(webDistPath, { index: false, maxAge: "1h" }));
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api/")) {
        next();
        return;
      }
      res.sendFile(path.join(webDistPath, "index.html"));
    });
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
  });
}

startServer().catch(console.error);
