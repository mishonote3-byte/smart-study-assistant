import { publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import { z } from "zod";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import type { StructuredDocument, StructuredPage, StudyBlock } from "../../shared/study";
import { Document as WordDocument, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from "docx";
import PDFDocument from "pdfkit";

function getContent(result: any): string {
  const raw = result?.choices?.[0]?.message?.content;
  if (typeof raw === "string") return raw;
  if (Array.isArray(raw)) {
    return raw.map((part) => typeof part === "string" ? part : (part as any).text || "").join("\n");
  }
  return "{}";
}

function parseJsonObject(content: string): unknown {
  const normalized = content
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  const match = normalized.match(/\{[\s\S]*\}/);
  return JSON.parse(match ? match[0] : normalized);
}

const generatedQuestionSchema = z.object({
  id: z.string(),
  type: z.enum(["mcq", "fill", "truefalse", "enumerate", "reason", "matching"]),
  question: z.string().min(5),
  answer: z.string(),
  hint: z.string(),
  options: z.array(z.string()),
  correctAnswer: z.string(),
  pairs: z.array(z.object({ left: z.string(), right: z.string() })),
  sourcePage: z.number().int().positive().optional(),
  sourceQuote: z.string().optional(),
});

const generatedQuestionBankSchema = z.object({
  questions: z.array(generatedQuestionSchema),
});

async function resolveWithin<T>(work: Promise<T>, timeoutMs: number, message: string): Promise<T> {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      work,
      new Promise<never>((_resolve, reject) => {
        timeout = setTimeout(() => reject(new Error(message)), timeoutMs);
      }),
    ]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

const summaryOutputSchema = {
  name: "study_summary",
  strict: true,
  schema: {
    type: "object",
    properties: {
      executive: { type: "string" },
      concepts: { type: "array", items: { type: "string" } },
      keyPoints: { type: "array", items: { type: "string" } },
    },
    required: ["executive", "concepts", "keyPoints"],
    additionalProperties: false,
  },
} as const;

const questionOutputSchema = {
  name: "study_question_bank",
  strict: true,
  schema: {
    type: "object",
    properties: {
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "string" },
            type: { type: "string", enum: ["mcq", "fill", "truefalse", "enumerate", "reason", "matching"] },
            question: { type: "string" },
            answer: { type: "string" },
            hint: { type: "string" },
            options: { type: "array", items: { type: "string" } },
            correctAnswer: { type: "string" },
            pairs: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  left: { type: "string" },
                  right: { type: "string" },
                },
                required: ["left", "right"],
                additionalProperties: false,
              },
            },
            sourcePage: { type: "integer" },
            sourceQuote: { type: "string" },
          },
          required: ["id", "type", "question", "answer", "hint", "options", "correctAnswer", "pairs", "sourcePage", "sourceQuote"],
          additionalProperties: false,
        },
      },
    },
    required: ["questions"],
    additionalProperties: false,
  },
} as const;

interface PdfPageText {
  pageNumber: number;
  text: string;
  blocks: StudyBlock[];
  confidence: number;
}

interface PdfTextExtraction {
  totalPages: number;
  firstPage: number;
  lastPage: number;
  pages: PdfPageText[];
  pagesNeedingOcr: number[];
}

function resolvePdfPageRange(totalPages: number, pageFrom?: number, pageTo?: number) {
  const firstPage = Math.min(Math.max(pageFrom ?? 1, 1), totalPages);
  const requestedLastPage = pageTo ?? totalPages;
  const lastPage = Math.min(Math.max(requestedLastPage, firstPage), totalPages);
  return { firstPage, lastPage };
}

function withPageMarker(pageNumber: number, text: string) {
  return `[صفحة رقم ${pageNumber}]\n${text.trim()}`;
}

function hasMeaningfulPageText(text: string) {
  return (text.match(/[\p{L}\p{N}]/gu) ?? []).length >= 25;
}

function needsLocalOcr(text: string) {
  if (!hasMeaningfulPageText(text)) return true;
  const alphaNumeric = text.match(/[\p{L}\p{N}]/gu) ?? [];
  const arabic = text.match(/[\u0600-\u06FF]/g) ?? [];
  // بعض ملفات PDF العربية تخزن أحرفاً مرمزة، فتظهر كرموز وفواصل رغم أن الصفحة تحتوي نصاً كاملاً.
  // عند انخفاض نسبة الأحرف العربية نعيد قراءتها من الصورة بدلاً من تلخيص نص غير قابل للمذاكرة.
  return alphaNumeric.length >= 30 && arabic.length / alphaNumeric.length < 0.32;
}

type PositionedText = { text: string; x: number; y: number; width: number; height: number };

function cleanArabicText(value: string) {
  return normalizeDigits(value)
    .replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, "")
    .replace(/\s+([،؛:؟.!])/g, "$1")
    .replace(/[ \t]{4,}/g, "   ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function isArabicDominant(value: string) {
  const letters = value.match(/[\p{L}\p{N}]/gu) ?? [];
  const arabic = value.match(/[\u0600-\u06ff]/g) ?? [];
  return arabic.length / Math.max(letters.length, 1) >= 0.35;
}

function splitTableRow(line: string) {
  if (line.includes("|")) return line.split("|").map(cleanArabicText).filter(Boolean);
  if (line.includes("\t")) return line.split(/\t+/).map(cleanArabicText).filter(Boolean);
  return line.split(/\s{3,}/).map(cleanArabicText).filter(Boolean);
}

export function blocksFromLines(lines: Array<{ text: string; height?: number }>, pageNumber: number, source: "pdf-text" | "ocr", confidence: number): StudyBlock[] {
  const nonEmpty = lines.map(line => ({ ...line, text: cleanArabicText(line.text) })).filter(line => line.text);
  const heights = nonEmpty.map(line => line.height || 10).sort((a, b) => a - b);
  const medianHeight = heights[Math.floor(heights.length / 2)] || 10;
  const blocks: StudyBlock[] = [];
  let order = 0;
  for (let index = 0; index < nonEmpty.length; index += 1) {
    const line = nonEmpty[index];
    const cells = splitTableRow(line.text);
    const nextCells = index + 1 < nonEmpty.length ? splitTableRow(nonEmpty[index + 1].text) : [];
    if (cells.length >= 2 && nextCells.length === cells.length) {
      const rows = [cells];
      while (index + 1 < nonEmpty.length) {
        const candidate = splitTableRow(nonEmpty[index + 1].text);
        if (candidate.length !== cells.length) break;
        rows.push(candidate);
        index += 1;
      }
      blocks.push({ id: `p${pageNumber}-b${order + 1}`, type: "table", rows, pageNumber, order: order++, confidence, source });
      continue;
    }
    const short = line.text.length <= 90;
    const heading = short && ((line.height || 10) >= medianHeight * 1.22 || /^(الفصل|الباب|المبحث|المطلب|الموضوع|أولاً|ثانياً|ثالثاً)/.test(line.text));
    const listItem = /^([\-–•*]|\(?[٠-٩0-9]+[).\-]|[أ-ي][).\-])\s*/.test(line.text);
    blocks.push({
      id: `p${pageNumber}-b${order + 1}`,
      type: heading ? "heading" : listItem ? "list-item" : "paragraph",
      text: line.text,
      pageNumber,
      order: order++,
      confidence,
      source,
    });
  }
  return blocks;
}

function reconstructPdfLines(items: PositionedText[]) {
  const groups: PositionedText[][] = [];
  for (const item of [...items].sort((a, b) => b.y - a.y || a.x - b.x)) {
    const group = groups.find(candidate => Math.abs(candidate[0].y - item.y) <= Math.max(2.5, item.height * 0.35));
    if (group) group.push(item); else groups.push([item]);
  }
  return groups.map(group => {
    const sample = group.map(item => item.text).join(" ");
    const ordered = [...group].sort((a, b) => isArabicDominant(sample) ? b.x - a.x : a.x - b.x);
    const parts: string[] = [];
    for (let i = 0; i < ordered.length; i += 1) {
      const current = ordered[i];
      parts.push(current.text);
      if (i + 1 < ordered.length) {
        const next = ordered[i + 1];
        const gap = isArabicDominant(sample)
          ? current.x - (next.x + next.width)
          : next.x - (current.x + current.width);
        parts.push(gap > Math.max(18, current.height * 2.2) ? "   " : " ");
      }
    }
    return { text: parts.join(""), height: Math.max(...group.map(item => item.height || 10)) };
  });
}

async function extractPdfText(buffer: Buffer, pageFrom?: number, pageTo?: number): Promise<PdfTextExtraction> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
  const document = await loadingTask.promise;
  const { firstPage, lastPage } = resolvePdfPageRange(document.numPages, pageFrom, pageTo);
  const pages: PdfPageText[] = [];
  const pagesNeedingOcr: number[] = [];

  for (let pageNumber = firstPage; pageNumber <= lastPage; pageNumber += 1) {
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent();
    const positioned = content.items.flatMap((item: any) => item?.str ? [{
      text: String(item.str), x: Number(item.transform?.[4] || 0), y: Number(item.transform?.[5] || 0),
      width: Number(item.width || 0), height: Math.abs(Number(item.height || item.transform?.[3] || 10)),
    }] : []) as PositionedText[];
    const lines = reconstructPdfLines(positioned);
    const text = lines.map(line => cleanArabicText(line.text)).filter(Boolean).join("\n");
    const confidence = needsLocalOcr(text) ? 0.35 : 0.98;
    pages.push({ pageNumber, text, blocks: blocksFromLines(lines, pageNumber, "pdf-text", confidence), confidence });
    if (needsLocalOcr(text)) pagesNeedingOcr.push(pageNumber);
  }

  return { totalPages: document.numPages, firstPage, lastPage, pages, pagesNeedingOcr };
}

async function extractWordText(buffer: Buffer): Promise<string> {
  const mammoth = await import("mammoth");
  const result = await mammoth.extractRawText({ buffer });
  return result.value.trim();
}

function normalizeDigits(value: string) {
  const arabicDigits = "٠١٢٣٤٥٦٧٨٩";
  return value.replace(/[٠-٩]/g, (digit) => String(arabicDigits.indexOf(digit)));
}

function studySentences(text: string, maximum = 10) {
  return text
    .replace(/\[صفحة رقم \d+\]/g, "")
    .split(/[.!؟\n]+/)
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter((line) => line.length >= 24)
    .slice(0, maximum);
}

function localSummary(text: string) {
  const sentences = studySentences(text, 12);
  return {
    executive: (sentences.slice(0, 5).join(". ") || "هذا المستند يحتاج إلى نص أوضح ليُنتج منه ملخص تفصيلي.").trim(),
    concepts: sentences.slice(0, 5).map((sentence, index) => `المفهوم ${index + 1}: ${sentence}`),
    keyPoints: sentences.slice(0, 7).map((sentence) => `• ${sentence}`),
  };
}

function localExplanation(text: string) {
  const sentences = studySentences(text, 8);
  if (!sentences.length) return "لم يظهر نص كافٍ لشرحه. جرّب رفع صفحات أوضح أو اختر نطاقاً أصغر.";
  return `الفكرة العامة: ${sentences[0]}\n\nللمراجعة خطوة بخطوة:\n${sentences.map((sentence, index) => `${index + 1}. ${sentence}`).join("\n")}\n\nتذكّر أن تراجع الكلمات الأساسية والأمثلة الواردة في الدرس.`;
}

function pageNumberFromText(text: string) {
  return Number(text.match(/\[صفحة رقم\s*(\d+)\]/)?.[1] || 1);
}

export function sourceChunks(text: string, maximumCharacters = 5200) {
  const pageParts = text.split(/(?=\[صفحة رقم\s*\d+\])/).filter(part => part.trim());
  const chunks: string[] = [];
  let current = "";
  for (const page of pageParts.length ? pageParts : [text]) {
    if (current && current.length + page.length > maximumCharacters) {
      chunks.push(current.trim());
      current = "";
    }
    if (page.length > maximumCharacters) {
      const paragraphs = page.split(/\n+/);
      for (const paragraph of paragraphs) {
        if (current && current.length + paragraph.length > maximumCharacters) {
          chunks.push(current.trim());
          current = "";
        }
        current += `${paragraph}\n`;
      }
    } else {
      current += `${page}\n`;
    }
  }
  if (current.trim()) chunks.push(current.trim());
  return chunks;
}

function sourcePageSections(text: string) {
  const matches = [...text.matchAll(/\[صفحة رقم\s*(\d+)\]\s*([\s\S]*?)(?=\[صفحة رقم\s*\d+\]|$)/g)];
  if (!matches.length) return [{ pageNumber: 1, text: `[صفحة رقم 1]\n${text}` }];
  return matches.map(match => ({ pageNumber: Number(match[1]), text: `[صفحة رقم ${match[1]}]\n${match[2].trim()}` }));
}

function normalizedQuestionKey(value: string) {
  return value.normalize("NFKC").replace(/[\u064b-\u065f\u0670]/g, "").replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
}

export function localQuestionBank(text: string, count: number, documentId: string, typeCounts?: Record<string, number>) {
  const requestedMcq = Math.max(0, Math.floor(typeCounts?.mcq ?? Math.ceil(count * 0.7)));
  const requestedTf = Math.max(0, Math.floor(typeCounts?.truefalse ?? Math.max(0, count - requestedMcq)));
  const total = requestedMcq + requestedTf || count;
  const sentences = studySentences(text, Math.max(total * 2, 20));
  const page = pageNumberFromText(text);
  const output: any[] = [];
  for (let index = 0; index < total; index += 1) {
    const answer = sentences[index % Math.max(sentences.length, 1)] || "راجع النص المستخرج من المصدر.";
    const type = index < requestedMcq ? "mcq" : "truefalse";
    if (type === "mcq") {
      const distractors = [1, 2, 3].map(offset => sentences[(index + offset) % Math.max(sentences.length, 1)] || `بديل ${offset}`);
      output.push({
        id: `local-mcq-${index + 1}`, type, question: `وفقاً للمصدر، ما العبارة الصحيحة المتعلقة بـ «${answer.slice(0, 55)}…»؟`, answer,
        options: [answer, ...distractors].filter((value, position, all) => all.indexOf(value) === position).slice(0, 4),
        correctAnswer: answer, pairs: [], hint: "ارجع إلى صياغة الفقرة الأصلية.", documentId, sourcePage: page, sourceQuote: answer.slice(0, 240),
      });
    } else {
      const falseStatement = index % 2 === 1;
      const statement = falseStatement ? `لا يذكر المصدر أن: ${answer}` : answer;
      output.push({
        id: `local-tf-${index + 1}`, type, question: statement, answer: falseStatement ? `خطأ؛ يذكر المصدر: ${answer}` : "صح",
        options: ["صح", "خطأ"], correctAnswer: falseStatement ? "خطأ" : "صح", pairs: [],
        hint: "قارن العبارة بالنص الأصلي.", documentId, sourcePage: page, sourceQuote: answer.slice(0, 240),
      });
    }
  }
  return output;
}

function localEssayGrade(modelAnswer: string, studentAnswer: string) {
  const expected = new Set((modelAnswer.match(/[\p{L}\p{N}]{3,}/gu) || []).map((word) => word.toLowerCase()));
  const actual = new Set((studentAnswer.match(/[\p{L}\p{N}]{3,}/gu) || []).map((word) => word.toLowerCase()));
  const overlap = [...actual].filter((word) => expected.has(word)).length;
  const score = Math.min(100, Math.max(0, Math.round((overlap / Math.max(1, Math.min(expected.size, 10))) * 100)));
  return { score, feedback: score >= 60 ? "تتضمن الإجابة أفكاراً مرتبطة بالنموذج. أضف تفاصيل أكثر لتحسينها." : "راجع الإجابة النموذجية وأضف المفاهيم الأساسية التي وردت فيها.", strengths: score >= 60 ? ["توجد مفاهيم مشتركة مع الإجابة النموذجية"] : [], weaknesses: score >= 60 ? [] : ["تحتاج الإجابة إلى مفاهيم أساسية إضافية"] };
}

type ExportQuestion = { question: string; answer: string; options?: string[]; correctAnswer?: string; sourcePage?: number };

function exportLines(content: string, questions: ExportQuestion[]) {
  const lines = content.split(/\n+/).map(line => line.trim()).filter(Boolean);
  questions.forEach((question, index) => {
    lines.push(`${index + 1}. ${question.question}`);
    question.options?.forEach((option, optionIndex) => lines.push(`   ${String.fromCharCode(65 + optionIndex)}) ${option}`));
    lines.push(`الإجابة: ${question.correctAnswer || question.answer}${question.sourcePage ? ` — صفحة ${question.sourcePage}` : ""}`);
  });
  return lines;
}

async function createWordExport(title: string, content: string, questions: ExportQuestion[]) {
  const children = [
    new Paragraph({ heading: HeadingLevel.TITLE, alignment: AlignmentType.CENTER, bidirectional: true, children: [new TextRun({ text: title, bold: true, size: 34 })] }),
    ...exportLines(content, questions).map(line => new Paragraph({
      bidirectional: true,
      alignment: AlignmentType.RIGHT,
      spacing: { after: 120 },
      children: [new TextRun({ text: line, size: 26, rightToLeft: true })],
    })),
  ];
  const document = new WordDocument({ sections: [{ properties: {}, children }] });
  return Buffer.from(await Packer.toBuffer(document));
}

async function createPdfExport(title: string, content: string, questions: ExportQuestion[]) {
  const document = new PDFDocument({ size: "A4", margins: { top: 48, right: 48, bottom: 48, left: 48 }, bufferPages: true });
  const chunks: Buffer[] = [];
  document.on("data", chunk => chunks.push(Buffer.from(chunk)));
  const fontCandidates = [
    join(process.cwd(), "server", "assets", "fonts", "NotoNaskhArabic-Regular.ttf"),
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "C:\\Windows\\Fonts\\arial.ttf",
  ];
  const fontPath = fontCandidates.find(candidate => existsSync(candidate));
  if (fontPath) document.font(fontPath);
  document.fontSize(20).text(title, { align: "center" }).moveDown();
  document.fontSize(12);
  for (const line of exportLines(content, questions)) {
    if (document.y > 770) document.addPage();
    document.text(line, { align: "right", lineGap: 4 });
    document.moveDown(0.3);
  }
  document.end();
  await new Promise<void>((resolve, reject) => { document.on("end", resolve); document.on("error", reject); });
  return Buffer.concat(chunks);
}

function resolveOcrLanguagePath() {
  const currentDirectory = dirname(fileURLToPath(import.meta.url));
  const candidates = [
    join(process.cwd(), "server", "assets", "tessdata"),
    join(process.cwd(), "dist", "assets", "tessdata"),
    join(currentDirectory, "..", "assets", "tessdata"),
    join(currentDirectory, "assets", "tessdata"),
  ];
  return candidates.find((candidate) => existsSync(join(candidate, "ara.traineddata.gz"))) || candidates[0];
}

type OcrLanguageGroup = "ara" | "eng+spa";

async function createEmbeddedOcrWorker(language: OcrLanguageGroup) {
  const { createWorker } = await import("tesseract.js");
  const worker = await createWorker(language, 1, {
    langPath: resolveOcrLanguagePath(),
    gzip: true,
    cacheMethod: "none",
  });
  // صفحات المذكرات الدراسية عبارة عن عمود نصي رئيسي. نمط الكتلة الواحدة يتجاوز
  // تحليلاً تخطيطياً مكلفاً في البيئة العامة مع الاحتفاظ بقراءة عربية مناسبة.
  await worker.setParameters({ tessedit_pageseg_mode: "6" as any });
  return worker;
}

// تهيئة بيانات اللغة هي الجزء الأبطأ في OCR المدمج. نحتفظ بالعامل في ذاكرة
// عملية الخادم بين طلبات الدفعات؛ لا نحفظ صور أو نصوص المستخدم. يبدأ المسار
// بالعربية (لغة التطبيق والملفات الشائعة)، ولا يحمل محرك اللاتينية إلا عندما
// لا تظهر أحرف عربية في النتيجة، وبذلك لا ندفع ثمن ثلاث لغات لكل صفحة عربية.
const embeddedOcrWorkerPromises = new Map<OcrLanguageGroup, Promise<any>>();
const embeddedOcrQueues = new Map<OcrLanguageGroup, Promise<void>>();

async function getEmbeddedOcrWorker(language: OcrLanguageGroup) {
  let workerPromise = embeddedOcrWorkerPromises.get(language);
  if (!workerPromise) {
    workerPromise = createEmbeddedOcrWorker(language);
    embeddedOcrWorkerPromises.set(language, workerPromise);
  }
  try {
    return await workerPromise;
  } catch (error) {
    embeddedOcrWorkerPromises.delete(language);
    throw error;
  }
}

/**
 * يحمّل بيانات لغات OCR مرة واحدة خلال بدء الخدمة. لا يمرر أي ملف أو نص مستخدم
 * إلى الذاكرة الدائمة؛ العامل يحتفظ فقط ببيانات المحرك واللغة حتى يكون أول رفع
 * للطالب سريعاً ولا يصطدم بمهلة الوكيل العام.
 */
export async function prewarmEmbeddedOcrWorker() {
  await getEmbeddedOcrWorker("ara");
}

async function recognizeWithEmbeddedOcrLanguage(image: Buffer, language: OcrLanguageGroup): Promise<string> {
  const queued = embeddedOcrQueues.get(language) ?? Promise.resolve();
  const recognition = queued.then(async () => {
    const worker = await getEmbeddedOcrWorker(language);
    const { data } = await worker.recognize(image, {}, { text: true, blocks: true, hocr: true, tsv: true });
    return data.text.trim();
  });
  embeddedOcrQueues.set(language, recognition.then(() => undefined, () => undefined));
  return recognition;
}

function hasUsableOcrText(text: string) {
  return (text.match(/[\p{L}\p{N}]/gu) ?? []).length >= 12;
}

async function runEmbeddedOcr(image: Buffer): Promise<string> {
  const arabicText = await recognizeWithEmbeddedOcrLanguage(image, "ara");
  const letters = arabicText.match(/[\p{L}\p{N}]/gu) ?? [];
  const arabicLetters = arabicText.match(/[\u0600-\u06FF]/g) ?? [];
  if (hasUsableOcrText(arabicText) && arabicLetters.length / Math.max(letters.length, 1) >= 0.08) {
    return arabicText;
  }

  const latinText = await recognizeWithEmbeddedOcrLanguage(image, "eng+spa");
  return hasUsableOcrText(latinText) ? latinText : arabicText;
}

async function extractPdfWithEmbeddedOcr(buffer: Buffer, pageNumbers: number[]): Promise<Map<number, string>> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const { createCanvas } = await import("@napi-rs/canvas");
  const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
  const document = await loadingTask.promise;
  const extractedText = new Map<number, string>();

  // تعمل بيئة النشر على معالج أقل سرعة من التطوير؛ لذلك تستخدم الدفعات دقة 1.0
  // لتبقى الاستجابة دون مهلة الطلب. ويستطيع المستخدم اختيار صفحة واحدة عند الحاجة
  // إلى القراءة الأكثر تفصيلاً، إذ تبقى الصفحة المنفردة بدقة أعلى.
  const renderScale = pageNumbers.length > 1 ? 2.2 : 3.2;
  // نعالج صفحة واحدة في كل مرة لتقليل استهلاك الذاكرة عند المستندات الطويلة.
  for (const pageNumber of pageNumbers) {
    const page = await document.getPage(pageNumber);
    const viewport = page.getViewport({ scale: renderScale });
    const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
    const context = canvas.getContext("2d");
    await page.render({ canvas: canvas as any, canvasContext: context as any, viewport }).promise;
    const image = canvas.toBuffer("image/png");
    const text = await runEmbeddedOcr(image);
    if (hasUsableOcrText(text)) extractedText.set(pageNumber, text);
  }

  return extractedText;
}

function pageFromExtraction(page: PdfPageText, ocrText?: string): StructuredPage {
  const source = ocrText ? "ocr" : "pdf-text";
  const text = cleanArabicText((ocrText || page.text).replace(/\r/g, "\n"));
  const ocrLines = text.split(/\n+/).map(line => ({ text: line, height: 10 }));
  const blocks = ocrText ? blocksFromLines(ocrLines, page.pageNumber, source, 0.78) : page.blocks;
  const hasTable = blocks.some(block => block.type === "table");
  const warnings: string[] = [];
  if (!hasMeaningfulPageText(text)) warnings.push("النص المستخرج قليل أو غير واضح");
  if (ocrText) warnings.push("تمت قراءة الصفحة باستخدام OCR عربي");
  const kind: StructuredPage["kind"] = hasTable ? "table" : ocrText ? "scanned" : page.confidence < 0.6 ? "distorted" : "text";
  return { pageNumber: page.pageNumber, kind, confidence: ocrText ? 0.78 : page.confidence, text, blocks, warnings };
}

function buildStructuredDocument(extraction: PdfTextExtraction, ocrPages: Map<number, string>): StructuredDocument {
  const pages = extraction.pages.map(page => pageFromExtraction(page, ocrPages.get(page.pageNumber)));
  const plainText = pages.map(page => withPageMarker(page.pageNumber, page.text || "[تعذّر استخراج نص هذه الصفحة.]")).join("\n\n");
  const averageConfidence = pages.length
    ? Number((pages.reduce((sum, page) => sum + page.confidence, 0) / pages.length).toFixed(2))
    : 0;
  return {
    version: 1,
    totalPages: extraction.totalPages,
    extractedPageFrom: extraction.firstPage,
    extractedPageTo: extraction.lastPage,
    pages,
    plainText,
    quality: {
      readablePages: pages.filter(page => hasMeaningfulPageText(page.text)).length,
      ocrPages: pages.filter(page => page.kind === "scanned" || page.blocks.some(block => block.source === "ocr")).length,
      tablePages: pages.filter(page => page.blocks.some(block => block.type === "table")).length,
      warningPages: pages.filter(page => page.warnings.length > 0).length,
      averageConfidence,
    },
  };
}

async function extractPdfWithOcr(buffer: Buffer, pageNumbers: number[]): Promise<Map<number, string>> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const { createCanvas } = await import("@napi-rs/canvas");
  const loadingTask = pdfjs.getDocument({ data: new Uint8Array(buffer) });
  const document = await loadingTask.promise;
  const extractedText = new Map<number, string>();
  const batchSize = 2;

  for (let startIndex = 0; startIndex < pageNumbers.length; startIndex += batchSize) {
    const batch = pageNumbers.slice(startIndex, startIndex + batchSize);
    const images: Array<{ type: "image_url"; image_url: { url: string; detail: "low" } }> = [];

    for (const pageNumber of batch) {
      const page = await document.getPage(pageNumber);
      const viewport = page.getViewport({ scale: 0.8 });
      const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
      const context = canvas.getContext("2d");
      await page.render({ canvas: canvas as any, canvasContext: context as any, viewport }).promise;
      const image = canvas.toBuffer("image/jpeg", 62);
      images.push({
        type: "image_url",
        image_url: { url: `data:image/jpeg;base64,${image.toString("base64")}`, detail: "low" },
      });
    }

    const result = await resolveWithin(
      invokeLLM({
        model: "gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `أنت نظام OCR دقيق للمستندات الدراسية. استخرج النص المقروء حرفياً من صور صفحات PDF بالترتيب. حافظ على العربية والإنجليزية والإسبانية والأرقام والعناوين والقوائم. لا تشرح ولا تلخص ولا تضف معلومات. ابدأ نص كل صفحة بعلامة مستقلة بالشكل "[صفحة رقم X]". أرقام الصفحات المتاحة بالترتيب هي: ${batch.join("، ")}.`,
          },
          { role: "user", content: images },
        ],
        maxTokens: 6400,
      }),
      55000,
      "انتهت مهلة استخراج النص من الصفحات المصورة",
    );

    const rawText = normalizeDigits(getContent(result).trim());
    const pagePattern = /\[صفحة رقم\s*(\d+)\]\s*([\s\S]*?)(?=\[صفحة رقم\s*\d+\]|$)/g;
    let match: RegExpExecArray | null;
    let foundMarkers = false;
    while ((match = pagePattern.exec(rawText)) !== null) {
      const pageNumber = Number(match[1]);
      if (batch.includes(pageNumber)) {
        extractedText.set(pageNumber, match[2].trim());
        foundMarkers = true;
      }
    }

    if (!foundMarkers && rawText) {
      // لا نفقد النص إن لم يلتزم نموذج OCR بعلامة فصل الصفحات.
      extractedText.set(batch[0], rawText);
    }
  }

  return extractedText;
}

export const studyRouter = router({
  processDocument: publicProcedure
    .input(z.object({
      fileName: z.string(),
      fileData: z.string().max(55_000_000),
      mimeType: z.string(),
      pageFrom: z.number().int().min(1).max(1000).optional(),
      pageTo: z.number().int().min(1).max(1000).optional(),
    }))
    .mutation(async ({ input }) => {
      try {
        if (input.mimeType.includes("image")) {
          const imageBuffer = Buffer.from(input.fileData, "base64");
          try {
            const embeddedText = await runEmbeddedOcr(imageBuffer);
            if (hasUsableOcrText(embeddedText)) {
              const page: StructuredPage = {
                pageNumber: 1, kind: "scanned", confidence: 0.78, text: cleanArabicText(embeddedText),
                blocks: blocksFromLines(embeddedText.split(/\n+/).map(text => ({ text })), 1, "ocr", 0.78),
                warnings: ["تمت قراءة الصورة باستخدام OCR عربي"],
              };
              const structuredDocument: StructuredDocument = {
                version: 1, totalPages: 1, extractedPageFrom: 1, extractedPageTo: 1, pages: [page],
                plainText: withPageMarker(1, page.text),
                quality: { readablePages: 1, ocrPages: 1, tablePages: page.blocks.some(block => block.type === "table") ? 1 : 0, warningPages: 1, averageConfidence: 0.78 },
              };
              return { text: structuredDocument.plainText, pageCount: 1, extractedPageFrom: 1, extractedPageTo: 1, structuredDocument };
            }
          } catch (localOcrError) {
            console.warn("[study] embedded image OCR unavailable", localOcrError);
          }
          const result = await invokeLLM({
            messages: [
              { role: "system", content: "استخرج كل النص من هذه الصورة بدقة عالية باللغة العربية. حافظ على أي نصوص إنجليزية أو إسبانية." },
              { role: "user", content: [{ type: "image_url", image_url: { url: `data:${input.mimeType};base64,${input.fileData.slice(0, 50000)}`, detail: "high" as const } }] },
            ],
            maxTokens: 3000,
          });
          const fallbackText = cleanArabicText(getContent(result));
          return { text: withPageMarker(1, fallbackText), pageCount: 1, extractedPageFrom: 1, extractedPageTo: 1 };
        }

        const buffer = Buffer.from(input.fileData, "base64");
        const fileName = input.fileName.toLowerCase();
        const isPdf = input.mimeType === "application/pdf" || fileName.endsWith(".pdf");
        const isWord = input.mimeType.includes("word") || fileName.endsWith(".docx");

        if (isPdf) {
          const extraction = await extractPdfText(buffer, input.pageFrom, input.pageTo);
          let ocrPages = new Map<number, string>();
          // لا نؤخر مستنداً نصياً كاملاً بسبب صفحة غلاف أو صفحة قليلة النص.
          // عند غياب النص القابل للقراءة من كامل النطاق، ننتقل إلى OCR للملف الممسوح.
          const selectionNeedsOcr = extraction.pagesNeedingOcr.length > 0;
          if (selectionNeedsOcr) {
            try {
              ocrPages = await extractPdfWithEmbeddedOcr(buffer, extraction.pagesNeedingOcr);
              if (!ocrPages.size) ocrPages = await extractPdfWithOcr(buffer, extraction.pagesNeedingOcr);
            } catch (ocrError) {
              console.error("[study] OCR fallback failed", ocrError);
            }
          }

          const structuredDocument = buildStructuredDocument(extraction, ocrPages);
          const text = structuredDocument.plainText.trim();

          if (text.length < 20) {
            return { text: `[لم يتم العثور على نص قابل للقراءة في ${input.fileName}. جرّب تحديد نطاق صفحات أصغر أو رفع صور أوضح للصفحات المطلوبة.]` };
          }

          return {
            text,
            pageCount: extraction.totalPages,
            extractedPageFrom: extraction.firstPage,
            extractedPageTo: extraction.lastPage,
            structuredDocument,
          };
        }

        const text = isWord
          ? await extractWordText(buffer)
          : buffer.toString("utf-8").slice(0, 15000);

        if (text.length < 20) {
          return { text: `[لم يتم العثور على نص قابل للقراءة في ${input.fileName}. جرّب صورة واضحة أو ملفاً آخر.]` };
        }

        return { text, pageCount: 1, extractedPageFrom: 1, extractedPageTo: 1 };
      } catch (error) {
        console.error("[study] document processing failed", error);
        return { text: `تعذّرت معالجة ${input.fileName}. جرّب تحديد نطاق صفحات أصغر أو إعادة رفعه، مع الاحتفاظ بالملف الأصلي بالحجم نفسه.` };
      }
    }),

  summarizeDocument: publicProcedure
    .input(z.object({ text: z.string(), documentId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const chunks = sourceChunks(input.text, 8000);
        const partials: Array<{ executive: string; concepts: string[]; keyPoints: string[] }> = [];
        for (const chunk of chunks) {
          const result = await resolveWithin(invokeLLM({
            model: "gpt-5-mini",
            messages: [{ role: "system", content: "لخّص هذا الجزء من المصدر العربي بدقة ومن دون إضافة معلومات. حافظ على الأرقام والتعريفات والشروط. أعد JSON وفق المخطط." }, { role: "user", content: chunk }],
            outputSchema: summaryOutputSchema, maxCompletionTokens: 1800,
          }), 60_000, "انتهت مهلة تلخيص جزء من المستند");
          partials.push(z.object({ executive: z.string().min(20), concepts: z.array(z.string()), keyPoints: z.array(z.string()) }).parse(parseJsonObject(getContent(result))));
        }
        let parsed = partials[0];
        if (partials.length > 1) {
          const merged = await resolveWithin(invokeLLM({
            model: "gpt-5-mini",
            messages: [
              { role: "system", content: "ادمج الملخصات الجزئية في ملخص عربي شامل للمصدر كله. لا تحذف الأرقام أو الشروط المهمة ولا تضف معلومات. أعد JSON وفق المخطط." },
              { role: "user", content: JSON.stringify(partials) },
            ],
            outputSchema: summaryOutputSchema, maxCompletionTokens: 2600,
          }), 60_000, "انتهت مهلة دمج الملخصات");
          parsed = z.object({ executive: z.string().min(20), concepts: z.array(z.string()), keyPoints: z.array(z.string()) }).parse(parseJsonObject(getContent(merged)));
        }
        if (!parsed.concepts.length || !parsed.keyPoints.length) throw new Error("تعذر إنشاء ملخص مكتمل");
        return parsed;
      } catch (error) {
        console.warn("[study] using local summary fallback", error);
        return localSummary(input.text);
      }
    }),

  explainDocument: publicProcedure
    .input(z.object({ text: z.string(), documentId: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const chunks = sourceChunks(input.text, 7000);
        const explanations: string[] = [];
        for (let index = 0; index < chunks.length; index += 1) {
        const result = await resolveWithin(
          invokeLLM({
            model: "gpt-5-mini",
            messages: [
              {
                role: "system",
                content: "أنت معلّم يشرح بأسلوب مبسط وواضح. اشرح النص المرسل فقط باللغة العربية الفصحى السهلة، وكأنك تراجع الدرس مع طالب. رتّب الشرح في فقرات قصيرة تشمل الفكرة العامة، ثم الأفكار خطوة بخطوة، ثم مثالاً أو رابطاً ذهنياً عند ملاءمته. لا تخترع معلومات ولا تذكر أنك نموذج ذكاء اصطناعي.",
              },
              { role: "user", content: `الجزء ${index + 1} من ${chunks.length}:\n\n${chunks[index]}` },
            ],
            maxCompletionTokens: 2800,
          }),
          55000,
          "استغرق إنشاء الشرح وقتاً أطول من المعتاد. أعد المحاولة.",
        );
          const explanation = getContent(result).trim();
          if (explanation.length < 30) throw new Error("تعذّر إنشاء شرح مكتمل لهذا الجزء");
          explanations.push(explanation);
        }
        return { explanation: explanations.map((value, index) => `الجزء ${index + 1}\n${value}`).join("\n\n") };
      } catch (error) {
        console.warn("[study] using local explanation fallback", error);
        return { explanation: localExplanation(input.text) };
      }
    }),

  generateQuestions: publicProcedure
    .input(z.object({ text: z.string().min(20), documentId: z.string(), questionCount: z.number().int().min(1).max(300).default(150), typeCounts: z.record(z.string(), z.number().int().min(0).max(300)).optional() }))
    .mutation(async ({ input }) => {
      const requestedTotal = input.typeCounts
        ? Math.min(300, (input.typeCounts.mcq || 0) + (input.typeCounts.truefalse || 0))
        : input.questionCount;
      const effectiveCount = requestedTotal || input.questionCount;
      const targetMcq = input.typeCounts?.mcq ?? Math.ceil(effectiveCount * 0.7);
      const targetTrueFalse = input.typeCounts?.truefalse ?? Math.max(0, effectiveCount - targetMcq);
      const chunks = sourceChunks(input.text);
      const generated: any[] = [];

      const requestQuestionBank = async (chunk: string, mcqCount: number, trueFalseCount: number, batchIndex: number) => {
        const count = mcqCount + trueFalseCount;
        const firstPage = pageNumberFromText(chunk);
        const result = await resolveWithin(
          invokeLLM({
            model: "gpt-5-mini",
            messages: [
              { role: "system", content: `أنت خبير إعداد امتحانات عربية. أنشئ من الجزء المرسل بالضبط ${count} سؤالاً: ${mcqCount} اختيار من متعدد من النوع mcq و${trueFalseCount} صح أو خطأ من النوع truefalse. غطِّ الأرقام والتعريفات والشروط والتفاصيل المهمة، ولا تكرر نفس الفكرة. لا تستخدم أي معلومة خارج النص. لكل MCQ أربعة خيارات منطقية وإجابة واحدة صحيحة. لكل صح/خطأ نوّع بين العبارات الصحيحة والخاطئة، وإذا كانت خاطئة اكتب التصحيح في answer. أعد JSON فقط بالشكل {"questions":[...]}. الحقول الإلزامية لكل سؤال: id,type,question,answer,hint,options,correctAnswer,pairs,sourcePage,sourceQuote. sourcePage هو رقم الصفحة الظاهر في النص، وsourceQuote اقتباس قصير يدعم الإجابة. pairs دائماً [] هنا.` },
              { role: "user", content: `رقم الدفعة: ${batchIndex}. تبدأ قرب الصفحة ${firstPage}.\n\n${chunk}` },
            ],
            outputSchema: questionOutputSchema,
            maxCompletionTokens: Math.min(9000, 1200 + count * 260),
          }),
          90000,
          "استغرق توليد دفعة الأسئلة وقتاً أطول من المعتاد.",
        );
        return generatedQuestionBankSchema.parse(parseJsonObject(getContent(result)));
      };

      let remainingMcq = targetMcq;
      let remainingTrueFalse = targetTrueFalse;
      let batchIndex = 0;
      while ((remainingMcq > 0 || remainingTrueFalse > 0) && batchIndex < Math.max(chunks.length * 4, 20)) {
        const chunk = chunks[batchIndex % Math.max(chunks.length, 1)] || input.text;
        const batchMcq = Math.min(14, remainingMcq);
        const batchTrueFalse = Math.min(6, remainingTrueFalse);
        if (batchMcq + batchTrueFalse === 0) break;
        try {
          const parsed = await requestQuestionBank(chunk, batchMcq, batchTrueFalse, batchIndex + 1);
          generated.push(...parsed.questions);
        } catch (error) {
          console.warn(`[study] question batch ${batchIndex + 1} used deterministic fallback`, error);
          generated.push(...localQuestionBank(chunk, batchMcq + batchTrueFalse, input.documentId, { mcq: batchMcq, truefalse: batchTrueFalse }));
        }
        remainingMcq -= batchMcq;
        remainingTrueFalse -= batchTrueFalse;
        batchIndex += 1;
      }

      const candidates: any[] = [];
      const candidateKeys = new Set<string>();
      for (const question of generated) {
        if (question.type !== "mcq" && question.type !== "truefalse") continue;
        const key = normalizedQuestionKey(question.question + (question.sourceQuote || ""));
        if (!key || candidateKeys.has(key)) continue;
        candidateKeys.add(key);
        candidates.push({ ...question, documentId: input.documentId });
      }

      const sections = sourcePageSections(input.text);
      const selected: any[] = [];
      const selectedKeys = new Set<string>();
      let selectedMcq = 0;
      let selectedTrueFalse = 0;
      const canUse = (question: any) => question.type === "mcq" ? selectedMcq < targetMcq : selectedTrueFalse < targetTrueFalse;
      const addQuestion = (question: any) => {
        const key = normalizedQuestionKey(question.question + (question.sourceQuote || ""));
        if (!key || selectedKeys.has(key) || !canUse(question) || selected.length >= effectiveCount) return false;
        selectedKeys.add(key);
        selected.push({ ...question, documentId: input.documentId });
        if (question.type === "mcq") selectedMcq += 1; else selectedTrueFalse += 1;
        return true;
      };
      const nextCoverageType = () => {
        if (selectedMcq >= targetMcq) return "truefalse";
        if (selectedTrueFalse >= targetTrueFalse) return "mcq";
        return selectedMcq / Math.max(targetMcq, 1) <= selectedTrueFalse / Math.max(targetTrueFalse, 1) ? "mcq" : "truefalse";
      };

      // التغطية شرط سابق للعدد: نضمن سؤالاً واحداً على الأقل من كل صفحة قبل ملء بقية البنك.
      if (sections.length <= effectiveCount) {
        for (const section of sections) {
          const desiredType = nextCoverageType();
          const fromModel = candidates.find(question => question.sourcePage === section.pageNumber && question.type === desiredType && !selectedKeys.has(normalizedQuestionKey(question.question + (question.sourceQuote || ""))))
            || candidates.find(question => question.sourcePage === section.pageNumber && canUse(question) && !selectedKeys.has(normalizedQuestionKey(question.question + (question.sourceQuote || ""))));
          if (fromModel && addQuestion(fromModel)) continue;
          const fallback = localQuestionBank(section.text, 1, input.documentId, {
            mcq: desiredType === "mcq" ? 1 : 0,
            truefalse: desiredType === "truefalse" ? 1 : 0,
          })[0];
          addQuestion(fallback);
        }
      }

      for (const question of candidates) addQuestion(question);

      let pageCursor = 0;
      while (selected.length < effectiveCount && sections.length && pageCursor < sections.length * 8) {
        const section = sections[pageCursor % sections.length];
        const remainingMcq = Math.max(0, targetMcq - selectedMcq);
        const remainingTrueFalse = Math.max(0, targetTrueFalse - selectedTrueFalse);
        const supplements = localQuestionBank(section.text, Math.min(5, remainingMcq + remainingTrueFalse), input.documentId, {
          mcq: Math.min(3, remainingMcq),
          truefalse: Math.min(2, remainingTrueFalse),
        });
        for (const question of supplements) addQuestion(question);
        pageCursor += 1;
      }
      return selected.slice(0, effectiveCount).map((question, index) => ({ ...question, id: `q${index + 1}`, documentId: input.documentId }));
    }),

  gradeEssay: publicProcedure
    .input(z.object({ question: z.string(), modelAnswer: z.string(), studentAnswer: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const result = await resolveWithin(invokeLLM({
          messages: [
            { role: "system", content: "قيّم إجابة الطالب وأعد JSON: {\"score\":0-100,\"feedback\":\"تغذية راجعة\",\"strengths\":[],\"weaknesses\":[]}" },
            { role: "user", content: `السؤال: ${input.question}\nالإجابة النموذجية: ${input.modelAnswer}\nإجابة الطالب: ${input.studentAnswer}` },
          ],
          responseFormat: { type: "json_object" }, maxTokens: 1000,
        }), 30_000, "انتهت مهلة التصحيح الذكي");
        const content = getContent(result);
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        return JSON.parse(jsonMatch ? jsonMatch[0] : content);
      } catch {
        return localEssayGrade(input.modelAnswer, input.studentAnswer);
      }
    }),

  exportDocument: publicProcedure
    .input(z.object({
      type: z.enum(["pdf", "word"]), content: z.string().default(""), title: z.string().min(1),
      questions: z.array(z.object({
        question: z.string(), answer: z.string(), options: z.array(z.string()).optional(),
        correctAnswer: z.string().optional(), sourcePage: z.number().optional(),
      })).default([]),
    }))
    .mutation(async ({ input }) => {
      const data = input.type === "word"
        ? await createWordExport(input.title, input.content, input.questions)
        : await createPdfExport(input.title, input.content, input.questions);
      return {
        success: true,
        fileName: `${input.title.replace(/[\\/:*?"<>|]/g, "-")}.${input.type === "word" ? "docx" : "pdf"}`,
        mimeType: input.type === "word" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/pdf",
        base64: data.toString("base64"),
      };
    }),
});
