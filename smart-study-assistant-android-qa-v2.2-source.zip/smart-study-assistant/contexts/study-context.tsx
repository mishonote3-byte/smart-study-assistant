import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { StructuredDocument } from '@/shared/study';

export interface Summary {
  executive: string;
  concepts: string[];
  keyPoints: string[];
  createdAt: string;
}

export interface Question {
  id: string;
  type: 'mcq' | 'fill' | 'truefalse' | 'enumerate' | 'reason' | 'matching';
  question: string;
  answer: string;
  options?: string[];
  correctAnswer?: string;
  pairs?: { left: string; right: string }[];
  /** تلميح موجز يوجه الطالب إلى الفكرة ولا يعرض الإجابة النموذجية مباشرة. */
  hint?: string;
  documentId: string;
  sourcePage?: number;
  sourceQuote?: string;
}

export interface QuestionDetail {
  questionId: string;
  questionText: string;
  questionType: Question['type'];
  userAnswer: unknown;
  correctAnswer: string;
  isCorrect: boolean;
  hint?: string;
  essayFeedback?: string;
  essayScore?: number;
}

export interface ExamResult {
  id: string;
  documentId: string;
  documentName: string;
  totalQuestions: number;
  score: number;
  answers: Record<string, any>;
  essayScores?: Record<string, { score: number; feedback: string }>;
  /** لقطة من الأسئلة والإجابات وقت إنهاء الامتحان لعرض التصحيح لاحقاً. */
  questionDetails?: QuestionDetail[];
  createdAt: string;
}

export interface Document {
  id: string;
  name: string;
  text: string;
  processingState?: 'processing' | 'ready' | 'failed';
  processingMessage?: string;
  pageCount?: number;
  extractedPageFrom?: number;
  extractedPageTo?: number;
  summary?: Summary;
  explanation?: string;
  questionBank?: Question[];
  createdAt: string;
  filePath?: string;
  mimeType?: string;
  structuredDocument?: StructuredDocument;
}

interface StudyContextType {
  documents: Document[];
  examResults: ExamResult[];
  addDocument: (doc: Omit<Document, 'id' | 'createdAt'>) => Promise<string>;
  updateDocument: (id: string, updates: Partial<Document>) => Promise<void>;
  deleteDocument: (id: string) => Promise<void>;
  addExamResult: (result: Omit<ExamResult, 'id' | 'createdAt'>) => Promise<string>;
  getDocument: (id: string) => Document | undefined;
  loadAll: () => Promise<void>;
}

const StudyContext = createContext<StudyContextType | null>(null);
const STORAGE_KEY = 'study_documents';
const RESULTS_KEY = 'study_exam_results';

export function StudyProvider({ children }: { children: ReactNode }) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [examResults, setExamResults] = useState<ExamResult[]>([]);

  const loadAll = useCallback(async () => {
    try {
      const [docsData, resultsData] = await AsyncStorage.multiGet([STORAGE_KEY, RESULTS_KEY]);
      if (docsData[1]) setDocuments(JSON.parse(docsData[1]));
      if (resultsData[1]) setExamResults(JSON.parse(resultsData[1]));
    } catch (e) { console.error(e); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const addDocument = async (docData: Omit<Document, 'id' | 'createdAt'>): Promise<string> => {
    const newDoc: Document = { ...docData, id: Date.now().toString(36) + Math.random().toString(36).slice(2), createdAt: new Date().toISOString() };
    setDocuments(currentDocuments => {
      const nextDocuments = [newDoc, ...currentDocuments];
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextDocuments));
      return nextDocuments;
    });
    return newDoc.id;
  };
  const updateDocument = async (id: string, updates: Partial<Document>) => {
    setDocuments(currentDocuments => {
      const nextDocuments = currentDocuments.map(d => d.id === id ? { ...d, ...updates } : d);
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextDocuments));
      return nextDocuments;
    });
  };
  const deleteDocument = async (id: string) => {
    setDocuments(current => {
      const next = current.filter(document => document.id !== id);
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
    setExamResults(current => {
      const next = current.filter(result => result.documentId !== id);
      void AsyncStorage.setItem(RESULTS_KEY, JSON.stringify(next));
      return next;
    });
  };
  const addExamResult = async (resultData: Omit<ExamResult, 'id' | 'createdAt'>): Promise<string> => {
    const result: ExamResult = { ...resultData, id: Date.now().toString(36) + Math.random().toString(36).slice(2), createdAt: new Date().toISOString() };
    setExamResults(current => {
      const next = [result, ...current];
      void AsyncStorage.setItem(RESULTS_KEY, JSON.stringify(next));
      return next;
    });
    return result.id;
  };
  const getDocument = (id: string) => documents.find(d => d.id === id);

  return (
    <StudyContext.Provider value={{ documents, examResults, addDocument, updateDocument, deleteDocument, addExamResult, getDocument, loadAll }}>
      {children}
    </StudyContext.Provider>
  );
}

export function useStudy() {
  const ctx = useContext(StudyContext);
  if (!ctx) throw new Error('useStudy must be used within StudyProvider');
  return ctx;
}
