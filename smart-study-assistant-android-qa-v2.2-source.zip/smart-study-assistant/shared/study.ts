export type PageKind = "text" | "scanned" | "distorted" | "mixed" | "table";

export type StudyBlock =
  | {
      id: string;
      type: "heading" | "paragraph" | "list-item";
      text: string;
      pageNumber: number;
      order: number;
      confidence: number;
      source: "pdf-text" | "ocr";
    }
  | {
      id: string;
      type: "table";
      pageNumber: number;
      order: number;
      confidence: number;
      source: "pdf-text" | "ocr";
      rows: string[][];
    };

export interface StructuredPage {
  pageNumber: number;
  kind: PageKind;
  confidence: number;
  text: string;
  blocks: StudyBlock[];
  warnings: string[];
}

export interface StructuredDocument {
  version: 1;
  totalPages: number;
  extractedPageFrom: number;
  extractedPageTo: number;
  pages: StructuredPage[];
  plainText: string;
  quality: {
    readablePages: number;
    ocrPages: number;
    tablePages: number;
    warningPages: number;
    averageConfidence: number;
  };
}

