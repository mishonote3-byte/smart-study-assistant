export type MatchingPair = {
  left: string;
  right: string;
};

/** يحوّل قيمة الدقائق المختارة إلى ثوانٍ لعداد الامتحان. */
export function minutesToSeconds(minutes: number | string | undefined): number {
  const parsedMinutes = Number(minutes);
  return Number.isFinite(parsedMinutes) && parsedMinutes > 0
    ? Math.floor(parsedMinutes * 60)
    : 0;
}

/** يتحقق من اكتمال وصحة جميع أزواج سؤال المطابقة. */
export function isMatchingAnswerCorrect(
  selectedPairs: Record<string, string> | undefined,
  pairs: MatchingPair[] | undefined,
): boolean {
  if (!selectedPairs || !pairs || pairs.length === 0) return false;

  return pairs.every((pair) =>
    String(selectedPairs[pair.left] || '').trim() === pair.right.trim(),
  );
}
