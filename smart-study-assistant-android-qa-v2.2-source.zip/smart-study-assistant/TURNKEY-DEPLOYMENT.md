# Turnkey deployment
This project is prepared for a hosted backend on Railway and automatic Android APK builds on GitHub Actions.
Required deployment secrets:
- Backend: BUILT_IN_FORGE_API_KEY (or compatible provider configuration), JWT_SECRET, DATABASE_URL if persistence is enabled.
- GitHub Actions: EXPO_PUBLIC_API_BASE_URL, ANDROID_KEYSTORE_BASE64, ANDROID_KEY_ALIAS, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_PASSWORD.
The signing keystore is kept under signing/ in the handoff archive and should be converted to a protected GitHub secret during deployment.
