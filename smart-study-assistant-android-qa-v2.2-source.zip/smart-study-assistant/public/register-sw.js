// Registers the service worker only in secure browser contexts.
// This enables offline access to the already-opened app shell without caching API requests.
if ('serviceWorker' in navigator && window.isSecureContext) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js', { scope: '/', updateViaCache: 'none' })
      .then((registration) => registration.update())
      .catch(() => {
        // The app remains usable online if the browser declines service worker registration.
      });
  });
}
